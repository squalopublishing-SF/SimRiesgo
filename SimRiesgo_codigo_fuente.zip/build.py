#!/usr/bin/env python3
"""Construye SimRiesgo.xlam a partir de las fuentes VBA, la plantilla del visor y la cinta."""
import os, sys, re, shutil, uuid, zipfile, tempfile, io

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC_VBA = os.path.join(ROOT, "src", "vba")
VISOR = os.path.join(ROOT, "src", "visor", "visor.html")
RIBBON = os.path.join(ROOT, "src", "ribbon", "customUI14.xml")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "dist", "SimRiesgo.xlam")

sys.path.insert(0, os.environ.get("VBAC_SRC", ""))
from ms_ovba.vbaProject import VbaProject
from ms_ovba.Models.Entities.doc_module import DocModule
from ms_ovba.Models.Entities.std_module import StdModule
from ms_ovba.Views.dirStream import DirStream
from ms_ovba.Views.project_view import ProjectView
from ms_ovba.Views.project import Project
from ms_ovba.Views.projectWm import ProjectWm
from ms_ovba.Models.Entities.reference import Reference
from ms_ovba.Models.Entities.reference_registered import ReferenceRegistered
from ms_ovba.Models.Fields.libid_reference import LibidReference
import openpyxl
from ms_ovba_compression.ms_ovba import MsOvba
sys.path.insert(0, ROOT)
from ovba_compress import compress as _ovba_compress
from cfb_write import write_cfb
MsOvba.compress = lambda self, data: _ovba_compress(bytes(data))


def stored_source(path, is_class):
    text = open(path, encoding="utf-8").read().replace("\r\n", "\n")
    lines = text.split("\n")
    if is_class:
        # quitar el bloque VERSION/BEGIN/END de los .cls exportados
        assert lines[0].startswith("VERSION") and lines[3].strip() == "END", path
        lines = lines[4:]
    while lines and lines[-1] == "":
        lines.pop()
    body = "\r\n".join(lines) + "\r\n"
    return body.encode("cp1252")  # falla si hay caracteres fuera de cp1252


class ClassModule(StdModule):
    """Modulo de clase (tipo 0x0022 en dir, 'Class=' en PROJECT)."""
    def __init__(self, name):
        super().__init__(name)
        self.type = "Class"

    def pack(self, endien, cp_name):
        self.type = "Document"
        try:
            return super().pack(endien, cp_name)
        finally:
            self.type = "Class"


def build_vba(workdir):
    project = VbaProject()
    project.project_id = "{" + str(uuid.uuid4()).upper() + "}"
    order = ["ThisWorkbook.cls", "Sheet1.cls"] + sorted(f for f in os.listdir(SRC_VBA) if f.endswith(".bas")) + \
        sorted(f for f in os.listdir(SRC_VBA) if f.endswith(".cls") and f not in ("ThisWorkbook.cls", "Sheet1.cls"))
    for fname in order:
        name = os.path.splitext(fname)[0]
        is_class = fname.endswith(".cls")
        data = stored_source(os.path.join(SRC_VBA, fname), is_class)
        base = os.path.join(workdir, name)
        open(base + ".new", "wb").write(data)
        if fname in ("ThisWorkbook.cls", "Sheet1.cls"):
            mod = DocModule(name)
        elif is_class:
            mod = ClassModule(name)
        else:
            mod = StdModule(name)
        mod.add_file(base)
        project.add_module(mod)
    stdole = LibidReference(uuid.UUID("00020430-0000-0000-C000-000000000046"), "2.0", "0",
                            "C:\\Windows\\System32\\stdole2.tlb", "OLE Automation")
    office = LibidReference(uuid.UUID("2DF8D04C-5BFA-101B-BDE5-00AA0044DE52"), "2.0", "0",
                            r"C:\Program Files\Common Files\Microsoft Shared\OFFICE16\MSO.DLL",
                            "Microsoft Office 16.0 Object Library")
    project.add_reference(Reference(ReferenceRegistered(stdole), "stdole"))
    project.add_reference(Reference(ReferenceRegistered(office), "Office"))
    cwd = os.getcwd()
    os.chdir(workdir)
    try:
        # el escritor OLE de la biblioteca corrompe archivos de mas de 64 KB: se usa uno propio
        streams = {}
        for module in project.get_modules():
            module.write_file()
            streams[module.name] = open(module.bin_path, "rb").read()
        DirStream(project).write_file()
        streams["dir"] = open("dir.bin", "rb").read()
        ProjectView(project).write_file()
        streams["_VBA_PROJECT"] = open("vba_project.bin", "rb").read()
        tree = {"VBA": streams}
        if project.projectwm:
            ProjectWm(project).write_file()
            tree["PROJECTwm"] = open("projectwm.bin", "rb").read()
        Project(project).write_file()
        tree["PROJECT"] = open("project.bin", "rb").read()
        if os.environ.get("SR_OLDCFB"):
            from ms_ovba.Views.project_ole_file import ProjectOleFile
            ProjectOleFile._write_ole_file(ProjectOleFile._build_ole_directory(project))
        else:
            write_cfb("vbaProject.bin", tree)
    finally:
        os.chdir(cwd)
    return open(os.path.join(workdir, "vbaProject.bin"), "rb").read()


def ascii_template(html):
    """Convierte caracteres no ASCII: entidades HTML fuera de <script>, escapes \\u dentro."""
    out, pos = [], 0
    for m in re.finditer(r"<script>(.*?)</script>", html, re.S):
        out.append(re.sub(r"[^\x00-\x7e]", lambda c: "&#%d;" % ord(c.group()), html[pos:m.start(1)]))
        out.append(re.sub(r"[^\x00-\x7e]", lambda c: "\\u%04x" % ord(c.group()), m.group(1)))
        pos = m.end(1)
    out.append(re.sub(r"[^\x00-\x7e]", lambda c: "&#%d;" % ord(c.group()), html[pos:]))
    return "".join(out)


def template_chunks():
    html = ascii_template(open(VISOR, encoding="utf-8").read())
    bad = [c for c in set(html) if ord(c) > 126]
    if bad:
        raise SystemExit("La plantilla del visor contiene caracteres no ASCII: %r" % bad[:20])
    if html.count("__SR_DATA__") != 1:
        raise SystemExit("La plantilla debe contener exactamente un marcador __SR_DATA__")
    size = 30000
    return ["|" + html[i:i + size] + "|" for i in range(0, len(html), size)]


def build_base_xlsx(path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "SRVisor"
    ws.sheet_properties.codeName = "Sheet1"
    for i, chunk in enumerate(template_chunks(), start=1):
        c = ws.cell(row=i, column=1)
        c.value = chunk
        c.data_type = "s"
    wb.code_name = "ThisWorkbook"
    wb.save(path)


def assemble(base_xlsx, vba_bin, out_path):
    zin = zipfile.ZipFile(base_xlsx)
    files = {n: zin.read(n) for n in zin.namelist()}
    zin.close()

    ct = files["[Content_Types].xml"].decode("utf-8")
    ct = ct.replace("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
                    "application/vnd.ms-excel.addin.macroEnabled.main+xml")
    if 'Extension="bin"' not in ct:
        ct = ct.replace("<Default ", '<Default Extension="bin" ContentType="application/vnd.ms-office.vbaProject"/><Default ', 1)
    files["[Content_Types].xml"] = ct.encode("utf-8")

    rels = files["xl/_rels/workbook.xml.rels"].decode("utf-8")
    rels = rels.replace("</Relationships>",
                        '<Relationship Id="rIdVBA1" Type="http://schemas.microsoft.com/office/2006/relationships/vbaProject" Target="vbaProject.bin"/></Relationships>')
    files["xl/_rels/workbook.xml.rels"] = rels.encode("utf-8")
    files["xl/vbaProject.bin"] = vba_bin

    wbx = files["xl/workbook.xml"].decode("utf-8")
    if 'codeName="ThisWorkbook"' not in wbx:
        raise SystemExit("workbook.xml sin codeName")
    files["xl/workbook.xml"] = wbx.encode("utf-8")

    root_rels = files["_rels/.rels"].decode("utf-8")
    root_rels = root_rels.replace("</Relationships>",
                                  '<Relationship Id="rIdUI14" Type="http://schemas.microsoft.com/office/2007/relationships/ui/extensibility" Target="customUI/customUI14.xml"/></Relationships>')
    files["_rels/.rels"] = root_rels.encode("utf-8")
    files["customUI/customUI14.xml"] = open(RIBBON, "rb").read()
    files["customUI/images/selloSqualo.png"] = open(os.path.join(ROOT, "src", "brand", "sello_64.png"), "rb").read()
    files["customUI/_rels/customUI14.xml.rels"] = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="selloSqualo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="images/selloSqualo.png"/>'
        '</Relationships>').encode("utf-8")
    ct = files["[Content_Types].xml"].decode("utf-8")
    if 'Extension="png"' not in ct:
        ct = ct.replace("<Default ", '<Default Extension="png" ContentType="image/png"/><Default ', 1)
    files["[Content_Types].xml"] = ct.encode("utf-8")

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    order = ["[Content_Types].xml"] + [n for n in files if n != "[Content_Types].xml"]
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for n in order:
            z.writestr(n, files[n])


def main():
    work = tempfile.mkdtemp(prefix="srbuild_")
    vba_bin = build_vba(work)
    base = os.path.join(work, "base.xlsx")
    build_base_xlsx(base)
    assemble(base, vba_bin, OUT)
    open(os.path.join(work, "vbaProject.bin"), "rb")
    shutil.copy(os.path.join(work, "vbaProject.bin"), os.path.join(os.path.dirname(OUT), "vbaProject.bin.debug"))
    print("OK", OUT, os.path.getsize(OUT), "bytes; vba", len(vba_bin))


if __name__ == "__main__":
    main()
