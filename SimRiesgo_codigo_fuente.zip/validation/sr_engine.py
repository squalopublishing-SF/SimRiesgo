"""Traduccion fiel a Python del motor VBA de SimRiesgo (modSRMotor / modSRDist).

Misma aritmetica en doble precision, mismo orden de llamadas al generador,
mismas formulas de inversion. Sirve para validar el motor fuera de Excel.
"""
import math
from scipy import stats

M1 = 4294967087.0
M2 = 4294944443.0
NORM = 2.32830654929573E-10


def fmod(a, m):
    r = a - math.floor(a / m) * m
    if r < 0: r += m
    if r >= m: r -= m
    return r


class MRG32k3a:
    def __init__(self, seed):
        x = fmod(abs(math.floor(seed)), 2147483647.0) + 1.0
        s = []
        for mod in (M1, M1, M1, M2, M2, M2):
            x = fmod(69069.0 * x + 1.0, 4294967296.0)
            s.append(fmod(x, mod))
        self.s10, self.s11, self.s12, self.s20, self.s21, self.s22 = s
        if self.s10 == 0 and self.s11 == 0 and self.s12 == 0: self.s10 = 12345.0
        if self.s20 == 0 and self.s21 == 0 and self.s22 == 0: self.s20 = 12345.0
        for _ in range(20): self.next()

    def next(self):
        p1 = 1403580.0 * self.s11 - 810728.0 * self.s10
        p1 = p1 - math.floor(p1 / M1) * M1
        if p1 < 0: p1 += M1
        if p1 >= M1: p1 -= M1
        self.s10, self.s11, self.s12 = self.s11, self.s12, p1
        p2 = 527612.0 * self.s22 - 1370589.0 * self.s20
        p2 = p2 - math.floor(p2 / M2) * M2
        if p2 < 0: p2 += M2
        if p2 >= M2: p2 -= M2
        self.s20, self.s21, self.s22 = self.s21, self.s22, p2
        return (p1 - p2) * NORM if p1 > p2 else (p1 - p2 + M1) * NORM


def generar_u(rng, n_inputs, n, lhs=True):
    """Igual que GenerarU: una columna de uniformes por entrada."""
    U = []
    for _ in range(n_inputs):
        if lhs:
            perm = list(range(1, n + 1))
            for i in range(n, 1, -1):
                k = math.floor(rng.next() * i) + 1
                if k > i: k = i
                perm[i - 1], perm[k - 1] = perm[k - 1], perm[i - 1]
            U.append([(perm[i] - 1 + rng.next()) / n for i in range(n)])
        else:
            U.append([rng.next() for _ in range(n)])
    return U


def norm_s_inv(p):
    a = [-39.6968302866538, 220.946098424521, -275.928510446969, 138.357751867269, -30.6647980661472, 2.50662827745924]
    b = [-54.4760987982241, 161.585836858041, -155.698979859887, 66.8013118877197, -13.2806815528857]
    c = [-7.78489400243029E-03, -0.322396458041136, -2.40075827716184, -2.54973253934373, 4.37466414146497, 2.93816398269878]
    d = [7.78469570904146E-03, 0.32246712907004, 2.445134137143, 3.75440866190742]
    plow = 0.02425
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p <= 1 - plow:
        q = p - 0.5; r = q * q
        return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)
    q = math.sqrt(-2 * math.log(1 - p))
    return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)


def inv_cdf(t, u, p):
    """Igual que InvCdf (Beta_Inv, Gamma_Inv y Binom_Inv de Excel -> scipy)."""
    u = min(max(u, 1e-12), 0.999999999999)
    if t == "normal": return p[0] + p[1] * norm_s_inv(u)
    if t == "triangular":
        a, c, b = p; fc = (c - a) / (b - a)
        return a + math.sqrt(u * (b - a) * (c - a)) if u < fc else b - math.sqrt((1 - u) * (b - a) * (b - c))
    if t == "pert":
        a, c, b = p
        return a + (b - a) * stats.beta.ppf(u, 1 + 4 * (c - a) / (b - a), 1 + 4 * (b - c) / (b - a))
    if t == "uniforme": return p[0] + (p[1] - p[0]) * u
    if t == "lognormal":
        s2 = math.log(1 + (p[1] / p[0]) ** 2); mu = math.log(p[0]) - s2 / 2
        return math.exp(mu + math.sqrt(s2) * norm_s_inv(u))
    if t == "weibull": return p[1] * (-math.log(1 - u)) ** (1 / p[0])
    if t == "exponencial": return -p[0] * math.log(1 - u)
    if t == "gamma": return stats.gamma.ppf(u, p[0], scale=p[1])
    if t == "beta": return p[2] + (p[3] - p[2]) * stats.beta.ppf(u, p[0], p[1])
    if t == "poisson":
        lam = p[0]
        if lam <= 0: return 0.0
        if lam > 400: return max(0.0, math.floor(lam + math.sqrt(lam) * norm_s_inv(u) + 0.5))
        k, pk = 0, math.exp(-lam); cum = pk
        while cum < u and k < 100000:
            k += 1; pk = pk * lam / k; cum += pk
        return float(k)
    if t == "binomial":
        if p[1] <= 0: return 0.0
        if p[1] >= 1: return float(p[0])
        return float(stats.binom.ppf(u, p[0], p[1]))
    if t == "bernoulli": return 1.0 if u > 1 - p[0] else 0.0
    if t == "loglogistica": return p[2] + p[0] * (u / (1 - u)) ** (1 / p[1])
    if t == "pearson5": return p[2] + p[1] / stats.gamma.ppf(1 - u, p[0])
    if t == "normaltrunc":
        a = stats.norm.cdf((p[2] - p[0]) / p[1]); b = stats.norm.cdf((p[3] - p[0]) / p[1])
        c = min(max(a + u * (b - a), 1e-12), 0.999999999999)
        return min(max(p[0] + p[1] * norm_s_inv(c), p[2]), p[3])
    if t == "empirica":
        ev = sorted(p); n = len(ev); fc = u * (n - 1) + 1; i = math.floor(fc)
        return ev[-1] if i >= n else ev[i - 1] + (fc - i) * (ev[i] - ev[i - 1])
    if t == "discreta":
        vals, probs = p; tot = sum(probs); cum = 0
        for v, pr in zip(vals, probs):
            cum += pr / tot
            if u <= cum: return float(v)
        return float(vals[-1])
    raise ValueError(t)


def valor_esperado(t, p):
    if t in ("normal", "lognormal", "exponencial", "poisson"): return p[0]
    if t == "triangular": return sum(p) / 3
    if t == "pert": return (p[0] + 4 * p[1] + p[2]) / 6
    if t == "uniforme": return (p[0] + p[1]) / 2
    if t == "weibull": return p[1] * math.exp(math.lgamma(1 + 1 / p[0]))
    if t == "gamma": return p[0] * p[1]
    if t == "beta": return p[2] + (p[3] - p[2]) * p[0] / (p[0] + p[1])
    if t == "binomial": return p[0] * p[1]
    if t == "bernoulli": return p[0]
    if t == "discreta": vals, probs = p; return sum(v * q for v, q in zip(vals, probs)) / sum(probs)
    if t == "loglogistica": return p[2] + (p[0] * (math.pi / p[1]) / math.sin(math.pi / p[1]) if p[1] > 1 else p[0])
    if t == "pearson5": return p[2] + p[1] / (p[0] - 1)
    if t == "normaltrunc":
        za, zb = (p[2] - p[0]) / p[1], (p[3] - p[0]) / p[1]
        return p[0] + p[1] * (stats.norm.pdf(za) - stats.norm.pdf(zb)) / (stats.norm.cdf(zb) - stats.norm.cdf(za))
    if t == "empirica":
        ev = sorted(p); return sum((ev[i] + ev[i + 1]) / 2 for i in range(len(ev) - 1)) / (len(ev) - 1)


def percentil(sorted_vals, p):
    """Igual que PercentilOrdenado (y pct del visor): inversa de la FDA empirica."""
    n = len(sorted_vals); k = -math.floor(-p * n)
    k = min(max(k, 1), n)
    return sorted_vals[k - 1]


def simular(inputs, modelo, n, seed, lhs=True, sims=1):
    """inputs: lista de (tipo, params). modelo(x, sim) -> dict de salidas."""
    rng = MRG32k3a(seed)
    X = []; Y = []
    for s in range(sims):
        U = generar_u(rng, len(inputs), n, lhs)
        xs = [[inv_cdf(t, U[j][i], p) for i in range(n)] for j, (t, p) in enumerate(inputs)]
        ys = None
        for i in range(n):
            out = modelo([xs[j][i] for j in range(len(inputs))], s)
            if ys is None: ys = {k: [] for k in out}
            for k, v in out.items(): ys[k].append(v)
        X.append(xs); Y.append(ys)
    return X, Y


def norm_s_inv_v(p):
    return norm_s_inv(p)


def _chol(A):
    import math
    n = len(A); L = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1):
            s = A[i][j] - sum(L[i][k] * L[j][k] for k in range(j))
            if i == j:
                if s <= 1e-10: return None
                L[i][i] = math.sqrt(s)
            else:
                L[i][j] = s / L[j][j]
    return L


def iman_conover(rng, U, idx, C):
    """Igual que AplicarCorrelaciones: reordena U[idx[j]] para inducir la correlacion de rangos C."""
    import numpy as np
    n = len(U[0]); k = len(idx)
    sc = [norm_s_inv((i + 1) / (n + 1)) for i in range(n)]
    R = np.zeros((n, k))
    for j in range(k):
        perm = list(range(1, n + 1))
        for i in range(n, 1, -1):
            kk = math.floor(rng.next() * i) + 1
            if kk > i: kk = i
            perm[i - 1], perm[kk - 1] = perm[kk - 1], perm[i - 1]
        for i in range(n):
            R[i, j] = sc[perm[i] - 1]
    T = np.corrcoef(R, rowvar=False) if k > 1 else np.ones((1, 1))
    T = (R.T @ R); d = np.sqrt(np.diag(T)); T = T / np.outer(d, d)
    Ct = [[1.0 if i == j else 2 * math.sin(math.pi * C[i][j] / 6) for j in range(k)] for i in range(k)]
    L = _chol(Ct) or _chol(C)
    P = np.array(L); Q = np.array(_chol(T.tolist()))
    M = (P @ np.linalg.inv(Q)).T
    Rs = R @ M
    for j in range(k):
        order = np.argsort(Rs[:, j], kind="stable")
        us = sorted(U[idx[j]])
        newcol = [0.0] * n
        for r, ii in enumerate(order):
            newcol[ii] = us[r]
        U[idx[j]] = newcol
    return U
