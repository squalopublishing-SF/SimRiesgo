"""Bateria de validacion de SimRiesgo: escenarios con resultado teorico conocido."""
import json, math, sys, os, asyncio
import numpy as np
from scipy import stats, integrate
sys.path.insert(0, os.path.dirname(__file__))
from sr_engine import MRG32k3a, generar_u, inv_cdf, valor_esperado, percentil, simular

R = {}
Z90 = 1.6449


def chk(ok):
    return "Cumple" if ok else "NO CUMPLE"


# ------------------------------------------------------------------ E1 generador
def e1():
    n = 1_000_000
    r = MRG32k3a(1); u = np.array([r.next() for _ in range(n)])
    cnt, _ = np.histogram(u, bins=100, range=(0, 1))
    chi = stats.chisquare(cnt)
    ks = stats.kstest(u, "uniform")
    ac = np.corrcoef(u[:-1], u[1:])[0, 1]
    r1 = MRG32k3a(99); r2 = MRG32k3a(99); r3 = MRG32k3a(100)
    a = [r1.next() for _ in range(1000)]; b = [r2.next() for _ in range(1000)]; c = [r3.next() for _ in range(1000)]
    R["E1"] = {
        "n": n, "mean": u.mean(), "var": u.var(), "chi2": chi.statistic, "chi2_p": chi.pvalue,
        "ks_p": ks.pvalue, "lag1": ac, "min": u.min(), "max": u.max(),
        "repro": a == b, "distinct": a != c,
        "ok_mean": abs(u.mean() - 0.5) < 3 * math.sqrt(1 / 12 / n),
        "ok_var": abs(u.var() - 1 / 12) < 3 * math.sqrt(1 / 180 / n),
        "ok_chi": chi.pvalue > 0.01, "ok_ks": ks.pvalue > 0.01, "ok_ac": abs(ac) < 3 / math.sqrt(n),
    }


# ------------------------------------------------------------------ E2 distribuciones
DISTS = [
    ("Normal(100; 10)", "normal", [100, 10], stats.norm(100, 10)),
    ("Triangular(10; 20; 40)", "triangular", [10, 20, 40], stats.triang(1 / 3, loc=10, scale=30)),
    ("PERT(10; 20; 40)", "pert", [10, 20, 40], stats.beta(1 + 4 * 10 / 30, 1 + 4 * 20 / 30, loc=10, scale=30)),
    ("Uniforme(5; 15)", "uniforme", [5, 15], stats.uniform(5, 10)),
    ("Lognormal(100; 20)", "lognormal", [100, 20], None),
    ("Weibull(2; 50)", "weibull", [2, 50], stats.weibull_min(2, scale=50)),
    ("Exponencial(8)", "exponencial", [8], stats.expon(scale=8)),
    ("Gamma(2; 3)", "gamma", [2, 3], stats.gamma(2, scale=3)),
    ("Beta(2; 5; 0; 10)", "beta", [2, 5, 0, 10], stats.beta(2, 5, loc=0, scale=10)),
    ("Poisson(4)", "poisson", [4], stats.poisson(4)),
    ("Binomial(10; 0,3)", "binomial", [10, 0.3], stats.binom(10, 0.3)),
    ("Bernoulli(0,25)", "bernoulli", [0.25], stats.bernoulli(0.25)),
    ("Discreta({1;2;3}; {0,2;0,5;0,3})", "discreta", [[1, 2, 3], [0.2, 0.5, 0.3]], stats.rv_discrete(values=([1, 2, 3], [0.2, 0.5, 0.3]))),
]
s2 = math.log(1 + 0.2 ** 2); DISTS[4] = DISTS[4][:3] + (stats.lognorm(math.sqrt(s2), scale=math.exp(math.log(100) - s2 / 2)),)


def e2():
    n = 100_000
    rows = []
    for k, (lab, t, p, dist) in enumerate(DISTS):
        r = MRG32k3a(1000 + k)
        u = generar_u(r, 1, n, True)[0]
        x = np.array([inv_cdf(t, ui, p) for ui in u]); xs = np.sort(x)
        mt, st = dist.mean(), dist.std()
        discrete = t in ("poisson", "binomial", "bernoulli", "discreta")
        row = {"lab": lab, "mean_t": mt, "mean_s": x.mean(), "sd_t": st, "sd_s": x.std(ddof=1),
               "static": valor_esperado(t, p)}
        for q in (0.05, 0.5, 0.95):
            row["p%d_t" % round(q * 100)] = dist.ppf(q)
            row["p%d_s" % round(q * 100)] = percentil(xs, q)
        if discrete:
            vals = np.unique(xs)
            row["fit"] = max(abs((x == v).mean() - dist.pmf(v)) for v in vals)
            row["fit_lab"] = "máx |P(X=k) sim − teor|"
            ok_q = all(abs(row["p%d_s" % q] - row["p%d_t" % q]) < 1e-9 for q in (5, 50, 95))
        else:
            row["fit"] = stats.kstest(x, dist.cdf).statistic
            row["fit_lab"] = "Kolmogorov-Smirnov D"
            ok_q = all(abs(row["p%d_s" % q] - row["p%d_t" % q]) <= 0.002 * st + 1e-9 for q in (5, 50, 95))
        row["ok"] = (abs(row["mean_s"] - mt) <= 0.002 * st) and (abs(row["sd_s"] - st) <= 0.005 * st) and ok_q and abs(row["static"] - mt) < 1e-6 * max(1, abs(mt))
        rows.append(row)
    R["E2"] = {"n": n, "rows": rows}


# ------------------------------------------------------------------ E3-E5 modelos con solucion cerrada
def e3():
    n = 10_000
    X, Y = simular([("normal", [100, 10]), ("normal", [50, 5])], lambda x, s: {"Z": x[0] + x[1]}, n, 2026)
    z = np.array(Y[0]["Z"]); zs = np.sort(z)
    sd_t = math.sqrt(125)
    R["E3"] = {"n": n, "mean": z.mean(), "sd": z.std(ddof=1), "sd_t": sd_t,
               "p5": percentil(zs, .05), "p5_t": 150 - 1.6448536 * sd_t, "p95": percentil(zs, .95), "p95_t": 150 + 1.6448536 * sd_t,
               "pz": (z <= 160).mean(), "pz_t": stats.norm.cdf(10 / sd_t),
               "skew": stats.skew(z), "kurt": stats.kurtosis(z, fisher=False)}
    e = R["E3"]
    e["se_sd"] = sd_t * math.sqrt(2 / (4 * n))
    e["ok"] = abs(e["mean"] - 150) < 3 * sd_t / math.sqrt(n) and abs(e["sd"] - sd_t) < 3 * e["se_sd"] and abs(e["pz"] - e["pz_t"]) < 0.01 and abs(e["skew"]) < 0.1 and abs(e["kurt"] - 3) < 0.2


def e4():
    n = 10_000
    X, Y = simular([("bernoulli", [0.25]), ("pert", [20000, 45000, 90000])], lambda x, s: {"C": x[0] * x[1]}, n, 77)
    c = np.array(Y[0]["C"]); cs = np.sort(c)
    pert = stats.beta(1 + 4 * 25000 / 70000, 1 + 4 * 45000 / 70000, loc=20000, scale=70000)
    m_t = 0.25 * pert.mean(); var_t = 0.25 * (pert.var() + pert.mean() ** 2) - m_t ** 2
    R["E4"] = {"n": n, "mean": c.mean(), "mean_t": m_t, "sd": c.std(ddof=1), "sd_t": math.sqrt(var_t),
               "p_occ": (c > 0).mean(), "p75": percentil(cs, .75), "p80": percentil(cs, .80), "static": 0.25 * valor_esperado("pert", [20000, 45000, 90000])}
    e = R["E4"]; e["ok"] = abs(e["mean"] - m_t) < 0.01 * m_t and abs(e["p_occ"] - 0.25) < 1e-9 and e["p75"] == 0 and e["p80"] > 0


def e5():
    n = 10_000
    X, Y = simular([("normal", [1000, 100]), ("triangular", [9, 11, 14])], lambda x, s: {"I": x[0] * x[1]}, n, 5)
    v = np.array(Y[0]["I"])
    tri = stats.triang((11 - 9) / 5, loc=9, scale=5)
    EQ, VQ, EP, VP = 1000, 100 ** 2, tri.mean(), tri.var()
    m_t = EQ * EP; var_t = (VQ + EQ ** 2) * (VP + EP ** 2) - m_t ** 2
    R["E5"] = {"n": n, "mean": v.mean(), "mean_t": m_t, "sd": v.std(ddof=1), "sd_t": math.sqrt(var_t)}
    e = R["E5"]
    e["se_sd"] = e["sd_t"] * math.sqrt((stats.kurtosis(v, fisher=False) - 1) / (4 * n))
    e["ok"] = abs(e["mean"] - m_t) < 3 * e["sd_t"] / math.sqrt(n) and abs(e["sd"] - e["sd_t"]) < 3 * e["se_sd"]


# ------------------------------------------------------------------ E6 sensibilidad (modelo lineal)
COEF = [3, -2, 0.5, 10]
SENS_IN = [("normal", [10, 2]), ("uniforme", [0, 6]), ("triangular", [0, 5, 10]), ("bernoulli", [0.3])]


def e6():
    n = 5000
    X, Y = simular(SENS_IN, lambda x, s: {"Y": sum(a * b for a, b in zip(COEF, x))}, n, 314)
    xs = [np.array(c) for c in X[0]]; y = np.array(Y[0]["Y"])
    sig = [2, 6 / math.sqrt(12), math.sqrt((0 + 100 + 25 - 0 - 0 - 50) / 18), math.sqrt(0.3 * 0.7)]
    sy = math.sqrt(sum((a * s) ** 2 for a, s in zip(COEF, sig)))
    beta_t = [a * s / sy for a, s in zip(COEF, sig)]
    Z = np.column_stack([(c - c.mean()) / c.std(ddof=1) for c in xs]); zy = (y - y.mean()) / y.std(ddof=1)
    beta_np, *_ = np.linalg.lstsq(Z, zy, rcond=None)
    rho = [stats.spearmanr(c, y).statistic for c in xs]
    # cambio en la media por deciles (misma definicion que el visor) y teoria para X1 normal
    def deciles(c):
        idx = np.argsort(c, kind="stable"); res = []
        for b in range(10):
            a0, a1 = b * n // 10, (b + 1) * n // 10; res.append(y[idx[a0:a1]].mean())
        return res
    dec = [deciles(c) for c in xs]
    phi = stats.norm.pdf(stats.norm.ppf(0.9)) / 0.1
    chg1_t = COEF[0] * (2 * 2 * phi)
    R["E6"] = {"n": n, "beta_t": beta_t, "beta_np": list(beta_np), "rho": rho, "sy_t": sy, "sy": y.std(ddof=1),
               "chg1": dec[0][-1] - dec[0][0], "chg1_t": chg1_t, "dec": dec, "X": [list(c) for c in xs], "y": list(y)}
    R["E6"]["ok"] = max(abs(a - b) for a, b in zip(beta_np, beta_t)) < 0.02 and abs(R["E6"]["chg1"] - chg1_t) / abs(chg1_t) < 0.03


# ------------------------------------------------------------------ E7 hipercubo latino vs Monte Carlo
def e7():
    n, reps = 500, 300
    sims = {}
    for lhs in (False, True):
        means, p95 = [], []
        for rep in range(reps):
            X, Y = simular([("normal", [1000, 100]), ("triangular", [9, 11, 14])], lambda x, s: {"I": x[0] * x[1]}, n, 10_000 + rep, lhs=lhs)
            v = np.sort(Y[0]["I"]); means.append(v.mean()); p95.append(percentil(v, .95))
        sims[lhs] = (np.std(means, ddof=1), np.std(p95, ddof=1))
    r = MRG32k3a(5); U = generar_u(r, 3, 1000, True)
    strat = all(sorted(int(u * 1000) for u in col) == list(range(1000)) for col in U)
    sd_t = R["E5"]["sd_t"]
    R["E7"] = {"n": n, "reps": reps, "se_theory": sd_t / math.sqrt(n), "se_mc": sims[False][0], "se_lhs": sims[True][0],
               "p95_mc": sims[False][1], "p95_lhs": sims[True][1], "strat": strat}
    e = R["E7"]; e["vr_mean"] = (e["se_mc"] / e["se_lhs"]) ** 2; e["vr_p95"] = (e["p95_mc"] / e["p95_lhs"]) ** 2
    e["ok"] = strat and abs(e["se_mc"] - e["se_theory"]) / e["se_theory"] < 0.15 and e["vr_mean"] > 1.5


# ------------------------------------------------------------------ E8 convergencia y cobertura del IC 90%
def e8():
    reps = 1000; cov = {}
    for n in (100, 1000):
        hits = 0
        for rep in range(reps):
            X, Y = simular([("exponencial", [8])], lambda x, s: {"X": x[0]}, n, 50_000 + rep + n, lhs=False)
            v = np.array(Y[0]["X"]); h = Z90 * v.std(ddof=1) / math.sqrt(n)
            hits += abs(v.mean() - 8) <= h
        cov[n] = hits / reps
    se = []
    for n in (100, 400, 1600, 6400):
        ests = [np.mean(simular([("exponencial", [8])], lambda x, s: {"X": x[0]}, n, 90_000 + rep, lhs=False)[1][0]["X"]) for rep in range(200)]
        se.append((n, float(np.std(ests, ddof=1)), 8 / math.sqrt(n)))
    R["E8"] = {"cov": cov, "se": se, "ok": all(abs(c - 0.90) < 0.03 for c in cov.values()) and all(abs(a - b) / b < 0.15 for _, a, b in se)}


# ------------------------------------------------------------------ E9 estadisticos del visor (JavaScript) vs scipy
async def e9(viewer_path):
    from playwright.async_api import async_playwright
    E = R["E6"]
    data = {"meta": {"app": "SimRiesgo", "ver": "1.0", "model": "validacion.xlsx", "date": "11/11/2026", "iter": E["n"], "sims": 1,
                     "sampling": "Hipercubo latino", "seed": 314, "elapsed": 1.0}, "simNames": ["Simulación 1"],
            "inputs": [{"n": "X%d" % (j + 1), "c": "V!B%d" % (j + 1), "d": "", "v": [E["X"][j]]} for j in range(4)],
            "outputs": [{"n": "Y", "c": "V!C1", "g": "", "v": [E["y"]]}]}
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import build
    tpl = build.ascii_template(open(build.VISOR, encoding="utf-8").read())
    open(viewer_path, "w").write(tpl.replace("__SR_DATA__", json.dumps(data)))
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        pg = await b.new_page(); await pg.goto("file://" + viewer_path)
        js = await pg.evaluate("""() => {
            const s = series('o0', 0), st = s.st, sd = sensData('o0', 0);
            const ps = [0.01,0.05,0.25,0.5,0.75,0.95,0.99].map(p => pct(s.sorted, p));
            const thr = [0, 30, 50];
            return {st: st, ps: ps, cdf: thr.map(x => cdfLE(s.sorted, x)), R2: sd.R2,
                    items: sd.items.map(it => ({beta: it.beta, rho: it.rho, cvar: it.cvar, bins: it.bins}))};
        }""")
        await b.close()
    y = np.array(E["y"]); ys = np.sort(y)
    ref = {"mean": y.mean(), "sd": y.std(ddof=1), "skew": stats.skew(y), "kurt": stats.kurtosis(y, fisher=False), "min": y.min(), "max": y.max()}
    rows = []
    for k, lab in [("mean", "Media"), ("sd", "Desviación estándar"), ("skew", "Asimetría"), ("kurt", "Curtosis"), ("min", "Mínimo"), ("max", "Máximo")]:
        rows.append((lab, js["st"][k], ref[k]))
    for q, v in zip([1, 5, 25, 50, 75, 95, 99], js["ps"]):
        rows.append(("Percentil %d%%" % q, v, float(np.quantile(y, q / 100, method="inverted_cdf"))))
    for x, v in zip([0, 30, 50], js["cdf"]):
        rows.append(("P(Y ≤ %d)" % x, v, float((y <= x).mean())))
    for j, it in enumerate(js["items"]):
        rows.append(("Coef. regresión X%d" % (j + 1), it["beta"], E["beta_np"][j]))
        rows.append(("Spearman X%d" % (j + 1), it["rho"], E["rho"][j]))
    for j, it in enumerate(js["items"]):
        rows.append(("Cambio en la media X%d" % (j + 1), it["bins"][-1] - it["bins"][0], E["dec"][j][-1] - E["dec"][j][0]))
    rows.append(("R² de la regresión", js["R2"], 1.0))
    err = max(abs(a - b) / max(1e-12, abs(b), 1e-6) if b != 0 else abs(a) for _, a, b in rows)
    R["E9"] = {"rows": rows, "max_rel_err": err, "ok": err < 1e-6}


if __name__ == "__main__":
    import time
    t = time.time()
    for f in (e1, e2, e3, e4, e5, e6, e7, e8):
        f(); print(f.__name__, "ok" if R[f.__name__.upper()].get("ok", True) else "FALLA", round(time.time() - t, 1), flush=True)
    asyncio.run(e9(sys.argv[1] if len(sys.argv) > 1 else "/tmp/visor_val.html"))
    print("E9", R["E9"]["ok"], R["E9"]["max_rel_err"])
    R["E6"].pop("X"); R["E6"].pop("y")
    def conv(o):
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, (np.bool_,)): return bool(o)
        if isinstance(o, (np.integer,)): return int(o)
        raise TypeError(type(o))
    json.dump(R, open(os.path.join(os.path.dirname(__file__), "resultados.json"), "w"), default=conv, indent=1, ensure_ascii=False)
