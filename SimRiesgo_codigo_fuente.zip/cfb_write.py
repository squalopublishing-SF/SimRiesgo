"""Escritor minimo de archivos Compound File Binary (MS-CFB v3, sectores de 512 bytes).

Uso: write_cfb(path, tree) con tree = {"VBA": {"dir": b"...", ...}, "PROJECT": b"..."}
(dict = almacenamiento, bytes = flujo). Arbol rojo-negro valido por cada nivel.
"""
import struct

SECTOR = 512
MINI = 64
CUTOFF = 4096
FREESECT, ENDOFCHAIN, FATSECT, DIFSECT, NOSTREAM = 0xFFFFFFFF, 0xFFFFFFFE, 0xFFFFFFFD, 0xFFFFFFFC, 0xFFFFFFFF


class Entry:
    def __init__(self, name, kind, data=None, children=None):
        self.name, self.kind, self.data = name, kind, data
        self.children = children or []
        self.left = self.right = self.child = NOSTREAM
        self.color = 1
        self.start, self.size = ENDOFCHAIN, 0
        self.sid = None


def _key(e):
    return (len(e.name), e.name.upper())


def _build_tree(entries):
    """Arbol binario balanceado; colorea de rojo el ultimo nivel si esta incompleto."""
    entries = sorted(entries, key=_key)
    depth = {}

    def rec(lo, hi, d):
        if lo > hi:
            return NOSTREAM, None
        mid = (lo + hi) // 2
        e = entries[mid]
        depth[id(e)] = d
        l, _ = rec(lo, mid - 1, d + 1)
        r, _ = rec(mid + 1, hi, d + 1)
        e.left, e.right = l, r
        return e.sid, e

    root_sid, _ = rec(0, len(entries) - 1, 0)
    if entries:
        maxd = max(depth.values())
        full = all(sum(1 for v in depth.values() if v == d) == 2 ** d for d in range(maxd + 1))
        for e in entries:
            e.color = 0 if (not full and depth[id(e)] == maxd and maxd > 0) else 1
    return root_sid


def _check_rb(entries_by_sid, sid):
    """Devuelve la altura negra; falla si el arbol no es rojo-negro valido."""
    if sid == NOSTREAM:
        return 1
    e = entries_by_sid[sid]
    lh = _check_rb(entries_by_sid, e.left)
    rh = _check_rb(entries_by_sid, e.right)
    assert lh == rh, "altura negra distinta en " + e.name
    if e.color == 0:
        for c in (e.left, e.right):
            if c != NOSTREAM:
                assert entries_by_sid[c].color == 1, "rojo con hijo rojo"
    return lh + (1 if e.color == 1 else 0)


def write_cfb(path, tree):
    # 1. entradas de directorio (orden de ids: preorden)
    root = Entry("Root Entry", 5)
    all_entries = [root]

    def add(parent, d):
        for name, v in d.items():
            if isinstance(v, dict):
                e = Entry(name, 1)
                e.sid = len(all_entries); all_entries.append(e)
                parent.children.append(e)
                add(e, v)
            else:
                e = Entry(name, 2, bytes(v))
                e.sid = len(all_entries); all_entries.append(e)
                parent.children.append(e)
    root.sid = 0
    add(root, tree)
    for e in all_entries:
        if e.kind in (1, 5):
            e.child = _build_tree(e.children)
    by_sid = {e.sid: e for e in all_entries}
    for e in all_entries:
        if e.kind in (1, 5):
            _check_rb(by_sid, e.child)

    # 2. ministream (flujos pequenos)
    mini = bytearray()
    minifat = []
    for e in all_entries:
        if e.kind == 2 and len(e.data) < CUTOFF:
            e.size = len(e.data)
            if e.size == 0:
                e.start = ENDOFCHAIN
                continue
            n = (len(e.data) + MINI - 1) // MINI
            first = len(minifat)
            for i in range(n):
                minifat.append(first + i + 1 if i < n - 1 else ENDOFCHAIN)
            e.start = first
            mini += e.data + b"\0" * (n * MINI - len(e.data))

    # 3. sectores regulares: [flujos grandes][ministream][minifat][directorio][FAT]
    sectors = []          # lista de bloques de 512 bytes
    fat = []

    def alloc(data):
        if not data:
            return ENDOFCHAIN
        n = (len(data) + SECTOR - 1) // SECTOR
        first = len(sectors)
        for i in range(n):
            sectors.append(bytes(data[i * SECTOR:(i + 1) * SECTOR]).ljust(SECTOR, b"\0"))
            fat.append(first + i + 1 if i < n - 1 else ENDOFCHAIN)
        return first

    for e in all_entries:
        if e.kind == 2 and len(e.data) >= CUTOFF:
            e.size = len(e.data)
            e.start = alloc(e.data)
    root.start = alloc(bytes(mini)) if mini else ENDOFCHAIN
    root.size = len(mini)
    minifat_bytes = b"".join(struct.pack("<I", v) for v in minifat)
    if minifat_bytes:
        minifat_bytes += struct.pack("<I", FREESECT) * ((SECTOR - len(minifat_bytes) % SECTOR) % SECTOR // 4)
    minifat_start = alloc(minifat_bytes) if minifat_bytes else ENDOFCHAIN
    n_minifat = len(minifat_bytes) // SECTOR

    # directorio
    dirb = bytearray()
    for e in all_entries:
        nm = e.name.encode("utf-16-le")
        assert len(nm) <= 62, e.name
        rec = nm.ljust(64, b"\0")
        rec += struct.pack("<HBB", len(nm) + 2, e.kind, e.color)
        rec += struct.pack("<III", e.left, e.right, e.child)
        rec += b"\0" * 16 + b"\0" * 4 + b"\0" * 16
        rec += struct.pack("<IQ", e.start if e.kind != 1 else 0, e.size if e.kind != 1 else 0)
        assert len(rec) == 128
        dirb += rec
    while len(dirb) % SECTOR:
        dirb += (b"\0" * 64 + struct.pack("<HBB", 0, 0, 0) + struct.pack("<III", NOSTREAM, NOSTREAM, NOSTREAM) + b"\0" * 52)
    dir_start = alloc(bytes(dirb))

    # FAT (se autodescribe); hasta 109 sectores de FAT sin DIFAT
    nfat = 1
    while True:
        total = len(sectors) + nfat
        if (total + 127) // 128 <= nfat:
            break
        nfat += 1
    assert nfat <= 109, "archivo demasiado grande para este escritor"
    fat_start = len(sectors)
    for i in range(nfat):
        fat.append(FATSECT)
    fat += [FREESECT] * (nfat * 128 - len(fat))
    fat_bytes = b"".join(struct.pack("<I", v) for v in fat)
    for i in range(nfat):
        sectors.append(fat_bytes[i * SECTOR:(i + 1) * SECTOR])

    hdr = bytearray()
    hdr += bytes.fromhex("D0CF11E0A1B11AE1") + b"\0" * 16
    hdr += struct.pack("<HHHHH", 0x3E, 3, 0xFFFE, 9, 6) + b"\0" * 6
    hdr += struct.pack("<IIIIIIIII", 0, nfat, dir_start, 0, CUTOFF, minifat_start, n_minifat, ENDOFCHAIN, 0)
    difat = [fat_start + i for i in range(nfat)] + [FREESECT] * (109 - nfat)
    hdr += b"".join(struct.pack("<I", v) for v in difat)
    assert len(hdr) == 512
    with open(path, "wb") as f:
        f.write(hdr)
        for s in sectors:
            f.write(s)
