Attribute VB_Name = "modSRVisor"
Option Explicit

' ============================================================
'  SimRiesgo - Generacion del visor interactivo de resultados (HTML)
' ============================================================

Private Const MARCA As String = "__SR_DATA__"

Public Sub SR_AbrirVisor(Optional ByVal regenerar As Boolean = False)
    Dim ruta As String
    If Not ActiveWorkbook Is Nothing Then
        AsegurarResultados ActiveWorkbook
    End If
    If Not gHasResults Then
        MsgBox "Todavia no hay resultados. Ejecute primero una simulacion.", vbInformation, SR_APP
        Exit Sub
    End If
    If Not regenerar And Len(gLastViewer) > 0 Then
        If Len(Dir$(gLastViewer)) > 0 Then
            AbrirArchivo gLastViewer
            Exit Sub
        End If
    End If
    Application.StatusBar = SR_APP & ": preparando el visor de resultados..."
    ruta = GenerarVisor()
    Application.StatusBar = False
    If Len(ruta) > 0 Then
        gLastViewer = ruta
        AbrirArchivo ruta
    End If
End Sub

Private Function GenerarVisor() As String
    Dim plantilla As String, p As Long, json As String, carpeta As String, ruta As String
    On Error GoTo falla
    plantilla = LeerPlantilla()
    p = InStr(1, plantilla, MARCA, vbBinaryCompare)
    If p = 0 Then
        MsgBox "No se encontro la plantilla del visor en el complemento.", vbCritical, SR_APP
        Exit Function
    End If
    json = ConstruirJson()
    carpeta = Environ$("TEMP") & "\SimRiesgo"
    If Len(Dir$(carpeta, vbDirectory)) = 0 Then MkDir carpeta
    ruta = carpeta & "\" & NombreSeguro(gModelName) & "_" & Format$(gSimDate, "yyyymmdd_hhnnss") & ".html"
    EscribirTexto ruta, Left$(plantilla, p - 1) & json & Mid$(plantilla, p + Len(MARCA))
    GenerarVisor = ruta
    Exit Function
falla:
    Application.StatusBar = False
    MsgBox "No se pudo generar el visor: " & Err.Description, vbCritical, SR_APP
    GenerarVisor = ""
End Function

Private Function LeerPlantilla() As String
    Dim ws As Worksheet, n As Long, i As Long, partes() As String
    Set ws = ThisWorkbook.Worksheets("SRVisor")
    n = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    ReDim partes(1 To n)
    For i = 1 To n
        partes(i) = CStr(ws.Cells(i, 1).Value)
        partes(i) = Mid$(partes(i), 2, Len(partes(i)) - 2)
    Next i
    LeerPlantilla = Join(partes, "")
End Function

Private Sub EscribirTexto(ByVal ruta As String, ByVal txt As String)
    Dim f As Integer
    f = FreeFile
    Open ruta For Output As #f
    Print #f, txt;
    Close #f
End Sub

Public Sub AbrirArchivo(ByVal ruta As String)
    On Error Resume Next
    CreateObject("Shell.Application").ShellExecute ruta, "", "", "open", 1
    If Err.Number <> 0 Then
        Err.Clear
        ThisWorkbook.FollowHyperlink ruta
    End If
End Sub

Private Function NombreSeguro(ByVal s As String) As String
    Dim i As Long, ch As String, r As String
    If InStrRev(s, ".") > 1 Then s = Left$(s, InStrRev(s, ".") - 1)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch Like "[A-Za-z0-9_-]" Then r = r & ch Else r = r & "_"
    Next i
    If Len(r) = 0 Then r = "modelo"
    NombreSeguro = Left$(r, 60)
End Function

' ------------------------------------------------------------
'  JSON
' ------------------------------------------------------------
Public Function NumJ(ByVal x As Double) As String
    Dim s As String
    s = Trim$(Str$(x))
    If Left$(s, 1) = "." Then s = "0" & s
    If Left$(s, 2) = "-." Then s = "-0" & Mid$(s, 2)
    NumJ = s
End Function

Public Function JsonStr(ByVal s As String) As String
    Dim i As Long, ch As Long, partes() As String, n As Long
    n = Len(s)
    If n = 0 Then
        JsonStr = """"""
        Exit Function
    End If
    ReDim partes(1 To n)
    For i = 1 To n
        ch = AscW(Mid$(s, i, 1))
        If ch < 0 Then ch = ch + 65536
        Select Case ch
            Case 34: partes(i) = "\"""
            Case 92: partes(i) = "\\"
            Case 60, 62, 38: partes(i) = "\u" & Right$("000" & Hex$(ch), 4)
            Case 32 To 126: partes(i) = ChrW$(ch)
            Case Else: partes(i) = "\u" & Right$("000" & Hex$(ch), 4)
        End Select
    Next i
    JsonStr = """" & Join(partes, "") & """"
End Function

Private Function SerieJson(ByVal esSalida As Boolean, ByVal s As Long, ByVal idx As Long) As String
    Dim a() As String, i As Long
    ReDim a(1 To gItersDone)
    For i = 1 To gItersDone
        If esSalida Then
            If gOutErr(s, idx, i) = 1 Then
                a(i) = "null"
            Else
                a(i) = NumJ(gOutVals(s, idx, i))
            End If
        Else
            a(i) = NumJ(gInVals(s, idx, i))
        End If
    Next i
    SerieJson = "[" & Join(a, ",") & "]"
End Function

Private Function ConstruirJson() As String
    Dim partes() As String, n As Long, j As Long, s As Long, sims() As String

    ReDim partes(1 To 16 + 2 * (rInCount + rOutCount))
    n = 0

    n = n + 1
    partes(n) = "{""meta"":{""app"":" & JsonStr(SR_APP) & ",""ver"":" & JsonStr(SR_VER) & _
        ",""model"":" & JsonStr(gModelName) & _
        ",""date"":" & JsonStr(Format$(gSimDate, "dd/mm/yyyy hh:nn")) & _
        ",""iter"":" & gItersDone & ",""sims"":" & gSimsDone & _
        ",""sampling"":" & JsonStr(gSampling) & ",""seed"":" & NumJ(gSeedUsed) & _
        ",""elapsed"":" & NumJ(Round(gElapsed, 2)) & _
        ",""conv"":{""used"":" & IIf(gConvUsada, "true", "false") & ",""tol"":" & NumJ(gConvTol) & _
        ",""reached"":" & IIf(gConvAlcanzada, "true", "false") & "}" & _
        ",""corr"":[" & rCorrJson & "]},"

    ReDim sims(1 To gSimsDone)
    For s = 1 To gSimsDone
        sims(s) = JsonStr("Simulaci" & ChrW$(243) & "n " & s)
    Next s
    n = n + 1
    partes(n) = """simNames"":[" & Join(sims, ",") & "],"

    n = n + 1
    partes(n) = """inputs"":["
    For j = 1 To rInCount
        n = n + 1
        If n + 4 > UBound(partes) Then ReDim Preserve partes(1 To UBound(partes) + 32)
        partes(n) = IIf(j > 1, ",", "") & "{""n"":" & JsonStr(rInName(j)) & ",""c"":" & JsonStr(rInCell(j)) & _
                    ",""d"":" & JsonStr(rInDist(j)) & ",""v"":[" & SeriesSims(False, j) & "]}"
    Next j
    n = n + 1
    partes(n) = "],""outputs"":["
    For j = 1 To rOutCount
        n = n + 1
        If n + 4 > UBound(partes) Then ReDim Preserve partes(1 To UBound(partes) + 32)
        partes(n) = IIf(j > 1, ",", "") & "{""n"":" & JsonStr(rOutName(j)) & ",""c"":" & JsonStr(rOutCell(j)) & _
                    ",""g"":" & JsonStr(rOutGroup(j)) & ",""v"":[" & SeriesSims(True, j) & "]}"
    Next j
    n = n + 1
    partes(n) = "]}"
    ReDim Preserve partes(1 To n)
    ConstruirJson = Join(partes, "")
End Function

Private Function SeriesSims(ByVal esSalida As Boolean, ByVal idx As Long) As String
    Dim a() As String, s As Long
    ReDim a(1 To gSimsDone)
    For s = 1 To gSimsDone
        a(s) = SerieJson(esSalida, s, idx)
    Next s
    SeriesSims = Join(a, ",")
End Function
