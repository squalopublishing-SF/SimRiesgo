Attribute VB_Name = "modSRVentana"
Option Explicit

' ============================================================
'  SimRiesgo - Ventana "Definir distribucion" (hoja de trabajo temporal con vista previa)
' ============================================================

Public Const HOJA_DIST As String = "SR Distribucion"
Private Const NPUNTOS As Long = 120
Private gDistDestino As Range

' ------------------------------------------------------------
'  Catalogo de distribuciones parametricas
' ------------------------------------------------------------
Public Function CatalogoNombres() As Variant
    CatalogoNombres = Array("Normal", "Triangular", "PERT", "Uniforme", "Lognormal", "Weibull", "Exponencial", _
        "Gamma", "Beta", "Poisson", "Binomial", "Bernoulli", "Log-log" & ChrW$(237) & "stica", "Pearson V", "Normal truncada")
End Function

Public Function CatalogoFuncion(ByVal i As Long) As String
    CatalogoFuncion = Choose(i + 1, "SRNormal", "SRTriangular", "SRPert", "SRUniforme", "SRLognormal", "SRWeibull", _
        "SRExponencial", "SRGamma", "SRBeta", "SRPoisson", "SRBinomial", "SRBernoulli", "SRLogLogistica", "SRPearson5", "SRNormalTrunc")
End Function

Public Function CatalogoCodigo(ByVal i As Long) As Long
    CatalogoCodigo = Choose(i + 1, D_NORMAL, D_TRIANG, D_PERT, D_UNIF, D_LOGN, D_WEIB, D_EXPO, D_GAMMA, D_BETA, _
        D_POIS, D_BINOM, D_BERN, D_LOGLOG, D_PEARSON5, D_NTRUNC)
End Function

Public Function CatalogoIndice(ByVal nombre As String) As Long
    Dim v As Variant, i As Long
    v = CatalogoNombres()
    CatalogoIndice = -1
    For i = 0 To UBound(v)
        If StrComp(v(i), nombre, vbTextCompare) = 0 Or StrComp(CatalogoFuncion(i), nombre, vbTextCompare) = 0 Then
            CatalogoIndice = i
            Exit Function
        End If
    Next i
End Function

Public Function EtiquetasParam(ByVal t As Long) As Variant
    Dim mn As String, mx As String, mp As String, ds As String
    mn = "M" & ChrW$(237) & "nimo"
    mx = "M" & ChrW$(225) & "ximo"
    mp = "M" & ChrW$(225) & "s probable"
    ds = "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar"
    Select Case t
        Case D_NORMAL, D_LOGN: EtiquetasParam = Array("Media", ds)
        Case D_TRIANG, D_PERT: EtiquetasParam = Array(mn, mp, mx)
        Case D_UNIF: EtiquetasParam = Array(mn, mx)
        Case D_WEIB, D_GAMMA: EtiquetasParam = Array("Forma", "Escala")
        Case D_EXPO: EtiquetasParam = Array("Media")
        Case D_BETA: EtiquetasParam = Array("Alfa 1", "Alfa 2", mn, mx)
        Case D_POIS: EtiquetasParam = Array("Lambda (media)")
        Case D_BINOM: EtiquetasParam = Array("Ensayos (n)", "Probabilidad (p)")
        Case D_BERN: EtiquetasParam = Array("Probabilidad (p)")
        Case D_LOGLOG: EtiquetasParam = Array("Escala", "Forma", "Ubicaci" & ChrW$(243) & "n")
        Case D_PEARSON5: EtiquetasParam = Array("Alfa (forma)", "Beta (escala)", "Ubicaci" & ChrW$(243) & "n")
        Case D_NTRUNC: EtiquetasParam = Array("Media (normal original)", ds & " (original)", mn, mx)
    End Select
End Function

' Parametros por defecto en torno a un valor de referencia v
Public Function DefectoParam(ByVal t As Long, ByVal v As Double) As Variant
    Dim a As Double
    If v = 0 Then v = 100
    a = Abs(v)
    Select Case t
        Case D_NORMAL: DefectoParam = Array(v, a * 0.1)
        Case D_LOGN: DefectoParam = Array(a, a * 0.1)
        Case D_TRIANG, D_PERT: DefectoParam = Array(v - a * 0.1, v, v + a * 0.2)
        Case D_UNIF: DefectoParam = Array(v - a * 0.1, v + a * 0.1)
        Case D_WEIB: DefectoParam = Array(2, a * 1.128)
        Case D_GAMMA: DefectoParam = Array(4, a / 4)
        Case D_EXPO: DefectoParam = Array(a)
        Case D_BETA: DefectoParam = Array(2, 3, v - a * 0.2, v + a * 0.3)
        Case D_POIS: DefectoParam = Array(IIf(a > 1000, 10, a))
        Case D_BINOM: DefectoParam = Array(10, 0.5)
        Case D_BERN: DefectoParam = Array(0.3)
        Case D_LOGLOG: DefectoParam = Array(a, 4, 0)
        Case D_PEARSON5: DefectoParam = Array(4, a * 3, 0)
        Case D_NTRUNC: DefectoParam = Array(v, a * 0.1, v - a * 0.15, v + a * 0.15)
    End Select
End Function

' Devuelve "" si los parametros son validos o un mensaje explicando el problema
Public Function ValidarParametros(ByVal t As Long, ByRef p() As Double) As String
    Dim m As String
    Select Case t
        Case D_NORMAL: If p(2) <= 0 Then m = "La desviaci" & ChrW$(243) & "n debe ser mayor que 0."
        Case D_LOGN: If p(1) <= 0 Or p(2) <= 0 Then m = "La media y la desviaci" & ChrW$(243) & "n deben ser mayores que 0."
        Case D_TRIANG, D_PERT
            If Not (p(1) < p(3) And p(1) <= p(2) And p(2) <= p(3)) Then m = "Debe cumplirse m" & ChrW$(237) & "nimo " & ChrW$(8804) & " m" & ChrW$(225) & "s probable " & ChrW$(8804) & " m" & ChrW$(225) & "ximo (con m" & ChrW$(237) & "nimo < m" & ChrW$(225) & "ximo)."
        Case D_UNIF: If p(1) >= p(2) Then m = "El m" & ChrW$(237) & "nimo debe ser menor que el m" & ChrW$(225) & "ximo."
        Case D_WEIB, D_GAMMA: If p(1) <= 0 Or p(2) <= 0 Then m = "Forma y escala deben ser mayores que 0."
        Case D_EXPO: If p(1) <= 0 Then m = "La media debe ser mayor que 0."
        Case D_BETA: If p(1) <= 0 Or p(2) <= 0 Or p(3) >= p(4) Then m = "Alfas > 0 y m" & ChrW$(237) & "nimo < m" & ChrW$(225) & "ximo."
        Case D_POIS: If p(1) <= 0 Then m = "Lambda debe ser mayor que 0."
        Case D_BINOM: If p(1) < 1 Or p(1) <> Int(p(1)) Or p(2) < 0 Or p(2) > 1 Then m = "n entero " & ChrW$(8805) & " 1 y p entre 0 y 1."
        Case D_BERN: If p(1) < 0 Or p(1) > 1 Then m = "p debe estar entre 0 y 1."
        Case D_LOGLOG: If p(1) <= 0 Or p(2) <= 0 Then m = "Escala y forma deben ser mayores que 0."
        Case D_PEARSON5: If p(1) <= 0 Or p(2) <= 0 Then m = "Alfa y beta deben ser mayores que 0."
        Case D_NTRUNC: If p(2) <= 0 Or p(3) >= p(4) Then m = "Desviaci" & ChrW$(243) & "n > 0 y m" & ChrW$(237) & "nimo < m" & ChrW$(225) & "ximo."
    End Select
    ValidarParametros = m
End Function

' ------------------------------------------------------------
'  Abrir la ventana
' ------------------------------------------------------------
Public Sub SR_VentanaDistribucion()
    Dim c As Range, wb As Workbook, ws As Worksheet, idx As Long, p As Variant, nombre As String
    Dim v As Double, i As Long, nm As Variant, shp As Object, ch As Object

    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    Set gDistDestino = c
    ThisWorkbook.ArmarEventos
    idx = 0
    nombre = ""
    If Not LeerFormulaDist(c, idx, p, nombre) Then
        idx = 0
        v = 0
        If VarType(c.Value2) = vbDouble Then v = c.Value2
        p = DefectoParam(D_NORMAL, v)
    End If

    On Error GoTo falla
    Application.ScreenUpdating = False
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set ws = wb.Worksheets(1)
    ws.Name = HOJA_DIST
    ActiveWindow.DisplayGridlines = False
    ActiveWindow.DisplayHeadings = False
    ws.Cells.Font.Name = "Calibri"
    ws.Cells.Font.Size = 10
    ws.Columns("A").ColumnWidth = 2
    ws.Columns("B").ColumnWidth = 24
    ws.Columns("C").ColumnWidth = 16
    ws.Columns("D").ColumnWidth = 2

    ' destino (por si se pierde la referencia en memoria)
    ws.Range("AH30").Value2 = "'" & c.Worksheet.Parent.Name
    ws.Range("AH31").Value2 = "'" & c.Worksheet.Name
    ws.Range("AH32").Value2 = "'" & c.Address

    nm = CatalogoNombres()
    For i = 0 To UBound(nm)
        ws.Cells(1 + i, 34).Value2 = nm(i)
    Next i

    With ws.Range("B2")
        .Value = "Definir distribuci" & ChrW$(243) & "n"
        .Font.Size = 15
        .Font.Bold = True
        .Font.Color = RGB(154, 61, 12)
    End With
    ws.Range("B3").Value = "Celda: " & CellLabel(c)
    ws.Range("B3").Font.Color = RGB(124, 123, 119)

    ws.Range("B5").Value = "Distribuci" & ChrW$(243) & "n"
    ws.Range("B10").Value = "Nombre (opcional)"
    ws.Range("B12").Value = "Delimitador izquierdo"
    ws.Range("B13").Value = "Delimitador derecho"
    ws.Range("B5:B13").Font.Bold = True
    With ws.Range("C5")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=$AH$1:$AH$" & (UBound(nm) + 1)
        .Value2 = nm(idx)
    End With
    ws.Range("C10").Value2 = "'" & nombre
    ws.Range("C12").Value2 = 0.05
    ws.Range("C13").Value2 = 0.95
    ws.Range("C12:C13").NumberFormat = "0.0%"
    With ws.Range("C5,C6:C9,C10,C12:C13")
        .Interior.Color = RGB(255, 255, 255)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(217, 216, 212)
    End With
    ws.Range("B4:C14").Interior.Color = RGB(250, 248, 245)
    ws.Range("C5,C6:C9,C10,C12:C13").Interior.Color = RGB(255, 255, 255)

    ws.Range("B16").Value = "Resultados te" & ChrW$(243) & "ricos"
    ws.Range("B16").Font.Bold = True
    ws.Range("B16").Font.Color = RGB(154, 61, 12)
    ws.Range("B17").Value = "x izquierdo"
    ws.Range("B18").Value = "x derecho"
    ws.Range("B19").Value = "Probabilidad central"
    ws.Range("B20").Value = "Media"
    ws.Range("B21").Value = "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar"
    ws.Range("B22").Value = "Mediana"
    ws.Range("B23").Value = "Percentil 0,1 % / 99,9 %"
    ws.Range("B25").Value = "F" & ChrW$(243) & "rmula"
    ws.Range("B25").Font.Bold = True
    ws.Range("C25").Font.Name = "Consolas"

    ' botones
    Set shp = ws.Shapes.AddShape(5, ws.Range("B28").Left, ws.Range("B28").Top, 120, 26)
    EstiloBoton shp, "Aplicar a la celda", RGB(217, 86, 26), RGB(255, 255, 255)
    shp.OnAction = "'" & ThisWorkbook.Name & "'!SR_DistAplicar"
    Set shp = ws.Shapes.AddShape(5, ws.Range("B28").Left + 130, ws.Range("B28").Top, 90, 26)
    EstiloBoton shp, "Cancelar", RGB(236, 235, 232), RGB(60, 59, 56)
    shp.OnAction = "'" & ThisWorkbook.Name & "'!SR_DistCancelar"

    ' grafico
    Set ch = ws.ChartObjects.Add(ws.Range("E2").Left, ws.Range("E2").Top, 470, 330)
    ch.Name = "SRVista"
    With ch.Chart
        .ChartType = xlColumnStacked
        Do While .SeriesCollection.Count < 3
            .SeriesCollection.NewSeries
        Loop
        .HasLegend = False
        .HasTitle = True
        .ChartTitle.Font.Size = 11
        .ChartTitle.Font.Bold = False
        .SeriesCollection(1).Format.Fill.ForeColor.RGB = RGB(205, 201, 195)
        .SeriesCollection(2).Format.Fill.ForeColor.RGB = RGB(217, 86, 26)
        .SeriesCollection(3).Format.Fill.ForeColor.RGB = RGB(205, 201, 195)
        .ChartGroups(1).Overlap = 100
        .Axes(xlValue).HasMajorGridlines = True
        .Axes(xlValue).MajorGridlines.Format.Line.ForeColor.RGB = RGB(236, 235, 232)
        .Axes(xlValue).TickLabels.Font.Size = 8
        .Axes(xlCategory).TickLabels.Font.Size = 8
        .PlotVisibleOnly = False
        .ChartArea.Format.Line.Visible = msoFalse
    End With
    ws.Columns("AA:AH").Hidden = True

    PonerEtiquetas ws, CatalogoCodigo(idx), p
    DistActualizar ws
    ws.Range("C6").Select
    wb.Saved = True
    Application.ScreenUpdating = True
    Exit Sub
falla:
    Application.ScreenUpdating = True
    MsgBox "No se pudo abrir la ventana de distribuci" & ChrW$(243) & "n: " & Err.Description, vbExclamation, SR_APP
End Sub

Private Sub EstiloBoton(ByVal shp As Object, ByVal texto As String, ByVal fondo As Long, ByVal tinta As Long)
    shp.Fill.ForeColor.RGB = fondo
    shp.Line.Visible = msoFalse
    With shp.TextFrame2
        .TextRange.Text = texto
        .TextRange.Font.Size = 10
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = tinta
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
    End With
End Sub

' Escribe etiquetas y valores de los parametros para el tipo t
Private Sub PonerEtiquetas(ByVal ws As Worksheet, ByVal t As Long, ByVal p As Variant)
    Dim et As Variant, i As Long, ev As Boolean
    ev = Application.EnableEvents
    Application.EnableEvents = False
    et = EtiquetasParam(t)
    For i = 0 To 3
        If i <= UBound(et) Then
            ws.Cells(6 + i, 2).Value = et(i)
            ws.Cells(6 + i, 3).Value2 = p(i)
            ws.Cells(6 + i, 3).Interior.Color = RGB(255, 255, 255)
            ws.Cells(6 + i, 3).Borders.LineStyle = xlContinuous
            ws.Cells(6 + i, 3).Borders.Color = RGB(217, 216, 212)
            ws.Cells(6 + i, 3).Locked = False
        Else
            ws.Cells(6 + i, 2).Value = ""
            ws.Cells(6 + i, 3).Value = ""
            ws.Cells(6 + i, 3).Interior.Color = RGB(250, 248, 245)
            ws.Cells(6 + i, 3).Borders.LineStyle = xlNone
        End If
    Next i
    ws.Range("B6:B9").Font.Bold = True
    Application.EnableEvents = ev
End Sub

' ------------------------------------------------------------
'  Recalculo de la vista previa (lo llama el evento de cambio de hoja)
' ------------------------------------------------------------
Public Sub DistCambio(ByVal ws As Worksheet, ByVal Target As Range)
    Dim idx As Long, v As Double
    On Error Resume Next
    If ws.Name <> HOJA_DIST Then Exit Sub
    If Len(CStr(ws.Range("AH32").Value2)) = 0 Then Exit Sub
    If Not Intersect(Target, ws.Range("C5")) Is Nothing Then
        idx = CatalogoIndice(CStr(ws.Range("C5").Value2))
        If idx < 0 Then Exit Sub
        v = 0
        If VarType(ws.Range("C20").Value2) = vbDouble Then v = ws.Range("C20").Value2
        PonerEtiquetas ws, CatalogoCodigo(idx), DefectoParam(CatalogoCodigo(idx), v)
    End If
    If Not Intersect(Target, ws.Range("C5:C13")) Is Nothing Then DistActualizar ws
End Sub

Private Function ParamsHoja(ByVal ws As Worksheet, ByVal t As Long, ByRef p() As Double, ByRef np As Long) As Boolean
    Dim i As Long, x As Variant
    np = UBound(EtiquetasParam(t)) + 1
    ReDim p(1 To 4)
    For i = 1 To np
        x = ws.Cells(5 + i, 3).Value2
        If VarType(x) <> vbDouble Then Exit Function
        p(i) = x
    Next i
    ParamsHoja = True
End Function

Public Sub DistActualizar(ByVal ws As Worksheet)
    Dim idx As Long, t As Long, p() As Double, np As Long, msg As String, ev As Boolean
    Dim lo As Double, hi As Double, xL As Double, xR As Double, pL As Double, pR As Double
    Dim k As Long, i As Long, x As Double, f As Double, paso As Double, disc As Boolean
    Dim dat() As Variant, ch As Object, fx As String

    ev = Application.EnableEvents
    Application.EnableEvents = False
    On Error GoTo falla
    idx = CatalogoIndice(CStr(ws.Range("C5").Value2))
    If idx < 0 Then msg = "Elija una distribuci" & ChrW$(243) & "n de la lista."
    If Len(msg) = 0 Then
        t = CatalogoCodigo(idx)
        If Not ParamsHoja(ws, t, p, np) Then msg = "Complete todos los par" & ChrW$(225) & "metros con n" & ChrW$(250) & "meros."
    End If
    If Len(msg) = 0 Then msg = ValidarParametros(t, p)
    pL = 0.05: pR = 0.95
    If VarType(ws.Range("C12").Value2) = vbDouble Then pL = ws.Range("C12").Value2
    If VarType(ws.Range("C13").Value2) = vbDouble Then pR = ws.Range("C13").Value2
    If Len(msg) = 0 Then
        If pL < 0 Or pR > 1 Or pL >= pR Then msg = "Los delimitadores deben cumplir 0 " & ChrW$(8804) & " izquierdo < derecho " & ChrW$(8804) & " 100 %."
    End If
    Set ch = ws.ChartObjects("SRVista").Chart
    If Len(msg) > 0 Then
        ws.Range("C17:C23").Value = ""
        ws.Range("C25").Value = ""
        ch.ChartTitle.Text = msg
        ch.ChartTitle.Font.Color = RGB(180, 35, 24)
        GoTo fin
    End If

    disc = EsDiscreta(t)
    lo = InvCdf(t, 0.0005, p)
    hi = InvCdf(t, 0.9995, p)
    xL = InvCdf(t, IIf(pL <= 0, 0.000000000001, pL), p)
    xR = InvCdf(t, IIf(pR >= 1, 0.999999999999, pR), p)
    If disc Then
        paso = -Int(-(hi - lo + 1) / NPUNTOS)
        If paso < 1 Then paso = 1
        k = Int((hi - lo) / paso) + 1
    Else
        If hi <= lo Then hi = lo + 1
        k = NPUNTOS
        paso = (hi - lo) / k
    End If
    ReDim dat(1 To k, 1 To 4)
    For i = 1 To k
        If disc Then x = lo + (i - 1) * paso Else x = lo + (i - 0.5) * paso
        f = Densidad(t, x, p)
        dat(i, 1) = x
        dat(i, 2) = 0: dat(i, 3) = 0: dat(i, 4) = 0
        If (disc And x < xL) Or (Not disc And x < xL) Then
            dat(i, 2) = f
        ElseIf x <= xR Then
            dat(i, 3) = f
        Else
            dat(i, 4) = f
        End If
    Next i
    ws.Range("AA1:AD" & (NPUNTOS + 5)).ClearContents
    ws.Range("AA1").Resize(k, 4).Value2 = dat
    With ch
        .SeriesCollection(1).Values = ws.Range("AB1").Resize(k, 1)
        .SeriesCollection(2).Values = ws.Range("AC1").Resize(k, 1)
        .SeriesCollection(3).Values = ws.Range("AD1").Resize(k, 1)
        For i = 1 To 3
            .SeriesCollection(i).XValues = ws.Range("AA1").Resize(k, 1)
        Next i
        .ChartGroups(1).GapWidth = IIf(disc, 60, 0)
        .Axes(xlCategory).TickLabels.NumberFormat = FormatoEje(hi - lo)
        .Axes(xlCategory).TickLabelSpacing = IIf(k > 12, Int(k / 6), 1)
        .Axes(xlCategory).TickMarkSpacing = .Axes(xlCategory).TickLabelSpacing
        .ChartTitle.Font.Color = RGB(60, 59, 56)
        .ChartTitle.Text = Format(pL, "0.0%") & "  |  " & Format(xL, FormatoNum(xL)) & "   " & _
            ChrW$(8212) & "  " & Format(pR - pL, "0.0%") & "  " & ChrW$(8212) & "   " & _
            Format(xR, FormatoNum(xR)) & "  |  " & Format(1 - pR, "0.0%")
    End With

    ws.Range("C17").Value2 = xL
    ws.Range("C18").Value2 = xR
    ws.Range("C19").Value2 = pR - pL
    ws.Range("C19").NumberFormat = "0.0%"
    ws.Range("C20").Value2 = ValorEsperado(t, p)
    f = Varianza(t, p)
    If f >= 0 Then ws.Range("C21").Value2 = Sqr(f) Else ws.Range("C21").Value = "no definida"
    ws.Range("C22").Value2 = InvCdf(t, 0.5, p)
    ws.Range("C23").Value = Format(InvCdf(t, 0.001, p), FormatoNum(lo)) & " / " & Format(InvCdf(t, 0.999, p), FormatoNum(hi))
    ws.Range("C17:C18,C20:C22").NumberFormat = "#,##0.00##"
    fx = FormulaDist(ws)
    ws.Range("C25").Value2 = "'" & fx
fin:
    Application.EnableEvents = ev
    Exit Sub
falla:
    Application.EnableEvents = ev
End Sub

Private Function FormatoNum(ByVal x As Double) As String
    If Abs(x) >= 1000 Then
        FormatoNum = "#,##0"
    ElseIf Abs(x) >= 10 Then
        FormatoNum = "#,##0.0"
    Else
        FormatoNum = "0.000"
    End If
End Function

Private Function FormatoEje(ByVal rango As Double) As String
    If rango >= 50 Then
        FormatoEje = "#,##0"
    ElseIf rango >= 5 Then
        FormatoEje = "0.0"
    Else
        FormatoEje = "0.00"
    End If
End Function

' Formula SR... equivalente a lo que hay en la ventana (separador ingles, para Range.Formula)
Private Function FormulaDist(ByVal ws As Worksheet) As String
    Dim idx As Long, t As Long, p() As Double, np As Long, i As Long, s As String, nombre As String
    idx = CatalogoIndice(CStr(ws.Range("C5").Value2))
    If idx < 0 Then Exit Function
    t = CatalogoCodigo(idx)
    If Not ParamsHoja(ws, t, p, np) Then Exit Function
    s = "=" & CatalogoFuncion(idx) & "("
    For i = 1 To np
        s = s & IIf(i > 1, ",", "") & NumJ(p(i))
    Next i
    nombre = Trim$(CStr(ws.Range("C10").Value2))
    If Len(nombre) > 0 Then
        If t = D_BETA And np < 4 Then s = s & ",0,1"
        s = s & ",""" & Replace(nombre, """", "") & """"
    End If
    FormulaDist = s & ")"
End Function

' ------------------------------------------------------------
'  Lee una formula SR... simple (argumentos constantes) de una celda
' ------------------------------------------------------------
Public Function LeerFormulaDist(ByVal c As Range, ByRef idx As Long, ByRef p As Variant, ByRef nombre As String) As Boolean
    Dim f As String, a As Long, fn As String, args As String, partes() As String, i As Long, np As Long
    Dim t As Long, s As String, nNum As Long
    On Error GoTo nada
    If Not c.HasFormula Then Exit Function
    f = Trim$(c.Formula)
    If UCase$(Left$(f, 3)) <> "=SR" Or Right$(f, 1) <> ")" Then Exit Function
    a = InStr(f, "(")
    If a = 0 Then Exit Function
    fn = Mid$(f, 2, a - 2)
    idx = CatalogoIndice(fn)
    If idx < 0 Then Exit Function
    args = Mid$(f, a + 1, Len(f) - a - 1)
    If InStr(args, "(") > 0 Then Exit Function
    partes = Split(args, ",")
    t = CatalogoCodigo(idx)
    np = UBound(EtiquetasParam(t)) + 1
    p = DefectoParam(t, 0)
    For i = 0 To UBound(partes)
        s = Trim$(partes(i))
        If Left$(s, 1) = """" Then
            nombre = Replace(s, """", "")
        ElseIf i < np Then
            If Not IsNumeric(Replace(s, ".", Application.International(xlDecimalSeparator))) Then Exit Function
            p(i) = Val(s)
            nNum = nNum + 1
        End If
    Next i
    If t = D_BETA And nNum <= 2 Then
        p(2) = 0
        p(3) = 1
    End If
    If t = D_LOGLOG Or t = D_PEARSON5 Then
        If nNum <= 2 Then p(2) = 0
    End If
    LeerFormulaDist = True
    Exit Function
nada:
    LeerFormulaDist = False
End Function

' ------------------------------------------------------------
'  Botones
' ------------------------------------------------------------
Private Function DestinoGuardado(ByVal ws As Worksheet) As Range
    On Error Resume Next
    If Not gDistDestino Is Nothing Then
        If gDistDestino.Address <> "" Then
            Set DestinoGuardado = gDistDestino
            Exit Function
        End If
    End If
    Set DestinoGuardado = Workbooks(CStr(ws.Range("AH30").Value2)).Worksheets(CStr(ws.Range("AH31").Value2)).Range(CStr(ws.Range("AH32").Value2))
End Function

Public Sub SR_DistAplicar()
    Dim ws As Worksheet, destino As Range, fx As String, wb As Workbook
    On Error Resume Next
    Set ws = ActiveSheet
    If ws.Name <> HOJA_DIST Then Exit Sub
    On Error GoTo 0
    DistActualizar ws
    fx = FormulaDist(ws)
    If Len(fx) = 0 Or Len(CStr(ws.Range("C25").Value2)) = 0 Then
        MsgBox "Revise los par" & ChrW$(225) & "metros: la distribuci" & ChrW$(243) & "n no es v" & ChrW$(225) & "lida.", vbExclamation, SR_APP
        Exit Sub
    End If
    Set destino = DestinoGuardado(ws)
    If destino Is Nothing Then
        MsgBox "No se encontr" & ChrW$(243) & " la celda de destino (" & CStr(ws.Range("AH32").Value2) & ").", vbExclamation, SR_APP
        Exit Sub
    End If
    On Error GoTo falla
    destino.Formula = fx
    Set wb = ws.Parent
    wb.Saved = True
    destino.Worksheet.Parent.Activate
    destino.Worksheet.Activate
    destino.Select
    wb.Close SaveChanges:=False
    Set gDistDestino = Nothing
    Exit Sub
falla:
    MsgBox "No se pudo escribir en la celda: " & Err.Description, vbExclamation, SR_APP
End Sub

Public Sub SR_DistCancelar()
    Dim ws As Worksheet, wb As Workbook, destino As Range
    On Error Resume Next
    Set ws = ActiveSheet
    If ws.Name <> HOJA_DIST Then Exit Sub
    Set destino = DestinoGuardado(ws)
    Set wb = ws.Parent
    wb.Saved = True
    If Not destino Is Nothing Then
        destino.Worksheet.Parent.Activate
        destino.Worksheet.Activate
    End If
    wb.Close SaveChanges:=False
    Set gDistDestino = Nothing
End Sub
