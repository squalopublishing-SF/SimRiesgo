Attribute VB_Name = "modSRInforme"
Option Explicit

' ============================================================
'  SimRiesgo - Informe de resultados en un libro de Excel
' ============================================================

Private Const COLOR_PRINCIPAL As Long = 1726169   ' RGB(217, 86, 26)
Private Const COLOR_COLA As Long = 10534645        ' RGB(245, 190, 160)
Private Const COLOR_NEG As Long = 14055466         ' RGB(42, 120, 214)

' Indices del vector de estadisticos
Private Const E_N As Long = 1
Private Const E_ERR As Long = 2
Private Const E_MIN As Long = 3
Private Const E_MAX As Long = 4
Private Const E_MEDIA As Long = 5
Private Const E_DESV As Long = 6
Private Const E_ASIM As Long = 7
Private Const E_CURT As Long = 8
Private Const E_MODA As Long = 9

Private Sub Estadisticos(ByRef a() As Double, ByVal n As Long, ByVal total As Long, ByRef e() As Double)
    Dim i As Long, s As Double, m2 As Double, m3 As Double, m4 As Double, d As Double
    ReDim e(1 To 9)
    e(E_N) = n
    e(E_ERR) = total - n
    If n = 0 Then Exit Sub
    e(E_MIN) = a(1): e(E_MAX) = a(1)
    For i = 1 To n
        s = s + a(i)
        If a(i) < e(E_MIN) Then e(E_MIN) = a(i)
        If a(i) > e(E_MAX) Then e(E_MAX) = a(i)
    Next i
    e(E_MEDIA) = s / n
    For i = 1 To n
        d = a(i) - e(E_MEDIA)
        m2 = m2 + d * d
        m3 = m3 + d * d * d
        m4 = m4 + d * d * d * d
    Next i
    If n > 1 Then e(E_DESV) = Sqr(m2 / (n - 1))
    m2 = m2 / n: m3 = m3 / n: m4 = m4 / n
    If m2 > 0 Then
        e(E_ASIM) = m3 / (m2 ^ 1.5)
        e(E_CURT) = m4 / (m2 * m2)
    End If
End Sub

Public Sub SR_InformeExcel()
    Dim wb As Workbook
    If ConstruirInforme(wb) Then
        wb.Worksheets(1).Activate
        wb.Worksheets(1).Range("A1").Select
    End If
End Sub

Public Sub SR_InformePDF()
    Dim wb As Workbook, ruta As Variant, ws As Worksheet, carpeta As String, nombre As String, al As Boolean
    If Not ConstruirInforme(wb) Then Exit Sub
    On Error GoTo falla
    Application.ScreenUpdating = False
    For Each ws In wb.Worksheets
        With ws.PageSetup
            .Orientation = xlLandscape
            .Zoom = False
            .FitToPagesWide = 1
            .FitToPagesTall = False
            .LeftMargin = Application.CentimetersToPoints(1.2)
            .RightMargin = Application.CentimetersToPoints(1.2)
            .TopMargin = Application.CentimetersToPoints(1.2)
            .BottomMargin = Application.CentimetersToPoints(1.4)
            .CenterHorizontally = True
        End With
    Next ws
    Application.ScreenUpdating = True
    nombre = NombreArchivo(Replace(gModelName, ".xlsx", "")) & " - informe SimRiesgo.pdf"
    ruta = Application.GetSaveAsFilename(InitialFileName:=nombre, FileFilter:="PDF (*.pdf), *.pdf", _
                                         Title:=SR_APP & " - Guardar informe PDF")
    If VarType(ruta) = vbBoolean Then
        wb.Saved = True
        wb.Close False
        Exit Sub
    End If
    Application.StatusBar = SR_APP & ": exportando PDF..."
    wb.ExportAsFixedFormat Type:=xlTypePDF, Filename:=CStr(ruta), Quality:=xlQualityStandard, _
        IncludeDocProperties:=True, IgnorePrintAreas:=False, OpenAfterPublish:=True
    Application.StatusBar = False
    wb.Saved = True
    wb.Close False
    Exit Sub
falla:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "No se pudo crear el PDF: " & Err.Description, vbExclamation, SR_APP
End Sub

Private Function NombreArchivo(ByVal s As String) As String
    Dim c As Variant
    For Each c In Array("\", "/", ":", "*", "?", """", "<", ">", "|")
        s = Replace(s, c, "_")
    Next c
    If InStrRev(s, ".") > 0 Then s = Left$(s, InStrRev(s, ".") - 1)
    NombreArchivo = s
End Function

Private Function ConstruirInforme(ByRef wb As Workbook) As Boolean
    Dim ws As Worksheet, wd As Worksheet
    Dim r As Long, s As Long, o As Long, j As Long, bloques As Long
    Dim a() As Double, n As Long

    If Not ActiveWorkbook Is Nothing Then AsegurarResultados ActiveWorkbook
    If Not gHasResults Then
        MsgBox "Todav" & ChrW$(237) & "a no hay resultados. Ejecute primero una simulaci" & ChrW$(243) & "n.", vbInformation, SR_APP
        Exit Function
    End If

    On Error GoTo falla
    Application.ScreenUpdating = False
    Application.StatusBar = SR_APP & ": generando informe..."

    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set ws = wb.Worksheets(1)
    ws.Name = "Resumen"
    ActiveWindow.DisplayGridlines = False

    ' ---- Encabezado ----
    ws.Range("A1").Value = SR_APP & " - Informe de simulaci" & ChrW$(243) & "n"
    ws.Range("A1").Font.Size = 16
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Color = COLOR_PRINCIPAL
    ws.Range("A2").Value = "Modelo:": ws.Range("B2").Value = gModelName
    ws.Range("A3").Value = "Fecha:": ws.Range("B3").Value = Format$(gSimDate, "dd/mm/yyyy hh:nn")
    ws.Range("A4").Value = "Iteraciones:": ws.Range("B4").Value = gItersDone
    ws.Range("C4").Value = "Simulaciones:": ws.Range("D4").Value = gSimsDone
    ws.Range("E4").Value = "Muestreo:": ws.Range("F4").Value = gSampling
    ws.Range("G4").Value = "Semilla:": ws.Range("H4").Value = gSeedUsed
    ws.Range("A2:A4,C4,E4,G4").Font.Bold = True
    ws.Range("B4,D4,H4").HorizontalAlignment = xlLeft
    If gConvUsada Then
        ws.Range("I4").Value = "Convergencia:"
        ws.Range("J4").Value = IIf(gConvAlcanzada, "alcanzada", "no alcanzada") & " (tol. " & Format(gConvTol * 100, "0.0") & " %)"
        ws.Range("I4").Font.Bold = True
    End If
    PonerSello ws

    ' ---- Tabla resumen ----
    r = 6
    ws.Cells(r, 1).Resize(1, 12).Value = Array("Tipo", "Nombre", "Celda", "Simulaci" & ChrW$(243) & "n", _
        "M" & ChrW$(237) & "nimo", "Media", "M" & ChrW$(225) & "ximo", "Desv. est.", "P5", "P50", "P95", "Errores")
    FormatoEncabezado ws.Cells(r, 1).Resize(1, 12)
    For s = 1 To gSimsDone
        For o = 1 To rOutCount
            r = r + 1
            n = DatosSerie(True, s, o, a)
            FilaResumen ws, r, "Salida", rOutName(o), rOutCell(o), s, a, n
        Next o
        For j = 1 To rInCount
            r = r + 1
            n = DatosSerie(False, s, j, a)
            FilaResumen ws, r, "Entrada", rInName(j), rInCell(j), s, a, n
        Next j
    Next s
    ws.Range(ws.Cells(7, 5), ws.Cells(r, 11)).NumberFormat = "#,##0.00"
    ws.Columns("A:L").AutoFit
    TablaCorrelaciones ws, r + 2
    If ws.Columns(2).ColumnWidth > 40 Then ws.Columns(2).ColumnWidth = 40

    ' ---- Detalle por salida ----
    Set wd = wb.Worksheets.Add(After:=ws)
    wd.Name = "Detalle"
    ActiveWindow.DisplayGridlines = False
    wd.Columns(1).ColumnWidth = 22
    wd.Columns(2).ColumnWidth = 14
    wd.Columns(3).ColumnWidth = 3
    wd.Columns(4).ColumnWidth = 10
    wd.Columns(5).ColumnWidth = 14
    r = 1
    bloques = 0
    For s = 1 To gSimsDone
        For o = 1 To rOutCount
            bloques = bloques + 1
            If bloques > 40 Then Exit For
            Application.StatusBar = SR_APP & ": informe de " & rOutName(o) & "..."
            BloqueSalida wd, r, o, s
            r = r + 24
        Next o
    Next s
    wd.Range("Z:AF").EntireColumn.Hidden = True
    PonerSello wd
    For j = 2 To bloques
        If j <= 40 Then wd.HPageBreaks.Add Before:=wd.Cells(1 + (j - 1) * 24, 1)
    Next j

    ws.Activate
    ws.Range("A1").Select
    wb.Saved = True
    Application.StatusBar = False
    Application.ScreenUpdating = True
    ConstruirInforme = True
    Exit Function
falla:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "No se pudo completar el informe: " & Err.Description, vbExclamation, SR_APP
End Function

' Credito discreto en el pie de pagina de cada hoja del informe
Private Sub PonerSello(ByVal ws As Worksheet)
    On Error Resume Next
    ws.PageSetup.RightFooter = "&8&""Georgia,Italic""SimRiesgo " & SR_VER & " " & ChrW$(183) & " SQUALO SOFTWARE"
    ws.PageSetup.LeftFooter = "&8&P / &N"
    Err.Clear
End Sub

Private Sub FormatoEncabezado(ByVal rg As Range)
    rg.Font.Bold = True
    rg.Font.Color = vbWhite
    rg.Interior.Color = COLOR_PRINCIPAL
End Sub

Private Sub FilaResumen(ByVal ws As Worksheet, ByVal r As Long, ByVal tipo As String, ByVal nombre As String, _
                        ByVal celda As String, ByVal s As Long, ByRef a() As Double, ByVal n As Long)
    Dim e() As Double
    ws.Cells(r, 1).Value = tipo
    ws.Cells(r, 2).Value = nombre
    ws.Cells(r, 3).Value = celda
    ws.Cells(r, 4).Value = s
    If n = 0 Then
        ws.Cells(r, 12).Value = gItersDone
        Exit Sub
    End If
    Estadisticos a, n, gItersDone, e
    OrdenarD a, 1, n
    ws.Cells(r, 5).Value = e(E_MIN)
    ws.Cells(r, 6).Value = e(E_MEDIA)
    ws.Cells(r, 7).Value = e(E_MAX)
    ws.Cells(r, 8).Value = e(E_DESV)
    ws.Cells(r, 9).Value = PercentilOrdenado(a, n, 0.05)
    ws.Cells(r, 10).Value = PercentilOrdenado(a, n, 0.5)
    ws.Cells(r, 11).Value = PercentilOrdenado(a, n, 0.95)
    ws.Cells(r, 12).Value = e(E_ERR)
    If tipo = "Salida" Then ws.Cells(r, 1).Resize(1, 12).Interior.Color = RGB(253, 240, 231)
End Sub

Private Sub BloqueSalida(ByVal ws As Worksheet, ByVal r As Long, ByVal o As Long, ByVal s As Long)
    Dim a() As Double, n As Long, e() As Double, i As Long, k As Long, b As Long
    Dim ancho As Double, cnt() As Long, p5 As Double, p95 As Double, mx As Long
    Dim etiquetas As Variant, probs As Variant, titulo As String

    n = DatosSerie(True, s, o, a)
    titulo = rOutName(o) & "  (" & rOutCell(o) & ")"
    If gSimsDone > 1 Then titulo = titulo & "  -  Simulaci" & ChrW$(243) & "n " & s
    ws.Cells(r, 1).Value = titulo
    ws.Cells(r, 1).Font.Size = 13
    ws.Cells(r, 1).Font.Bold = True
    ws.Cells(r, 1).Font.Color = COLOR_PRINCIPAL
    If n < 2 Then
        ws.Cells(r + 1, 1).Value = "Sin valores v" & ChrW$(225) & "lidos."
        Exit Sub
    End If

    Estadisticos a, n, gItersDone, e
    OrdenarD a, 1, n
    p5 = PercentilOrdenado(a, n, 0.05)
    p95 = PercentilOrdenado(a, n, 0.95)

    ' ---- Histograma (datos en columnas Z:AA) ----
    k = Int(Sqr(n) + 0.5)
    If k < 8 Then k = 8
    If k > 40 Then k = 40
    ReDim cnt(1 To k)
    ancho = (e(E_MAX) - e(E_MIN)) / k
    If ancho <= 0 Then ancho = 1
    For i = 1 To n
        b = Int((a(i) - e(E_MIN)) / ancho) + 1
        If b > k Then b = k
        If b < 1 Then b = 1
        cnt(b) = cnt(b) + 1
    Next i
    mx = 1
    For b = 1 To k
        ws.Cells(r + b, 26).Value = e(E_MIN) + (b - 0.5) * ancho
        ws.Cells(r + b, 27).Value = cnt(b) / n
        If cnt(b) > cnt(mx) Then mx = b
    Next b
    e(E_MODA) = e(E_MIN) + (mx - 0.5) * ancho

    ' ---- Estadisticos ----
    etiquetas = Array("M" & ChrW$(237) & "nimo", "M" & ChrW$(225) & "ximo", "Media", "IC 90% media (" & ChrW$(177) & ")", _
                      "Moda (aprox.)", "Mediana", "Desv. est.", "Asimetr" & ChrW$(237) & "a", "Curtosis", "Valores", "Errores")
    ws.Cells(r + 1, 1).Value = "Estad" & ChrW$(237) & "stico"
    ws.Cells(r + 1, 2).Value = "Valor"
    FormatoEncabezado ws.Range(ws.Cells(r + 1, 1), ws.Cells(r + 1, 2))
    For i = 0 To UBound(etiquetas)
        ws.Cells(r + 2 + i, 1).Value = etiquetas(i)
    Next i
    ws.Cells(r + 2, 2).Value = e(E_MIN)
    ws.Cells(r + 3, 2).Value = e(E_MAX)
    ws.Cells(r + 4, 2).Value = e(E_MEDIA)
    ws.Cells(r + 5, 2).Value = 1.6449 * e(E_DESV) / Sqr(n)
    ws.Cells(r + 6, 2).Value = e(E_MODA)
    ws.Cells(r + 7, 2).Value = PercentilOrdenado(a, n, 0.5)
    ws.Cells(r + 8, 2).Value = e(E_DESV)
    ws.Cells(r + 9, 2).Value = e(E_ASIM)
    ws.Cells(r + 10, 2).Value = e(E_CURT)
    ws.Cells(r + 11, 2).Value = e(E_N)
    ws.Cells(r + 12, 2).Value = e(E_ERR)
    ws.Range(ws.Cells(r + 2, 2), ws.Cells(r + 8, 2)).NumberFormat = "#,##0.00"
    ws.Range(ws.Cells(r + 9, 2), ws.Cells(r + 10, 2)).NumberFormat = "0.0000"

    ' ---- Percentiles ----
    probs = Array(0.01, 0.05, 0.1, 0.2, 0.25, 0.5, 0.75, 0.8, 0.9, 0.95, 0.99)
    ws.Cells(r + 1, 4).Value = "Percentil"
    ws.Cells(r + 1, 5).Value = "Valor"
    FormatoEncabezado ws.Range(ws.Cells(r + 1, 4), ws.Cells(r + 1, 5))
    For i = 0 To UBound(probs)
        ws.Cells(r + 2 + i, 4).Value = probs(i)
        ws.Cells(r + 2 + i, 5).Value = PercentilOrdenado(a, n, probs(i))
    Next i
    ws.Range(ws.Cells(r + 2, 4), ws.Cells(r + 12, 4)).NumberFormat = "0%"
    ws.Range(ws.Cells(r + 2, 5), ws.Cells(r + 12, 5)).NumberFormat = "#,##0.00"

    ws.Cells(r + 14, 1).Value = "Intervalo del 90%:"
    ws.Cells(r + 14, 1).Font.Bold = True
    ws.Cells(r + 14, 2).Value = p5
    ws.Cells(r + 14, 4).Value = "a"
    ws.Cells(r + 14, 5).Value = p95
    ws.Range(ws.Cells(r + 14, 2), ws.Cells(r + 14, 5)).NumberFormat = "#,##0.00"

    GraficoHistograma ws, r, k, rOutName(o), p5, p95, ancho
    GraficoTornado ws, r, o, s
End Sub

Private Sub GraficoHistograma(ByVal ws As Worksheet, ByVal r As Long, ByVal k As Long, ByVal titulo As String, _
                              ByVal p5 As Double, ByVal p95 As Double, ByVal ancho As Double)
    Dim co As ChartObject, ch As Chart, i As Long, xm As Double, ser As Object
    Set co = ws.ChartObjects.Add(ws.Cells(r + 1, 7).Left, ws.Cells(r + 1, 7).Top, 430, 260)
    Set ch = co.Chart
    ch.PlotVisibleOnly = False
    ch.ChartType = xlColumnClustered
    Do While ch.SeriesCollection.Count > 0
        ch.SeriesCollection(1).Delete
    Loop
    Set ser = ch.SeriesCollection.NewSeries
    ser.Name = "Frecuencia relativa"
    ser.Values = ws.Range(ws.Cells(r + 1, 27), ws.Cells(r + k, 27))
    ser.XValues = ws.Range(ws.Cells(r + 1, 26), ws.Cells(r + k, 26))
    ser.Format.Fill.ForeColor.RGB = COLOR_PRINCIPAL
    ch.ChartGroups(1).GapWidth = 3
    For i = 1 To k
        xm = ws.Cells(r + i, 26).Value
        If xm + ancho / 2 <= p5 Or xm - ancho / 2 >= p95 Then
            ser.Points(i).Format.Fill.ForeColor.RGB = COLOR_COLA
        End If
    Next i
    ch.HasLegend = False
    ch.HasTitle = True
    ch.ChartTitle.Text = titulo & "  -  90% entre " & Format$(p5, "#,##0.00") & " y " & Format$(p95, "#,##0.00")
    ch.ChartTitle.Font.Size = 11
    ch.Axes(xlCategory).TickLabels.NumberFormat = "#,##0.0"
    ch.Axes(xlValue).TickLabels.NumberFormat = "0.0%"
    ch.Axes(xlValue).HasTitle = True
    ch.Axes(xlValue).AxisTitle.Text = "Frecuencia relativa"
End Sub

Private Sub GraficoTornado(ByVal ws As Worksheet, ByVal r As Long, ByVal o As Long, ByVal s As Long)
    Dim y() As Double, x() As Double, ry() As Double, rx() As Double, ok() As Long
    Dim n As Long, i As Long, j As Long, m As Long, rho() As Double, ord() As Long, absr() As Double
    Dim co As ChartObject, ch As Chart, ser As Object, nTop As Long

    If rInCount = 0 Then Exit Sub
    ReDim ok(1 To gItersDone)
    For i = 1 To gItersDone
        If gOutErr(s, o, i) = 0 Then
            n = n + 1
            ok(n) = i
        End If
    Next i
    If n < 3 Then Exit Sub
    ReDim y(1 To n)
    For i = 1 To n
        y(i) = gOutVals(s, o, ok(i))
    Next i
    Rangos y, n, ry

    ReDim rho(1 To rInCount)
    ReDim absr(1 To rInCount)
    ReDim ord(1 To rInCount)
    ReDim x(1 To n)
    For j = 1 To rInCount
        For i = 1 To n
            x(i) = gInVals(s, j, ok(i))
        Next i
        Rangos x, n, rx
        rho(j) = Pearson(rx, ry, n)
        absr(j) = -Abs(rho(j))
        ord(j) = j
    Next j
    OrdenarIdx absr, ord, 1, rInCount

    nTop = rInCount
    If nTop > 10 Then nTop = 10
    For i = 1 To nTop
        ws.Cells(r + i, 29).Value = rInName(ord(i))
        ws.Cells(r + i, 30).Value = rho(ord(i))
    Next i

    Set co = ws.ChartObjects.Add(ws.Cells(r + 1, 7).Left + 440, ws.Cells(r + 1, 7).Top, 400, 260)
    Set ch = co.Chart
    ch.PlotVisibleOnly = False
    ch.ChartType = xlBarClustered
    Do While ch.SeriesCollection.Count > 0
        ch.SeriesCollection(1).Delete
    Loop
    Set ser = ch.SeriesCollection.NewSeries
    ser.Name = "Correlaci" & ChrW$(243) & "n de rangos"
    ser.Values = ws.Range(ws.Cells(r + 1, 30), ws.Cells(r + nTop, 30))
    ser.XValues = ws.Range(ws.Cells(r + 1, 29), ws.Cells(r + nTop, 29))
    ser.Format.Fill.ForeColor.RGB = COLOR_PRINCIPAL
    For i = 1 To nTop
        If rho(ord(i)) < 0 Then ser.Points(i).Format.Fill.ForeColor.RGB = COLOR_NEG
    Next i
    ser.HasDataLabels = True
    ser.DataLabels.NumberFormat = "0.00"
    ch.ChartGroups(1).GapWidth = 40
    ch.Axes(xlCategory).ReversePlotOrder = True
    ch.Axes(xlCategory).TickLabelPosition = xlTickLabelPositionLow
    ch.Axes(xlValue).MinimumScale = -1
    ch.Axes(xlValue).MaximumScale = 1
    ch.Axes(xlValue).TickLabels.NumberFormat = "0.0"
    ch.HasLegend = False
    ch.HasTitle = True
    ch.ChartTitle.Text = "Sensibilidad - correlaci" & ChrW$(243) & "n de rangos (Spearman)"
    ch.ChartTitle.Font.Size = 11
End Sub

' Correlaciones objetivo frente a las obtenidas (Spearman, simulacion 1)
Private Sub TablaCorrelaciones(ByVal ws As Worksheet, ByVal r As Long)
    Dim nombres() As String, vars() As Variant, obj() As Variant, ng As Long, g As Long, i As Long, j As Long
    Dim v As Variant, m As Variant, ra() As Double, rb() As Double, a() As Double, b() As Double, n As Long
    ng = CorrGrupos(nombres, vars, obj)
    If ng = 0 Then Exit Sub
    ws.Cells(r, 1).Value = "Correlaciones de rango (objetivo / obtenida)"
    ws.Cells(r, 1).Font.Bold = True
    ws.Cells(r, 1).Font.Color = COLOR_PRINCIPAL
    r = r + 1
    ws.Cells(r, 1).Resize(1, 5).Value = Array("Matriz", "Entrada A", "Entrada B", "Objetivo", "Obtenida")
    FormatoEncabezado ws.Cells(r, 1).Resize(1, 5)
    For g = 1 To ng
        v = vars(g)
        m = obj(g)
        For i = 0 To UBound(v) - 1
            For j = i + 1 To UBound(v)
                If v(i) + 1 >= 1 And v(i) + 1 <= rInCount And v(j) + 1 >= 1 And v(j) + 1 <= rInCount Then
                    r = r + 1
                    n = DatosSerie(False, 1, v(i) + 1, a)
                    n = DatosSerie(False, 1, v(j) + 1, b)
                    Rangos a, n, ra
                    Rangos b, n, rb
                    ws.Cells(r, 1).Value = nombres(g)
                    ws.Cells(r, 2).Value = rInName(v(i) + 1)
                    ws.Cells(r, 3).Value = rInName(v(j) + 1)
                    ws.Cells(r, 4).Value = m(i)(j)
                    ws.Cells(r, 5).Value = Pearson(ra, rb, n)
                    ws.Cells(r, 4).Resize(1, 2).NumberFormat = "0.000"
                End If
            Next j
        Next i
    Next g
End Sub
