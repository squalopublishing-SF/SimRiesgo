Attribute VB_Name = "modSRGuardar"
Option Explicit

' ============================================================
'  SimRiesgo - Resultados guardados dentro del libro del modelo
' ============================================================
'  Los resultados se guardan en una hoja muy oculta "SR_Resultados", de modo que al
'  reabrir el libro (aun sin volver a simular) el visor, el informe y las funciones
'  SRMedia, SRPercentil, etc. siguen disponibles.

Private Const HOJA_RES As String = "SR_Resultados"
Private Const MARCA As String = "SIMRIESGO_RESULTADOS"
Private Const COL_DATOS As Long = 14
Private gFallidos As Object

Private Function HojaResultados(ByVal wb As Workbook) As Worksheet
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name = HOJA_RES Then
            Set HojaResultados = ws
            Exit Function
        End If
    Next ws
End Function

Private Function Txt(ByVal s As String) As String
    Txt = "'" & s
End Function

Public Function LibroTieneResultados(ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = HojaResultados(wb)
    If ws Is Nothing Then Exit Function
    LibroTieneResultados = (CStr(ws.Range("A1").Value2) = MARCA)
End Function

' ------------------------------------------------------------
Public Sub GuardarResultados(ByVal wb As Workbook)
    Dim ws As Worksheet, wsAct As Object, nS As Long, nIn As Long, nOut As Long, n As Long
    Dim s As Long, j As Long, i As Long, col As Long, v() As Variant, t() As Variant, k As Variant
    Dim partes As Long, p As Long, cj As String

    If Not gHasResults Then Exit Sub
    nS = gSimsDone
    nIn = rInCount
    nOut = rOutCount
    n = gItersDone
    If COL_DATOS + CDbl(nS) * (nIn + nOut) > 16000 Or n > 1000000 Or CDbl(nS) * (nIn + nOut) * n > 8000000# Then
        gAvisos = gAvisos & "Los resultados son demasiado grandes para guardarse dentro del libro; " & _
                  "est" & ChrW$(225) & "n disponibles mientras Excel siga abierto." & vbCrLf
        Exit Sub
    End If

    On Error GoTo falla
    Set wsAct = wb.ActiveSheet
    Set ws = HojaResultados(wb)
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Sheets(wb.Sheets.Count))
        ws.Name = HOJA_RES
        If Not wsAct Is Nothing Then wsAct.Activate
    End If
    ws.Visible = xlSheetVisible
    ws.Cells.Clear

    ' --- metadatos
    ws.Range("A1").Value2 = MARCA
    ws.Range("B1").Value2 = Txt(SR_VER)
    ReDim t(1 To 13, 1 To 2)
    t(1, 1) = "iteraciones": t(1, 2) = n
    t(2, 1) = "simulaciones": t(2, 2) = nS
    t(3, 1) = "muestreo": t(3, 2) = Txt(gSampling)
    t(4, 1) = "semilla": t(4, 2) = gSeedUsed
    t(5, 1) = "modelo": t(5, 2) = Txt(gModelName)
    t(6, 1) = "fecha": t(6, 2) = CDbl(gSimDate)
    t(7, 1) = "duracion": t(7, 2) = gElapsed
    t(8, 1) = "conv_usada": t(8, 2) = IIf(gConvUsada, 1, 0)
    t(9, 1) = "conv_tol": t(9, 2) = gConvTol
    t(10, 1) = "conv_alcanzada": t(10, 2) = IIf(gConvAlcanzada, 1, 0)
    t(11, 1) = "entradas": t(11, 2) = nIn
    t(12, 1) = "salidas": t(12, 2) = nOut
    cj = rCorrJson
    partes = (Len(cj) + 29999) \ 30000
    t(13, 1) = "corr_partes": t(13, 2) = partes
    ws.Range("A2").Resize(13, 2).Value2 = t
    For p = 1 To partes
        ws.Cells(14 + p, 2).Value2 = Txt(Mid$(cj, (p - 1) * 30000 + 1, 30000))
    Next p

    ' --- entradas (D:G) y salidas (I:L)
    If nIn > 0 Then
        ReDim t(1 To nIn, 1 To 4)
        For Each k In rInIdx.Keys
            j = rInIdx(k)
            t(j, 1) = Txt(CStr(k))
        Next k
        For j = 1 To nIn
            t(j, 2) = Txt(rInName(j))
            t(j, 3) = Txt(rInCell(j))
            t(j, 4) = Txt(rInDist(j))
        Next j
        ws.Range("D2").Resize(nIn, 4).Value2 = t
    End If
    ReDim t(1 To nOut, 1 To 4)
    For Each k In rOutIdx.Keys
        j = rOutIdx(k)
        t(j, 1) = Txt(CStr(k))
    Next k
    For j = 1 To nOut
        t(j, 2) = Txt(rOutName(j))
        t(j, 3) = Txt(rOutCell(j))
        t(j, 4) = Txt(rOutGroup(j))
    Next j
    ws.Range("I2").Resize(nOut, 4).Value2 = t

    ' --- valores: una columna por serie (entradas y luego salidas de cada simulacion)
    ReDim v(1 To n, 1 To 1)
    col = COL_DATOS
    For s = 1 To nS
        For j = 1 To nIn
            For i = 1 To n
                v(i, 1) = gInVals(s, j, i)
            Next i
            ws.Cells(2, col).Resize(n, 1).Value2 = v
            col = col + 1
        Next j
        For j = 1 To nOut
            For i = 1 To n
                If gOutErr(s, j, i) = 0 Then v(i, 1) = gOutVals(s, j, i) Else v(i, 1) = Empty
            Next i
            ws.Cells(2, col).Resize(n, 1).Value2 = v
            col = col + 1
        Next j
    Next s
    ws.Visible = xlSheetVeryHidden
    If Not gFallidos Is Nothing Then gFallidos.RemoveAll
    Exit Sub
falla:
    gAvisos = gAvisos & "No se pudieron guardar los resultados dentro del libro (" & Err.Description & ")." & vbCrLf
    On Error Resume Next
    If Not ws Is Nothing Then ws.Visible = xlSheetVeryHidden
End Sub

' ------------------------------------------------------------
Public Function CargarResultados(ByVal wb As Workbook) As Boolean
    Dim ws As Worksheet, meta As Variant, nS As Long, nIn As Long, nOut As Long, n As Long
    Dim s As Long, j As Long, i As Long, col As Long, v As Variant, t As Variant, key As String
    Dim viejo As String, nuevo As String, partes As Long, p As Long, cj As String, x As Variant

    On Error GoTo falla
    Set ws = HojaResultados(wb)
    If ws Is Nothing Then Exit Function
    If CStr(ws.Range("A1").Value2) <> MARCA Then Exit Function
    meta = ws.Range("A2").Resize(13, 2).Value2
    n = CLng(meta(1, 2))
    nS = CLng(meta(2, 2))
    nIn = CLng(meta(11, 2))
    nOut = CLng(meta(12, 2))
    If n < 2 Or nS < 1 Or nOut < 1 Then Exit Function

    ' el libro pudo cambiar de nombre (Guardar como): se corrigen las claves
    viejo = "[" & CStr(meta(5, 2)) & "]"
    nuevo = "[" & wb.Name & "]"

    Set rInIdx = CreateObject("Scripting.Dictionary")
    Set rOutIdx = CreateObject("Scripting.Dictionary")
    rInCount = nIn
    rOutCount = nOut
    Erase rInName
    Erase rInCell
    Erase rInDist
    If nIn > 0 Then
        ReDim rInName(1 To nIn)
        ReDim rInCell(1 To nIn)
        ReDim rInDist(1 To nIn)
        t = ws.Range("D2").Resize(nIn, 4).Value2
        For j = 1 To nIn
            key = Replace(CStr(t(j, 1)), viejo, nuevo, 1, 1, vbTextCompare)
            If Not rInIdx.Exists(key) Then rInIdx.Add key, j
            rInName(j) = CStr(t(j, 2))
            rInCell(j) = CStr(t(j, 3))
            rInDist(j) = CStr(t(j, 4))
        Next j
    End If
    ReDim rOutName(1 To nOut)
    ReDim rOutCell(1 To nOut)
    ReDim rOutGroup(1 To nOut)
    t = ws.Range("I2").Resize(nOut, 4).Value2
    For j = 1 To nOut
        key = Replace(CStr(t(j, 1)), viejo, nuevo, 1, 1, vbTextCompare)
        If Not rOutIdx.Exists(key) Then rOutIdx.Add key, j
        rOutName(j) = CStr(t(j, 2))
        rOutCell(j) = CStr(t(j, 3))
        rOutGroup(j) = CStr(t(j, 4))
    Next j

    If nIn > 0 Then
        ReDim gInVals(1 To nS, 1 To nIn, 1 To n)
    Else
        ReDim gInVals(1 To nS, 1 To 1, 1 To n)
    End If
    ReDim gOutVals(1 To nS, 1 To nOut, 1 To n)
    ReDim gOutErr(1 To nS, 1 To nOut, 1 To n)
    col = COL_DATOS
    For s = 1 To nS
        For j = 1 To nIn
            v = ws.Cells(2, col).Resize(n, 1).Value2
            For i = 1 To n
                x = v(i, 1)
                If VarType(x) = vbDouble Then gInVals(s, j, i) = x
            Next i
            col = col + 1
        Next j
        For j = 1 To nOut
            v = ws.Cells(2, col).Resize(n, 1).Value2
            For i = 1 To n
                x = v(i, 1)
                If VarType(x) = vbDouble Then
                    gOutVals(s, j, i) = x
                Else
                    gOutErr(s, j, i) = 1
                End If
            Next i
            col = col + 1
        Next j
    Next s

    gItersDone = n
    gSimsDone = nS
    gSampling = CStr(meta(3, 2))
    gSeedUsed = CDbl(meta(4, 2))
    gModelName = wb.Name
    gSimDate = CDate(meta(6, 2))
    gElapsed = CDbl(meta(7, 2))
    gConvUsada = (Val(CStr(meta(8, 2))) = 1)
    gConvTol = Val(CStr(meta(9, 2)))
    gConvAlcanzada = (Val(CStr(meta(10, 2))) = 1)
    partes = CLng(meta(13, 2))
    cj = ""
    For p = 1 To partes
        cj = cj & CStr(ws.Cells(14 + p, 2).Value2)
    Next p
    rCorrJson = cj
    gLastViewer = ""
    gHasResults = True
    CargarResultados = True
    Exit Function
falla:
    gHasResults = False
    CargarResultados = False
End Function

' ------------------------------------------------------------
' Garantiza que haya resultados en memoria para el libro indicado (los carga si es necesario)
Public Function AsegurarResultados(ByVal wb As Workbook) As Boolean
    If SimulacionEnCurso() Then
        AsegurarResultados = False
        Exit Function
    End If
    If gHasResults Then
        If StrComp(gModelName, wb.Name, vbTextCompare) = 0 Then
            AsegurarResultados = True
            Exit Function
        End If
    End If
    If gFallidos Is Nothing Then Set gFallidos = CreateObject("Scripting.Dictionary")
    If gFallidos.Exists(wb.Name) Then
        AsegurarResultados = gHasResults
        Exit Function
    End If
    If LibroTieneResultados(wb) Then
        If CargarResultados(wb) Then
            AsegurarResultados = True
            Exit Function
        End If
    End If
    gFallidos(wb.Name) = True
    AsegurarResultados = gHasResults
End Function

Public Sub OlvidarFallidos()
    If Not gFallidos Is Nothing Then gFallidos.RemoveAll
End Sub

' Elimina los resultados guardados en el libro activo
Public Sub SR_BorrarResultadosLibro()
    Dim wb As Workbook, ws As Worksheet, al As Boolean
    If ActiveWorkbook Is Nothing Then Exit Sub
    Set wb = ActiveWorkbook
    Set ws = HojaResultados(wb)
    If ws Is Nothing Then
        MsgBox "Este libro no contiene resultados guardados.", vbInformation, SR_APP
        Exit Sub
    End If
    If MsgBox("Se eliminar" & ChrW$(225) & "n los resultados de simulaci" & ChrW$(243) & "n guardados en '" & wb.Name & "'." & vbCrLf & _
              "El modelo no se modifica. " & ChrW$(191) & "Continuar?", vbYesNo + vbQuestion, SR_APP) = vbNo Then Exit Sub
    On Error GoTo falla
    al = Application.DisplayAlerts
    Application.DisplayAlerts = False
    ws.Visible = xlSheetVisible
    ws.Delete
    Application.DisplayAlerts = al
    If StrComp(gModelName, wb.Name, vbTextCompare) = 0 Then gHasResults = False
    OlvidarFallidos
    Exit Sub
falla:
    Application.DisplayAlerts = al
    MsgBox "No se pudieron eliminar los resultados: " & Err.Description, vbExclamation, SR_APP
End Sub
