Attribute VB_Name = "modSRCorr"
Option Explicit

' ============================================================
'  SimRiesgo - Correlacion entre entradas (metodo de Iman-Conover)
' ============================================================
'  Cada matriz se guarda en el libro del modelo con dos nombres:
'    SR_Corr_k   -> rango de la matriz (k x k) en la hoja "SR Correlaciones"
'    SR_CorrIn_k -> union de las celdas de entrada, en el mismo orden que la matriz

Private gGrpN As Long
Private gGrpK() As Long          ' numero de entradas del grupo
Private gGrpIdx() As Variant     ' indices de entradas (1..k) por grupo
Private gGrpC() As Variant       ' matrices objetivo (1..k, 1..k) por grupo
Public gCorrJson As String       ' descripcion para el visor

' ------------------------------------------------------------
'  Lectura de las matrices definidas en el libro
' ------------------------------------------------------------
Public Sub LeerCorrelaciones(ByVal wb As Workbook)
    Dim nm As Object, k As String, rgM As Range, c As Range
    Dim idx() As Long, n As Long, i As Long, j As Long, key As String, mv As Variant
    Dim Mc() As Double, ok As Boolean, partes As String, nombres As String, reparada As Boolean

    gGrpN = 0
    gCorrJson = ""
    Erase gGrpK
    Erase gGrpIdx
    Erase gGrpC
    On Error Resume Next
    For Each nm In wb.Names
        If LCase$(Left$(nm.Name, 8)) = "sr_corr_" Then
            k = Mid$(nm.Name, 9)
            Set rgM = Nothing
            Set rgM = nm.RefersToRange
            Err.Clear
            If Not rgM Is Nothing Then
                n = rgM.Rows.Count
                ok = (n >= 2 And rgM.Columns.Count = n)
                If ok Then
                    ReDim idx(1 To n)
                    For j = 1 To n
                        Set c = Nothing
                        Set c = wb.Names("SR_CorrIn_" & k & "_" & j).RefersToRange
                        Err.Clear
                        idx(j) = 0
                        If Not c Is Nothing Then
                            key = CellKey(c.Cells(1, 1)) & "#1"
                            If Not gInIdx Is Nothing Then
                                If gInIdx.Exists(key) Then idx(j) = gInIdx(key)
                            End If
                            ' muestra la direccion actual de la celda sobre la matriz
                            If rgM.Row > 2 Then
                                If CStr(rgM.Offset(-2, 0).Cells(1, j).Value) <> CellLabel(c.Cells(1, 1)) Then _
                                    rgM.Offset(-2, 0).Cells(1, j).Value = "'" & CellLabel(c.Cells(1, 1))
                            End If
                        End If
                        If idx(j) = 0 Then ok = False
                    Next j
                End If
                If ok Then
                    mv = rgM.Value2
                    ReDim Mc(1 To n, 1 To n)
                    For i = 1 To n
                        For j = 1 To n
                            If i = j Then
                                Mc(i, j) = 1
                            Else
                                Mc(i, j) = (ValorNum(mv(i, j)) + ValorNum(mv(j, i))) / 2
                                If Mc(i, j) > 0.9999 Then Mc(i, j) = 0.9999
                                If Mc(i, j) < -0.9999 Then Mc(i, j) = -0.9999
                            End If
                        Next j
                    Next i
                    reparada = Not EsDefinidaPositiva(Mc, n)
                    If reparada Then
                        RepararMatriz Mc, n
                        gAvisos = gAvisos & "La matriz de correlaci" & ChrW$(243) & "n " & k & _
                                  " no era coherente (no definida positiva); se us" & ChrW$(243) & _
                                  " la matriz v" & ChrW$(225) & "lida m" & ChrW$(225) & "s cercana." & vbCrLf
                    End If
                    gGrpN = gGrpN + 1
                    ReDim Preserve gGrpK(1 To gGrpN)
                    ReDim Preserve gGrpIdx(1 To gGrpN)
                    ReDim Preserve gGrpC(1 To gGrpN)
                    gGrpK(gGrpN) = n
                    gGrpIdx(gGrpN) = idx
                    gGrpC(gGrpN) = Mc
                    ' descripcion para el visor (indices de entrada base 0)
                    nombres = ""
                    For i = 1 To n
                        nombres = nombres & IIf(i > 1, ",", "") & CStr(idx(i) - 1)
                    Next i
                    partes = ""
                    For i = 1 To n
                        partes = partes & IIf(i > 1, ",", "") & "["
                        For j = 1 To n
                            partes = partes & IIf(j > 1, ",", "") & NumJ(Round(Mc(i, j), 6))
                        Next j
                        partes = partes & "]"
                    Next i
                    gCorrJson = gCorrJson & IIf(Len(gCorrJson) > 0, ",", "") & "{""name"":" & JsonStr("Matriz " & k) & _
                        ",""vars"":[" & nombres & "],""target"":[" & partes & "],""fixed"":" & IIf(reparada, "true", "false") & "}"
                Else
                    gAvisos = gAvisos & "La matriz de correlaci" & ChrW$(243) & "n " & k & " se ignor" & ChrW$(243) & _
                              ": alguna de sus celdas ya no contiene una distribuci" & ChrW$(243) & "n." & vbCrLf
                End If
            End If
        End If
    Next nm
    On Error GoTo 0
End Sub

Private Function ValorNum(ByVal v As Variant) As Double
    If VarType(v) = vbDouble Then ValorNum = v Else ValorNum = 0
End Function

' ------------------------------------------------------------
'  Algebra matricial
' ------------------------------------------------------------
' Factorizacion de Cholesky (L triangular inferior). Devuelve False si no es definida positiva.
Private Function Cholesky(ByRef A() As Double, ByVal n As Long, ByRef L() As Double) As Boolean
    Dim i As Long, j As Long, k As Long, s As Double
    ReDim L(1 To n, 1 To n)
    For i = 1 To n
        For j = 1 To i
            s = A(i, j)
            For k = 1 To j - 1
                s = s - L(i, k) * L(j, k)
            Next k
            If i = j Then
                If s <= 0.0000000001 Then Exit Function
                L(i, i) = Sqr(s)
            Else
                L(i, j) = s / L(j, j)
            End If
        Next j
    Next i
    Cholesky = True
End Function

Private Function EsDefinidaPositiva(ByRef A() As Double, ByVal n As Long) As Boolean
    Dim L() As Double
    EsDefinidaPositiva = Cholesky(A, n, L)
End Function

' Valores y vectores propios de una matriz simetrica (metodo de Jacobi)
Private Sub Jacobi(ByRef A() As Double, ByVal n As Long, ByRef d() As Double, ByRef V() As Double)
    Dim i As Long, j As Long, p As Long, q As Long, it As Long
    Dim B() As Double, off As Double, theta As Double, t As Double, c As Double, s As Double
    Dim app As Double, aqq As Double, apq As Double, aip As Double, aiq As Double, vip As Double, viq As Double
    ReDim B(1 To n, 1 To n)
    ReDim V(1 To n, 1 To n)
    ReDim d(1 To n)
    For i = 1 To n
        For j = 1 To n
            B(i, j) = A(i, j)
        Next j
        V(i, i) = 1
    Next i
    For it = 1 To 100
        off = 0
        For p = 1 To n - 1
            For q = p + 1 To n
                off = off + B(p, q) ^ 2
            Next q
        Next p
        If off < 1E-22 Then Exit For
        For p = 1 To n - 1
            For q = p + 1 To n
                If Abs(B(p, q)) > 1E-15 Then
                    app = B(p, p): aqq = B(q, q): apq = B(p, q)
                    theta = (aqq - app) / (2 * apq)
                    t = Sgn(theta) / (Abs(theta) + Sqr(theta * theta + 1))
                    If theta = 0 Then t = 1
                    c = 1 / Sqr(t * t + 1)
                    s = t * c
                    For i = 1 To n
                        If i <> p And i <> q Then
                            aip = B(i, p): aiq = B(i, q)
                            B(i, p) = c * aip - s * aiq: B(p, i) = B(i, p)
                            B(i, q) = s * aip + c * aiq: B(q, i) = B(i, q)
                        End If
                    Next i
                    B(p, p) = app - t * apq
                    B(q, q) = aqq + t * apq
                    B(p, q) = 0: B(q, p) = 0
                    For i = 1 To n
                        vip = V(i, p): viq = V(i, q)
                        V(i, p) = c * vip - s * viq
                        V(i, q) = s * vip + c * viq
                    Next i
                End If
            Next q
        Next p
    Next it
    For i = 1 To n
        d(i) = B(i, i)
    Next i
End Sub

' Ajusta una matriz no definida positiva: recorta los valores propios y reescala a diagonal 1
Private Sub RepararMatriz(ByRef C() As Double, ByVal n As Long)
    Dim d() As Double, V() As Double, i As Long, j As Long, k As Long, s As Double, it As Long
    For it = 1 To 20
        Jacobi C, n, d, V
        For k = 1 To n
            If d(k) < 0.0001 Then d(k) = 0.0001
        Next k
        For i = 1 To n
            For j = 1 To n
                s = 0
                For k = 1 To n
                    s = s + V(i, k) * d(k) * V(j, k)
                Next k
                C(i, j) = s
            Next j
        Next i
        For i = 1 To n
            d(i) = Sqr(C(i, i))
        Next i
        For i = 1 To n
            For j = 1 To n
                C(i, j) = C(i, j) / (d(i) * d(j))
            Next j
            C(i, i) = 1
        Next i
        If EsDefinidaPositiva(C, n) Then Exit For
    Next it
End Sub

' Inversa de una matriz triangular inferior
Private Sub InversaTriInf(ByRef L() As Double, ByVal n As Long, ByRef Li() As Double)
    Dim i As Long, j As Long, k As Long, s As Double
    ReDim Li(1 To n, 1 To n)
    For i = 1 To n
        Li(i, i) = 1 / L(i, i)
        For j = 1 To i - 1
            s = 0
            For k = j To i - 1
                s = s + L(i, k) * Li(k, j)
            Next k
            Li(i, j) = -s / L(i, i)
        Next j
    Next i
End Sub

' ------------------------------------------------------------
'  Aplicacion: reordena las columnas de gU (muestras uniformes) para inducir la
'  correlacion de rangos objetivo sin alterar las distribuciones marginales.
' ------------------------------------------------------------
Public Sub AplicarCorrelaciones(ByVal n As Long)
    Dim g As Long, k As Long, i As Long, j As Long, l As Long, idx As Variant, C As Variant
    Dim R() As Double, sc() As Double, perm() As Long, tmp As Long, kk As Long
    Dim T() As Double, P() As Double, Q() As Double, Qi() As Double, M() As Double, Cm() As Double
    Dim col() As Double, ix() As Long, us() As Double, mu As Double, sd() As Double

    If gGrpN = 0 Or n < 3 Then Exit Sub
    ReDim sc(1 To n)
    For i = 1 To n
        sc(i) = NormSInv(i / (n + 1))
    Next i
    For g = 1 To gGrpN
        k = gGrpK(g)
        idx = gGrpIdx(g)
        C = gGrpC(g)
        ' 1. matriz de puntajes con permutaciones aleatorias independientes
        ReDim R(1 To n, 1 To k)
        ReDim perm(1 To n)
        For j = 1 To k
            For i = 1 To n
                perm(i) = i
            Next i
            For i = n To 2 Step -1
                kk = Int(RngNext() * i) + 1
                If kk > i Then kk = i
                tmp = perm(i): perm(i) = perm(kk): perm(kk) = tmp
            Next i
            For i = 1 To n
                R(i, j) = sc(perm(i))
            Next i
        Next j
        ' 2. correlacion real T de los puntajes y factores de Cholesky
        ReDim T(1 To k, 1 To k)
        ReDim sd(1 To k)
        For j = 1 To k
            For l = 1 To k
                mu = 0
                For i = 1 To n
                    mu = mu + R(i, j) * R(i, l)
                Next i
                T(j, l) = mu
            Next l
        Next j
        For j = 1 To k
            sd(j) = Sqr(T(j, j))
        Next j
        For j = 1 To k
            For l = 1 To k
                T(j, l) = T(j, l) / (sd(j) * sd(l))
            Next l
        Next j
        ' correlacion de Pearson de los puntajes normales que produce la de Spearman pedida:
        ' rho = 2 sen(pi * rs / 6)
        ReDim Cm(1 To k, 1 To k)
        For j = 1 To k
            For l = 1 To k
                If j = l Then Cm(j, l) = 1 Else Cm(j, l) = 2 * Sin(3.14159265358979 * C(j, l) / 6)
            Next l
        Next j
        If Not Cholesky(Cm, k, P) Then
            For j = 1 To k
                For l = 1 To k
                    Cm(j, l) = C(j, l)
                Next l
            Next j
            If Not Cholesky(Cm, k, P) Then GoTo siguiente
        End If
        If Not Cholesky(T, k, Q) Then GoTo siguiente
        InversaTriInf Q, k, Qi
        ' 3. M = (P * Q^-1)^T ;  R* = R * M
        ReDim M(1 To k, 1 To k)
        For j = 1 To k
            For l = 1 To k
                mu = 0
                For i = 1 To k
                    mu = mu + P(l, i) * Qi(i, j)
                Next i
                M(j, l) = mu
            Next l
        Next j
        ReDim col(1 To n)
        ReDim ix(1 To n)
        ReDim us(1 To n)
        For j = 1 To k
            ' columna objetivo R*(:, j)
            For i = 1 To n
                mu = 0
                For l = 1 To k
                    mu = mu + R(i, l) * M(l, j)
                Next l
                col(i) = mu
                ix(i) = i
            Next i
            OrdenarIdx col, ix, 1, n
            ' 4. valores uniformes de la entrada, ordenados
            For i = 1 To n
                us(i) = gU(idx(j), i)
            Next i
            OrdenarD us, 1, n
            ' 5. la iteracion con el rango r recibe el r-esimo valor uniforme
            For i = 1 To n
                gU(idx(j), ix(i)) = us(i)
            Next i
        Next j
siguiente:
    Next g
End Sub

' ------------------------------------------------------------
'  Comando de la cinta: crear una matriz de correlacion para las celdas seleccionadas
' ------------------------------------------------------------
Public Sub SR_DefinirCorrelaciones()
    Dim sel As Range, c As Range, wb As Workbook, ws As Worksheet, calcMode As Long
    Dim celdas() As Range, nombres() As String, n As Long, k As Long, r0 As Long, i As Long, j As Long
    Dim refs As String, key As String, rgM As Range, nm As Object

    If TypeName(Selection) <> "Range" Then Exit Sub
    Set sel = Selection
    Set wb = sel.Worksheet.Parent
    calcMode = Application.Calculation
    Application.Calculation = xlCalculationManual
    RegistrarModelo
    Application.Calculation = calcMode

    ReDim celdas(1 To sel.Cells.Count)
    ReDim nombres(1 To sel.Cells.Count)
    For Each c In sel.Cells
        key = CellKey(c) & "#1"
        If Not gInIdx Is Nothing Then
            If gInIdx.Exists(key) Then
                n = n + 1
                Set celdas(n) = c
                nombres(n) = gInName(gInIdx(key))
            End If
        End If
    Next c
    If n < 2 Then
        MsgBox "Seleccione al menos dos celdas que contengan distribuciones (puede usar Ctrl + clic).", vbExclamation, SR_APP
        Exit Sub
    End If
    If n > 30 Then
        MsgBox "Una matriz admite como m" & ChrW$(225) & "ximo 30 entradas.", vbExclamation, SR_APP
        Exit Sub
    End If

    ' siguiente numero de matriz libre
    k = 1
    On Error Resume Next
    Do
        Set nm = Nothing
        Set nm = wb.Names("SR_Corr_" & k)
        If nm Is Nothing Then Exit Do
        k = k + 1
    Loop
    Set ws = Nothing
    Set ws = wb.Worksheets("SR Correlaciones")
    On Error GoTo falla
    Application.ScreenUpdating = False
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        ws.Name = "SR Correlaciones"
        ActiveWindow.DisplayGridlines = False
        ws.Range("A1").Value = "Matrices de correlaci" & ChrW$(243) & "n de rangos (SimRiesgo)"
        ws.Range("A1").Font.Bold = True
        ws.Range("A1").Font.Size = 13
        ws.Range("A2").Value = "Edite solo el tri" & ChrW$(225) & "ngulo superior (celdas blancas): el inferior se completa solo. Valores entre -1 y 1."
        ws.Range("A2").Font.Italic = True
        ws.Range("A2").Font.Color = RGB(124, 123, 119)
        ws.Columns(1).ColumnWidth = 28
        r0 = 4
    Else
        r0 = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 3
        If r0 < 4 Then r0 = 4
    End If

    ws.Cells(r0, 1).Value = "Matriz " & k
    ws.Cells(r0, 1).Font.Bold = True
    ws.Cells(r0, 1).Font.Color = RGB(154, 61, 12)
    For i = 1 To n
        ws.Cells(r0 + 1, 1 + i).Value = nombres(i)
        ws.Cells(r0 + 1 + i, 1).Value = nombres(i)
    Next i
    With ws.Range(ws.Cells(r0 + 1, 2), ws.Cells(r0 + 1, 1 + n))
        .Font.Bold = True
        .WrapText = True
        .HorizontalAlignment = xlCenter
        .Interior.Color = RGB(253, 240, 231)
    End With
    ws.Range(ws.Cells(r0 + 2, 1), ws.Cells(r0 + 1 + n, 1)).Font.Bold = True
    ws.Range(ws.Cells(r0 + 2, 1), ws.Cells(r0 + 1 + n, 1)).Interior.Color = RGB(253, 240, 231)
    Set rgM = ws.Range(ws.Cells(r0 + 2, 2), ws.Cells(r0 + 1 + n, 1 + n))
    For i = 1 To n
        For j = 1 To n
            With rgM.Cells(i, j)
                If i = j Then
                    .Value = 1
                    .Interior.Color = RGB(236, 235, 232)
                ElseIf j > i Then
                    .Value = 0
                    .Interior.Color = RGB(255, 255, 255)
                    .Validation.Delete
                    .Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="-1", Formula2:="1"
                Else
                    .Formula = "=" & rgM.Cells(j, i).Address(False, False)
                    .Interior.Color = RGB(246, 246, 244)
                    .Font.Color = RGB(124, 123, 119)
                End If
                .NumberFormat = "0.00"
                .HorizontalAlignment = xlCenter
            End With
        Next j
    Next i
    rgM.Borders.LineStyle = xlContinuous
    rgM.Borders.Color = RGB(217, 216, 212)
    For j = 2 To 1 + n
        If ws.Columns(j).ColumnWidth < 14 Then ws.Columns(j).ColumnWidth = 14
    Next j

    For i = 1 To n
        refs = "='" & Replace(celdas(i).Worksheet.Name, "'", "''") & "'!" & celdas(i).Address
        wb.Names.Add Name:="SR_CorrIn_" & k & "_" & i, RefersTo:=refs, Visible:=False
        ws.Cells(r0, 1 + i).Value = "'" & CellLabel(celdas(i))
    Next i
    With ws.Range(ws.Cells(r0, 2), ws.Cells(r0, 1 + n))
        .Font.Size = 8
        .Font.Color = RGB(150, 149, 145)
        .HorizontalAlignment = xlCenter
    End With
    wb.Names.Add Name:="SR_Corr_" & k, RefersTo:="='" & Replace(ws.Name, "'", "''") & "'!" & rgM.Address

    Application.ScreenUpdating = True
    ws.Activate
    rgM.Cells(1, 2).Select
    MsgBox "Se cre" & ChrW$(243) & " la matriz " & k & " en la hoja 'SR Correlaciones'." & vbCrLf & _
           "Escriba los coeficientes en el tri" & ChrW$(225) & "ngulo superior y vuelva a simular.", vbInformation, SR_APP
    Exit Sub
falla:
    Application.ScreenUpdating = True
    MsgBox "No se pudo crear la matriz de correlaci" & ChrW$(243) & "n: " & Err.Description, vbExclamation, SR_APP
End Sub

' ------------------------------------------------------------
'  Lee las matrices usadas en la ultima simulacion (desde rCorrJson)
' ------------------------------------------------------------
Public Function CorrGrupos(ByRef nombres() As String, ByRef vars() As Variant, ByRef obj() As Variant) As Long
    Dim s As String, p As Long, q As Long, ng As Long, txt As String, filas() As String, i As Long, j As Long
    Dim vv() As String, vl() As Long, fila() As String, mm() As Variant, nums() As Double
    On Error GoTo fin
    s = rCorrJson
    p = InStr(1, s, """name"":""")
    Do While p > 0
        ng = ng + 1
        ReDim Preserve nombres(1 To ng)
        ReDim Preserve vars(1 To ng)
        ReDim Preserve obj(1 To ng)
        q = InStr(p + 8, s, """")
        nombres(ng) = Mid$(s, p + 8, q - p - 8)
        p = InStr(q, s, """vars"":[")
        q = InStr(p, s, "]")
        txt = Mid$(s, p + 8, q - p - 8)
        vv = Split(txt, ",")
        ReDim vl(0 To UBound(vv))
        For i = 0 To UBound(vv)
            vl(i) = CLng(Val(vv(i)))
        Next i
        vars(ng) = vl
        p = InStr(q, s, """target"":[[")
        q = InStr(p, s, "]]")
        txt = Mid$(s, p + 11, q - p - 11)
        filas = Split(txt, "],[")
        ReDim mm(0 To UBound(filas))
        For i = 0 To UBound(filas)
            fila = Split(filas(i), ",")
            ReDim nums(0 To UBound(fila))
            For j = 0 To UBound(fila)
                nums(j) = Val(fila(j))
            Next j
            mm(i) = nums
        Next i
        obj(ng) = mm
        p = InStr(q, s, """name"":""")
    Loop
fin:
    CorrGrupos = ng
End Function

' Gancho de prueba: define un unico grupo sin leer el libro
Public Function GrupoPrueba(ByRef idx() As Long, ByRef Mc() As Double, ByVal n As Long) As Boolean
    Dim i As Long, j As Long, C() As Double
    ReDim C(1 To n, 1 To n)
    For i = 1 To n
        For j = 1 To n
            C(i, j) = Mc(i, j)
        Next j
    Next i
    GrupoPrueba = Not EsDefinidaPositiva(C, n)
    If GrupoPrueba Then RepararMatriz C, n
    For i = 1 To n
        For j = 1 To n
            Mc(i, j) = C(i, j)
        Next j
    Next i
    gGrpN = 1
    ReDim gGrpK(1 To 1)
    ReDim gGrpIdx(1 To 1)
    ReDim gGrpC(1 To 1)
    gGrpK(1) = n
    gGrpIdx(1) = idx
    gGrpC(1) = C
End Function
