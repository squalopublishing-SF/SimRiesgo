Attribute VB_Name = "modSRMotor"
Option Explicit

' ============================================================
'  SimRiesgo - Motor de simulacion Monte Carlo para Excel
' ============================================================

Public Const SR_APP As String = "SimRiesgo"
Public Const SR_VER As String = "2.0"

' Modo de trabajo: 0 = estatico/inactivo, 1 = registro del modelo, 2 = simulando
Public gMode As Integer
Public gIter As Long
Public gSim As Long
Public gPass As Long
Public gRandomMode As Boolean
Private gRunning As Boolean

' ---- Entradas (distribuciones) ----
Public gInIdx As Object
Public gInCount As Long
Public gInName() As String
Public gInCell() As String
Public gInDist() As String

' ---- Salidas ----
Public gOutIdx As Object
Public gOutCount As Long
Public gOutName() As String
Public gOutCell() As String
Public gOutGroup() As String
Public gOutRng() As Range

' ---- Nombres usados (para evitar duplicados) ----
Private gNames As Object

' ---- Control de ordinal por celda (varias distribuciones en una celda) ----
Private gCellIdx As Object
Private gCellStamp() As Long
Private gCellCnt() As Long
Private gCellN() As Long
Private gCellCount As Long

' ---- Muestras y resultados ----
Public gU() As Double
Public gInVals() As Double
Public gOutVals() As Double
Public gOutErr() As Byte
Public gHasResults As Boolean
Public gItersDone As Long
Public gSimsDone As Long
Public gSampling As String
Public gSeedUsed As Double
Public gModelName As String
Public gSimDate As Date
Public gElapsed As Double
Public gLastViewer As String
Public gConvAlcanzada As Boolean
Public gConvUsada As Boolean
Public gConvTol As Double
Public gAvisos As String
Public gCancel As Boolean

' ---- Copia del modelo asociada a los resultados de la ultima simulacion ----
Public rInIdx As Object
Public rOutIdx As Object
Public rInCount As Long
Public rOutCount As Long
Public rInName() As String
Public rInCell() As String
Public rInDist() As String
Public rOutName() As String
Public rOutCell() As String
Public rOutGroup() As String
Public rCorrJson As String

' ---- Generador MRG32k3a (L'Ecuyer) ----
Private s10 As Double, s11 As Double, s12 As Double
Private s20 As Double, s21 As Double, s22 As Double
Private rngInit As Boolean

Private Const M1 As Double = 4294967087#
Private Const M2 As Double = 4294944443#
Private Const NORM As Double = 2.32830654929573E-10

' ============================================================
'  Generador de numeros aleatorios
' ============================================================
Private Function FMod(ByVal a As Double, ByVal m As Double) As Double
    Dim r As Double
    r = a - Int(a / m) * m
    If r < 0 Then r = r + m
    If r >= m Then r = r - m
    FMod = r
End Function

Public Sub RngSeed(ByVal seed As Double)
    Dim x As Double, i As Long
    x = FMod(Abs(Int(seed)), 2147483647#) + 1#
    x = FMod(69069# * x + 1#, 4294967296#): s10 = FMod(x, M1)
    x = FMod(69069# * x + 1#, 4294967296#): s11 = FMod(x, M1)
    x = FMod(69069# * x + 1#, 4294967296#): s12 = FMod(x, M1)
    x = FMod(69069# * x + 1#, 4294967296#): s20 = FMod(x, M2)
    x = FMod(69069# * x + 1#, 4294967296#): s21 = FMod(x, M2)
    x = FMod(69069# * x + 1#, 4294967296#): s22 = FMod(x, M2)
    If s10 = 0 And s11 = 0 And s12 = 0 Then s10 = 12345#
    If s20 = 0 And s21 = 0 And s22 = 0 Then s20 = 12345#
    rngInit = True
    For i = 1 To 20
        x = RngNext()
    Next i
End Sub

Public Function EstadoRng() As Variant
    EstadoRng = Array(s10, s11, s12, s20, s21, s22, rngInit)
End Function

Public Sub FijarRng(ByVal e As Variant)
    s10 = e(0): s11 = e(1): s12 = e(2): s20 = e(3): s21 = e(4): s22 = e(5): rngInit = e(6)
End Sub

Public Function RngNext() As Double
    Dim p1 As Double, p2 As Double
    If Not rngInit Then
        Randomize
        RngSeed Int(Timer * 1000#) + Int(Rnd() * 1000000#)
    End If
    p1 = 1403580# * s11 - 810728# * s10
    p1 = p1 - Int(p1 / M1) * M1
    If p1 < 0 Then p1 = p1 + M1
    If p1 >= M1 Then p1 = p1 - M1
    s10 = s11: s11 = s12: s12 = p1
    p2 = 527612# * s22 - 1370589# * s20
    p2 = p2 - Int(p2 / M2) * M2
    If p2 < 0 Then p2 = p2 + M2
    If p2 >= M2 Then p2 = p2 - M2
    s20 = s21: s21 = s22: s22 = p2
    If p1 > p2 Then
        RngNext = (p1 - p2) * NORM
    Else
        RngNext = (p1 - p2 + M1) * NORM
    End If
End Function

' ============================================================
'  Identificacion de la celda que llama
' ============================================================
Public Function CallerCell(ByRef c As Range) As Boolean
    On Error GoTo nope
    If TypeName(Application.Caller) <> "Range" Then GoTo nope
    Set c = Application.Caller.Cells(1, 1)
    CallerCell = True
    Exit Function
nope:
    CallerCell = False
End Function

Public Function CellKey(ByVal c As Range) As String
    CellKey = "[" & c.Worksheet.Parent.Name & "]" & c.Worksheet.Name & "!" & c.Address(False, False)
End Function

Public Function CellLabel(ByVal c As Range) As String
    CellLabel = c.Worksheet.Name & "!" & c.Address(False, False)
End Function

' Cuenta cuantas funciones de distribucion hay en la formula de una celda
Private Function CountDistTokens(ByVal c As Range) As Long
    Dim f As String, names As Variant, i As Long, n As Long, p As Long
    On Error Resume Next
    f = UCase$(c.Formula)
    On Error GoTo 0
    names = Array("SRNORMAL(", "SRTRIANGULAR(", "SRPERT(", "SRUNIFORME(", "SRLOGNORMAL(", _
                  "SRWEIBULL(", "SREXPONENCIAL(", "SRGAMMA(", "SRBETA(", "SRPOISSON(", _
                  "SRBINOMIAL(", "SRBERNOULLI(", "SRDISCRETA(", "SRLOGLOGISTICA(", "SRPEARSON5(", _
                  "SRNORMALTRUNC(", "SREMPIRICA(")
    For i = LBound(names) To UBound(names)
        p = InStr(1, f, names(i), vbBinaryCompare)
        Do While p > 0
            n = n + 1
            p = InStr(p + 1, f, names(i), vbBinaryCompare)
        Loop
    Next i
    If n < 1 Then n = 1
    CountDistTokens = n
End Function

' Devuelve el numero de orden de la llamada dentro de la celda en el recalculo actual
Public Function NextOrdinal(ByVal key As String, ByVal c As Range) As Long
    Dim i As Long
    If gCellIdx Is Nothing Then ResetCells
    If gCellIdx.Exists(key) Then
        i = gCellIdx(key)
        If gCellStamp(i) <> gPass Then
            gCellStamp(i) = gPass
            gCellCnt(i) = 1
        Else
            gCellCnt(i) = gCellCnt(i) + 1
            If gCellCnt(i) > gCellN(i) Then gCellCnt(i) = 1
        End If
    Else
        gCellCount = gCellCount + 1
        i = gCellCount
        If i > UBound(gCellStamp) Then
            ReDim Preserve gCellStamp(1 To 2 * UBound(gCellStamp))
            ReDim Preserve gCellCnt(1 To UBound(gCellStamp))
            ReDim Preserve gCellN(1 To UBound(gCellStamp))
        End If
        gCellIdx.Add key, i
        gCellStamp(i) = gPass
        gCellCnt(i) = 1
        gCellN(i) = CountDistTokens(c)
    End If
    NextOrdinal = gCellCnt(i)
End Function

Private Sub ResetCells()
    Set gCellIdx = CreateObject("Scripting.Dictionary")
    gCellCount = 0
    ReDim gCellStamp(1 To 64)
    ReDim gCellCnt(1 To 64)
    ReDim gCellN(1 To 64)
End Sub

Public Sub ResetRegistry()
    Set gInIdx = CreateObject("Scripting.Dictionary")
    Set gOutIdx = CreateObject("Scripting.Dictionary")
    Set gNames = CreateObject("Scripting.Dictionary")
    gNames.CompareMode = vbTextCompare
    gInCount = 0
    gOutCount = 0
    Erase gInName
    Erase gInCell
    Erase gInDist
    Erase gOutName
    Erase gOutCell
    Erase gOutGroup
    Erase gOutRng
    ResetCells
End Sub

' ============================================================
'  Nombres automaticos
' ============================================================
Private Function TextoIzquierda(ByVal c As Range) As String
    Dim col As Long, v As Variant, lim As Long
    On Error Resume Next
    lim = c.Column - 10
    If lim < 1 Then lim = 1
    For col = c.Column - 1 To lim Step -1
        v = c.Worksheet.Cells(c.Row, col).Value
        If VarType(v) = vbString Then
            If Len(Trim$(v)) > 0 Then
                TextoIzquierda = Trim$(v)
                Exit Function
            End If
        End If
    Next col
End Function

Private Function TextoArriba(ByVal c As Range) As String
    Dim r As Long, v As Variant, lim As Long
    On Error Resume Next
    lim = c.Row - 40
    If lim < 1 Then lim = 1
    For r = c.Row - 1 To lim Step -1
        v = c.Worksheet.Cells(r, c.Column).Value
        If VarType(v) = vbString Then
            If Len(Trim$(v)) > 0 Then
                TextoArriba = Trim$(v)
                Exit Function
            End If
        End If
    Next r
End Function

Private Function NombreUnico(ByVal nombre As String, ByVal c As Range) As String
    Dim nm As String, tp As String, k As Long
    nm = nombre
    If gNames Is Nothing Then
        Set gNames = CreateObject("Scripting.Dictionary")
        gNames.CompareMode = vbTextCompare
    End If
    If gNames.Exists(nm) Then
        tp = TextoArriba(c)
        If Len(tp) > 0 And StrComp(tp, nm, vbTextCompare) <> 0 Then nm = nombre & " / " & tp
    End If
    If gNames.Exists(nm) Then nm = nombre & " (" & c.Address(False, False) & ")"
    k = 2
    Do While gNames.Exists(nm)
        nm = nombre & " (" & k & ")"
        k = k + 1
    Loop
    gNames.Add nm, 1
    NombreUnico = nm
End Function

Public Function NombreDeArg(ByVal v As Variant) As String
    Dim rg As Object
    On Error GoTo fin
    If IsMissing(v) Then GoTo fin
    If TypeName(v) = "Range" Then
        Set rg = v
        NombreDeArg = Trim$(CStr(rg.Cells(1, 1).Value))
    ElseIf IsError(v) Or IsEmpty(v) Or IsNull(v) Then
        NombreDeArg = ""
    Else
        NombreDeArg = Trim$(CStr(v))
    End If
    Exit Function
fin:
    NombreDeArg = ""
End Function

Private Function NombreAuto(ByVal c As Range) As String
    Dim lt As String, tp As String
    lt = TextoIzquierda(c)
    If Len(lt) > 0 Then
        NombreAuto = lt
    Else
        tp = TextoArriba(c)
        If Len(tp) > 0 Then
            NombreAuto = tp
        Else
            NombreAuto = CellLabel(c)
        End If
    End If
End Function

' ============================================================
'  Registro de entradas y salidas
' ============================================================
Public Sub RegisterInput(ByVal k As String, ByVal c As Range, ByVal ord As Long, _
                         ByVal desc As String, ByVal nombre As Variant)
    Dim nm As String
    If gInIdx Is Nothing Then ResetRegistry
    If gInIdx.Exists(k) Then Exit Sub
    gInCount = gInCount + 1
    ReDim Preserve gInName(1 To gInCount)
    ReDim Preserve gInCell(1 To gInCount)
    ReDim Preserve gInDist(1 To gInCount)
    gInIdx.Add k, gInCount
    nm = NombreDeArg(nombre)
    If Len(nm) = 0 Then nm = NombreAuto(c)
    If ord > 1 Then nm = nm & " [" & ord & "]"
    gInName(gInCount) = NombreUnico(nm, c)
    gInCell(gInCount) = CellLabel(c)
    gInDist(gInCount) = desc
End Sub

Public Sub RegisterOutput(ByVal c As Range, ByVal nombre As Variant, ByVal grupo As Variant)
    Dim k As String, nm As String, gr As String
    If gOutIdx Is Nothing Then ResetRegistry
    k = CellKey(c)
    If gOutIdx.Exists(k) Then Exit Sub
    gOutCount = gOutCount + 1
    ReDim Preserve gOutName(1 To gOutCount)
    ReDim Preserve gOutCell(1 To gOutCount)
    ReDim Preserve gOutGroup(1 To gOutCount)
    ReDim Preserve gOutRng(1 To gOutCount)
    gOutIdx.Add k, gOutCount
    gr = NombreDeArg(grupo)
    nm = NombreDeArg(nombre)
    If Len(nm) = 0 Then
        If Len(gr) > 0 Then
            nm = TextoArriba(c)
            If Len(nm) = 0 Then nm = c.Address(False, False)
            nm = gr & " / " & nm
        Else
            nm = NombreAuto(c)
        End If
    End If
    gOutName(gOutCount) = NombreUnico(nm, c)
    gOutCell(gOutCount) = CellLabel(c)
    gOutGroup(gOutCount) = gr
    Set gOutRng(gOutCount) = c
End Sub

' Recorre el modelo (recalculo completo) para identificar entradas y salidas
Public Function RegistrarModelo() As Boolean
    ResetRegistry
    gMode = 1
    gPass = gPass + 1
    On Error Resume Next
    Application.CalculateFull
    If Err.Number <> 0 Then
        Err.Clear
        Application.Calculate
    End If
    RegistrarModelo = (Err.Number = 0)
    gMode = 0
End Function

' ============================================================
'  Generacion de numeros uniformes (Monte Carlo o Hipercubo latino)
' ============================================================
Public Sub GenerarU(ByVal n As Long, ByVal lhs As Boolean)
    Dim j As Long, i As Long, k As Long, tmp As Long, m As Long
    Dim perm() As Long
    m = gInCount
    If m < 1 Then m = 1
    ReDim gU(1 To m, 1 To n)
    ReDim perm(1 To n)
    For j = 1 To gInCount
        If lhs Then
            For i = 1 To n
                perm(i) = i
            Next i
            For i = n To 2 Step -1
                k = Int(RngNext() * i) + 1
                If k > i Then k = i
                tmp = perm(i): perm(i) = perm(k): perm(k) = tmp
            Next i
            For i = 1 To n
                gU(j, i) = (perm(i) - 1 + RngNext()) / n
            Next i
        Else
            For i = 1 To n
                gU(j, i) = RngNext()
            Next i
        End If
    Next j
End Sub

Public Function SimulacionEnCurso() As Boolean
    SimulacionEnCurso = gRunning
End Function

Public Sub MarcarEjecucion(ByVal activo As Boolean)
    gRunning = activo
End Sub

' Guarda una copia del registro del modelo junto con los resultados
Public Sub TomarFoto()
    Dim k As Variant, j As Long
    rCorrJson = gCorrJson
    Set rInIdx = CreateObject("Scripting.Dictionary")
    Set rOutIdx = CreateObject("Scripting.Dictionary")
    For Each k In gInIdx.Keys
        rInIdx.Add k, gInIdx(k)
    Next k
    For Each k In gOutIdx.Keys
        rOutIdx.Add k, gOutIdx(k)
    Next k
    rInCount = gInCount
    rOutCount = gOutCount
    If gInCount > 0 Then
        ReDim rInName(1 To gInCount)
        ReDim rInCell(1 To gInCount)
        ReDim rInDist(1 To gInCount)
        For j = 1 To gInCount
            rInName(j) = gInName(j)
            rInCell(j) = gInCell(j)
            rInDist(j) = gInDist(j)
        Next j
    End If
    ReDim rOutName(1 To gOutCount)
    ReDim rOutCell(1 To gOutCount)
    ReDim rOutGroup(1 To gOutCount)
    For j = 1 To gOutCount
        rOutName(j) = gOutName(j)
        rOutCell(j) = gOutCell(j)
        rOutGroup(j) = gOutGroup(j)
    Next j
End Sub

' ============================================================
'  Datos de una serie (para estadisticos e informes)
' ============================================================
' Devuelve el numero de valores validos copiados en arr (1..n)
Public Function DatosSerie(ByVal esSalida As Boolean, ByVal s As Long, ByVal idx As Long, ByRef arr() As Double) As Long
    Dim i As Long, n As Long
    If Not gHasResults Then
        DatosSerie = 0
        Exit Function
    End If
    ReDim arr(1 To gItersDone)
    For i = 1 To gItersDone
        If esSalida Then
            If gOutErr(s, idx, i) = 0 Then
                n = n + 1
                arr(n) = gOutVals(s, idx, i)
            End If
        Else
            n = n + 1
            arr(n) = gInVals(s, idx, i)
        End If
    Next i
    DatosSerie = n
End Function
