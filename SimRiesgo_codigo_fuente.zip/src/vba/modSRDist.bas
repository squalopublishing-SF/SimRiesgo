Attribute VB_Name = "modSRDist"
Option Explicit

' ============================================================
'  SimRiesgo - Funciones de distribucion (entradas del modelo)
' ============================================================

Public Const D_NORMAL As Long = 1
Public Const D_TRIANG As Long = 2
Public Const D_PERT As Long = 3
Public Const D_UNIF As Long = 4
Public Const D_LOGN As Long = 5
Public Const D_WEIB As Long = 6
Public Const D_EXPO As Long = 7
Public Const D_GAMMA As Long = 8
Public Const D_BETA As Long = 9
Public Const D_POIS As Long = 10
Public Const D_BINOM As Long = 11
Public Const D_BERN As Long = 12
Public Const D_DISC As Long = 13
Public Const D_LOGLOG As Long = 14
Public Const D_PEARSON5 As Long = 15
Public Const D_NTRUNC As Long = 16
Public Const D_EMPIR As Long = 17
Private Const PI_ As Double = 3.14159265358979

' Datos ordenados de la distribucion empirica en evaluacion (con cache por celda)
Private eV() As Double
Private eN As Long
Private gEmpCache As Object

' Valores temporales de la distribucion discreta en evaluacion
Private dV() As Double
Private dC() As Double
Private dN As Long

' ------------------------------------------------------------
'  Funciones publicas (UDF)
' ------------------------------------------------------------
Public Function SRNormal(Media As Double, DesvEst As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If DesvEst < 0 Then SRNormal = CVErr(xlErrNum): Exit Function
    p(1) = Media: p(2) = DesvEst
    SRNormal = Muestra(D_NORMAL, p, Nombre)
End Function

Public Function SRTriangular(Minimo As Double, MasProbable As Double, Maximo As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Minimo > MasProbable Or MasProbable > Maximo Or Minimo >= Maximo Then SRTriangular = CVErr(xlErrNum): Exit Function
    p(1) = Minimo: p(2) = MasProbable: p(3) = Maximo
    SRTriangular = Muestra(D_TRIANG, p, Nombre)
End Function

Public Function SRPert(Minimo As Double, MasProbable As Double, Maximo As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Minimo > MasProbable Or MasProbable > Maximo Or Minimo >= Maximo Then SRPert = CVErr(xlErrNum): Exit Function
    p(1) = Minimo: p(2) = MasProbable: p(3) = Maximo
    SRPert = Muestra(D_PERT, p, Nombre)
End Function

Public Function SRUniforme(Minimo As Double, Maximo As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Minimo > Maximo Then SRUniforme = CVErr(xlErrNum): Exit Function
    p(1) = Minimo: p(2) = Maximo
    SRUniforme = Muestra(D_UNIF, p, Nombre)
End Function

Public Function SRLognormal(Media As Double, DesvEst As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Media <= 0 Or DesvEst <= 0 Then SRLognormal = CVErr(xlErrNum): Exit Function
    p(1) = Media: p(2) = DesvEst
    SRLognormal = Muestra(D_LOGN, p, Nombre)
End Function

Public Function SRWeibull(Forma As Double, Escala As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Forma <= 0 Or Escala <= 0 Then SRWeibull = CVErr(xlErrNum): Exit Function
    p(1) = Forma: p(2) = Escala
    SRWeibull = Muestra(D_WEIB, p, Nombre)
End Function

Public Function SRExponencial(Media As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Media <= 0 Then SRExponencial = CVErr(xlErrNum): Exit Function
    p(1) = Media
    SRExponencial = Muestra(D_EXPO, p, Nombre)
End Function

Public Function SRGamma(Forma As Double, Escala As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Forma <= 0 Or Escala <= 0 Then SRGamma = CVErr(xlErrNum): Exit Function
    p(1) = Forma: p(2) = Escala
    SRGamma = Muestra(D_GAMMA, p, Nombre)
End Function

Public Function SRBeta(Alfa1 As Double, Alfa2 As Double, Optional Minimo As Double = 0, Optional Maximo As Double = 1, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Alfa1 <= 0 Or Alfa2 <= 0 Or Minimo >= Maximo Then SRBeta = CVErr(xlErrNum): Exit Function
    p(1) = Alfa1: p(2) = Alfa2: p(3) = Minimo: p(4) = Maximo
    SRBeta = Muestra(D_BETA, p, Nombre)
End Function

Public Function SRPoisson(Lambda As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Lambda < 0 Then SRPoisson = CVErr(xlErrNum): Exit Function
    p(1) = Lambda
    SRPoisson = Muestra(D_POIS, p, Nombre)
End Function

Public Function SRBinomial(Ensayos As Double, Probabilidad As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Ensayos < 0 Or Probabilidad < 0 Or Probabilidad > 1 Then SRBinomial = CVErr(xlErrNum): Exit Function
    p(1) = Int(Ensayos): p(2) = Probabilidad
    SRBinomial = Muestra(D_BINOM, p, Nombre)
End Function

Public Function SRBernoulli(Probabilidad As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Probabilidad < 0 Or Probabilidad > 1 Then SRBernoulli = CVErr(xlErrNum): Exit Function
    p(1) = Probabilidad
    SRBernoulli = Muestra(D_BERN, p, Nombre)
End Function

Public Function SRDiscreta(Valores As Variant, Probabilidades As Variant, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double, vv() As Double, pp() As Double, nv As Long, np As Long, i As Long, tot As Double
    Application.Volatile True
    nv = Aplanar(Valores, vv)
    np = Aplanar(Probabilidades, pp)
    If nv = 0 Or nv <> np Then SRDiscreta = CVErr(xlErrValue): Exit Function
    For i = 1 To np
        If pp(i) < 0 Then SRDiscreta = CVErr(xlErrNum): Exit Function
        tot = tot + pp(i)
    Next i
    If tot <= 0 Then SRDiscreta = CVErr(xlErrNum): Exit Function
    dN = nv
    ReDim dV(1 To nv)
    ReDim dC(1 To nv)
    For i = 1 To nv
        dV(i) = vv(i)
        If i = 1 Then dC(i) = pp(i) / tot Else dC(i) = dC(i - 1) + pp(i) / tot
    Next i
    dC(nv) = 1#
    SRDiscreta = Muestra(D_DISC, p, Nombre)
End Function

Public Function SRLogLogistica(Escala As Double, Forma As Double, Optional Ubicacion As Double = 0, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Escala <= 0 Or Forma <= 0 Then SRLogLogistica = CVErr(xlErrNum): Exit Function
    p(1) = Escala: p(2) = Forma: p(3) = Ubicacion
    SRLogLogistica = Muestra(D_LOGLOG, p, Nombre)
End Function

Public Function SRPearson5(Alfa As Double, Beta As Double, Optional Ubicacion As Double = 0, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If Alfa <= 0 Or Beta <= 0 Then SRPearson5 = CVErr(xlErrNum): Exit Function
    p(1) = Alfa: p(2) = Beta: p(3) = Ubicacion
    SRPearson5 = Muestra(D_PEARSON5, p, Nombre)
End Function

Public Function SRNormalTrunc(Media As Double, DesvEst As Double, Minimo As Double, Maximo As Double, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double
    Application.Volatile True
    If DesvEst <= 0 Or Minimo >= Maximo Then SRNormalTrunc = CVErr(xlErrNum): Exit Function
    p(1) = Media: p(2) = DesvEst: p(3) = Minimo: p(4) = Maximo
    If NormSDist((Maximo - Media) / DesvEst) - NormSDist((Minimo - Media) / DesvEst) <= 0 Then SRNormalTrunc = CVErr(xlErrNum): Exit Function
    SRNormalTrunc = Muestra(D_NTRUNC, p, Nombre)
End Function

' Distribucion empirica continua: interpola linealmente la FDA empirica de los datos
Public Function SREmpirica(Datos As Variant, Optional Nombre As Variant) As Variant
    Dim p(1 To 4) As Double, c As Range, key As String
    Application.Volatile True
    If CallerCell(c) Then key = CellKey(c) Else key = "?"
    If Not CargarEmpirica(key, Datos) Then SREmpirica = CVErr(xlErrValue): Exit Function
    SREmpirica = Muestra(D_EMPIR, p, Nombre)
End Function

Private Function CargarEmpirica(ByVal key As String, ByVal Datos As Variant) As Boolean
    Dim v() As Double, n As Long, i As Long, s As Double, sig As String, guardado As Variant
    n = Aplanar(Datos, v)
    If n < 2 Then Exit Function
    For i = 1 To n
        s = s + v(i) * (1 + (i Mod 7))
    Next i
    sig = key & "|" & n & "|" & NumJ(s)
    If gEmpCache Is Nothing Then Set gEmpCache = CreateObject("Scripting.Dictionary")
    If gEmpCache.Exists(sig) Then
        guardado = gEmpCache(sig)
        eN = UBound(guardado)
        ReDim eV(1 To eN)
        For i = 1 To eN
            eV(i) = guardado(i)
        Next i
    Else
        ReDim Preserve v(1 To n)
        OrdenarD v, 1, n
        eN = n
        eV = v
        If gEmpCache.Count > 200 Then gEmpCache.RemoveAll
        gEmpCache.Add sig, v
    End If
    CargarEmpirica = True
End Function

' Valores de un argumento (rango, matriz o escalar) como vector numerico
Private Function Aplanar(ByVal v As Variant, ByRef arr() As Double) As Long
    Dim n As Long, x As Variant, c As Range, rg As Object
    ReDim arr(1 To 1)
    If TypeName(v) = "Range" Then
        Set rg = v
        ReDim arr(1 To rg.Cells.Count)
        For Each c In rg.Cells
            If VarType(c.Value2) = vbDouble Then
                n = n + 1
                arr(n) = c.Value2
            End If
        Next c
    ElseIf IsArray(v) Then
        For Each x In v
            n = n + 1
            ReDim Preserve arr(1 To n)
            If IsNumeric(x) Then arr(n) = CDbl(x) Else n = n - 1
        Next x
    ElseIf IsNumeric(v) Then
        n = 1
        arr(1) = CDbl(v)
    End If
    Aplanar = n
End Function

' ------------------------------------------------------------
'  Nucleo comun: segun el modo devuelve valor estatico, registra o muestrea
' ------------------------------------------------------------
Private Function Muestra(ByVal t As Long, ByRef p() As Double, ByVal Nombre As Variant) As Variant
    Dim c As Range, key As String, ord As Long, u As Double, idx As Long, x As Double
    On Error GoTo falla
    Select Case gMode
        Case 1
            If CallerCell(c) Then
                key = CellKey(c)
                ord = NextOrdinal(key, c)
                RegisterInput key & "#" & ord, c, ord, Descripcion(t, p), Nombre
            End If
            Muestra = ValorEsperado(t, p)
        Case 2
            idx = 0
            If CallerCell(c) Then
                key = CellKey(c)
                ord = NextOrdinal(key, c)
                key = key & "#" & ord
                If Not gInIdx Is Nothing Then
                    If gInIdx.Exists(key) Then idx = gInIdx(key)
                End If
            End If
            If idx > 0 Then
                u = gU(idx, gIter)
            Else
                u = RngNext()
            End If
            x = InvCdf(t, u, p)
            If idx > 0 Then gInVals(gSim, idx, gIter) = x
            Muestra = x
        Case Else
            If gRandomMode Then
                Muestra = InvCdf(t, RngNext(), p)
            Else
                Muestra = ValorEsperado(t, p)
            End If
    End Select
    Exit Function
falla:
    Muestra = CVErr(xlErrNum)
End Function

' ------------------------------------------------------------
'  Inversa de la funcion de distribucion acumulada
' ------------------------------------------------------------
Public Function InvCdf(ByVal t As Long, ByVal u As Double, ByRef p() As Double) As Double
    Dim a As Double, b As Double, c As Double, fc As Double
    Dim s2 As Double, mu As Double, k As Double, pk As Double, cum As Double, i As Long
    If u < 0.000000000001 Then u = 0.000000000001
    If u > 0.999999999999 Then u = 0.999999999999
    Select Case t
        Case D_NORMAL
            InvCdf = p(1) + p(2) * NormSInv(u)
        Case D_TRIANG
            a = p(1): c = p(2): b = p(3)
            fc = (c - a) / (b - a)
            If u < fc Then
                InvCdf = a + Sqr(u * (b - a) * (c - a))
            Else
                InvCdf = b - Sqr((1 - u) * (b - a) * (b - c))
            End If
        Case D_PERT
            a = p(1): c = p(2): b = p(3)
            InvCdf = a + (b - a) * BetaInvX(u, 1 + 4 * (c - a) / (b - a), 1 + 4 * (b - c) / (b - a))
        Case D_UNIF
            InvCdf = p(1) + (p(2) - p(1)) * u
        Case D_LOGN
            s2 = Log(1 + (p(2) / p(1)) ^ 2)
            mu = Log(p(1)) - s2 / 2
            InvCdf = Exp(mu + Sqr(s2) * NormSInv(u))
        Case D_WEIB
            InvCdf = p(2) * (-Log(1 - u)) ^ (1 / p(1))
        Case D_EXPO
            InvCdf = -p(1) * Log(1 - u)
        Case D_GAMMA
            InvCdf = GammaInvX(u, p(1), p(2))
        Case D_BETA
            InvCdf = p(3) + (p(4) - p(3)) * BetaInvX(u, p(1), p(2))
        Case D_POIS
            If p(1) <= 0 Then
                InvCdf = 0
            ElseIf p(1) > 400 Then
                k = Int(p(1) + Sqr(p(1)) * NormSInv(u) + 0.5)
                If k < 0 Then k = 0
                InvCdf = k
            Else
                k = 0
                pk = Exp(-p(1))
                cum = pk
                Do While cum < u And k < 100000
                    k = k + 1
                    pk = pk * p(1) / k
                    cum = cum + pk
                Loop
                InvCdf = k
            End If
        Case D_BINOM
            If p(2) <= 0 Then
                InvCdf = 0
            ElseIf p(2) >= 1 Then
                InvCdf = p(1)
            Else
                InvCdf = BinomInvX(p(1), p(2), u)
            End If
        Case D_BERN
            If u > 1 - p(1) Then InvCdf = 1 Else InvCdf = 0
        Case D_DISC
            For i = 1 To dN
                If u <= dC(i) Then
                    InvCdf = dV(i)
                    Exit Function
                End If
            Next i
            InvCdf = dV(dN)
        Case D_LOGLOG
            InvCdf = p(3) + p(1) * (u / (1 - u)) ^ (1 / p(2))
        Case D_PEARSON5
            InvCdf = p(3) + p(2) / GammaInvX(1 - u, p(1), 1)
        Case D_NTRUNC
            a = NormSDist((p(3) - p(1)) / p(2))
            b = NormSDist((p(4) - p(1)) / p(2))
            c = a + u * (b - a)
            If c < 0.000000000001 Then c = 0.000000000001
            If c > 0.999999999999 Then c = 0.999999999999
            fc = p(1) + p(2) * NormSInv(c)
            If fc < p(3) Then fc = p(3)
            If fc > p(4) Then fc = p(4)
            InvCdf = fc
        Case D_EMPIR
            fc = u * (eN - 1) + 1
            i = Int(fc)
            If i >= eN Then
                InvCdf = eV(eN)
            Else
                InvCdf = eV(i) + (fc - i) * (eV(i + 1) - eV(i))
            End If
    End Select
End Function

' ------------------------------------------------------------
'  Inversas de Excel (con alternativa de compatibilidad)
' ------------------------------------------------------------
Private Function BetaInvX(ByVal u As Double, ByVal a As Double, ByVal b As Double) As Double
    On Error GoTo alt
    BetaInvX = WorksheetFunction.Beta_Inv(u, a, b)
    Exit Function
alt:
    BetaInvX = WorksheetFunction.BetaInv(u, a, b)
End Function

Private Function GammaInvX(ByVal u As Double, ByVal a As Double, ByVal b As Double) As Double
    On Error GoTo alt
    GammaInvX = WorksheetFunction.Gamma_Inv(u, a, b)
    Exit Function
alt:
    GammaInvX = WorksheetFunction.GammaInv(u, a, b)
End Function

Private Function BinomInvX(ByVal n As Double, ByVal p As Double, ByVal u As Double) As Double
    On Error GoTo alt
    BinomInvX = WorksheetFunction.Binom_Inv(n, p, u)
    Exit Function
alt:
    BinomInvX = WorksheetFunction.CritBinom(n, p, u)
End Function

' ------------------------------------------------------------
'  Valor esperado (valor estatico que se muestra fuera de la simulacion)
' ------------------------------------------------------------
Public Function ValorEsperado(ByVal t As Long, ByRef p() As Double) As Double
    Dim i As Long, m As Double
    Select Case t
        Case D_NORMAL, D_LOGN, D_EXPO, D_POIS
            ValorEsperado = p(1)
        Case D_TRIANG
            ValorEsperado = (p(1) + p(2) + p(3)) / 3
        Case D_PERT
            ValorEsperado = (p(1) + 4 * p(2) + p(3)) / 6
        Case D_UNIF
            ValorEsperado = (p(1) + p(2)) / 2
        Case D_WEIB
            ValorEsperado = p(2) * Exp(WorksheetFunction.GammaLn(1 + 1 / p(1)))
        Case D_GAMMA
            ValorEsperado = p(1) * p(2)
        Case D_BETA
            ValorEsperado = p(3) + (p(4) - p(3)) * p(1) / (p(1) + p(2))
        Case D_BINOM
            ValorEsperado = p(1) * p(2)
        Case D_BERN
            ValorEsperado = p(1)
        Case D_DISC
            For i = 1 To dN
                If i = 1 Then
                    m = m + dV(i) * dC(i)
                Else
                    m = m + dV(i) * (dC(i) - dC(i - 1))
                End If
            Next i
            ValorEsperado = m
        Case D_LOGLOG
            If p(2) > 1 Then
                ValorEsperado = p(3) + p(1) * (PI_ / p(2)) / Sin(PI_ / p(2))
            Else
                ValorEsperado = p(3) + p(1)
            End If
        Case D_PEARSON5
            If p(1) > 1 Then
                ValorEsperado = p(3) + p(2) / (p(1) - 1)
            Else
                ValorEsperado = p(3) + p(2) / GammaInvX(0.5, p(1), 1)
            End If
        Case D_NTRUNC
            ValorEsperado = MediaNormalTrunc(p(1), p(2), p(3), p(4))
        Case D_EMPIR
            For i = 1 To eN - 1
                m = m + (eV(i) + eV(i + 1)) / 2
            Next i
            ValorEsperado = m / (eN - 1)
    End Select
End Function


' Funcion de distribucion normal estandar
Public Function NormSDist(ByVal z As Double) As Double
    On Error GoTo alt
    NormSDist = WorksheetFunction.Norm_S_Dist(z, True)
    Exit Function
alt:
    NormSDist = WorksheetFunction.NormSDist(z)
End Function

Private Function PhiPdf(ByVal z As Double) As Double
    PhiPdf = Exp(-z * z / 2) / 2.506628274631
End Function

Private Function MediaNormalTrunc(ByVal m As Double, ByVal s As Double, ByVal a As Double, ByVal b As Double) As Double
    Dim za As Double, zb As Double, z As Double
    za = (a - m) / s: zb = (b - m) / s
    z = NormSDist(zb) - NormSDist(za)
    MediaNormalTrunc = m + s * (PhiPdf(za) - PhiPdf(zb)) / z
End Function

' ------------------------------------------------------------
'  Texto descriptivo de la distribucion
' ------------------------------------------------------------
Private Function F(ByVal x As Double) As String
    F = CStr(Round(x, 6))
End Function

Public Function Descripcion(ByVal t As Long, ByRef p() As Double) As String
    Dim s As String, i As Long
    Select Case t
        Case D_NORMAL: s = "Normal(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_TRIANG: s = "Triangular(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & ")"
        Case D_PERT: s = "PERT(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & ")"
        Case D_UNIF: s = "Uniforme(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_LOGN: s = "Lognormal(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_WEIB: s = "Weibull(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_EXPO: s = "Exponencial(" & F(p(1)) & ")"
        Case D_GAMMA: s = "Gamma(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_BETA: s = "Beta(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & "; " & F(p(4)) & ")"
        Case D_POIS: s = "Poisson(" & F(p(1)) & ")"
        Case D_BINOM: s = "Binomial(" & F(p(1)) & "; " & F(p(2)) & ")"
        Case D_BERN: s = "Bernoulli(" & F(p(1)) & ")"
        Case D_DISC
            s = "Discreta({"
            For i = 1 To dN
                If i > 1 Then s = s & "; "
                s = s & F(dV(i))
                If i >= 8 And dN > 8 Then
                    s = s & "; ..."
                    Exit For
                End If
            Next i
            s = s & "})"
        Case D_LOGLOG: s = "LogLog" & ChrW$(237) & "stica(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & ")"
        Case D_PEARSON5: s = "Pearson V(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & ")"
        Case D_NTRUNC: s = "Normal truncada(" & F(p(1)) & "; " & F(p(2)) & "; " & F(p(3)) & "; " & F(p(4)) & ")"
        Case D_EMPIR: s = "Emp" & ChrW$(237) & "rica(" & eN & " datos; " & F(eV(1)) & " a " & F(eV(eN)) & ")"
    End Select
    Descripcion = s
End Function

' ------------------------------------------------------------
'  Inversa de la normal estandar (algoritmo de Acklam)
' ------------------------------------------------------------
Public Function NormSInv(ByVal p As Double) As Double
    Const a1 As Double = -39.6968302866538, a2 As Double = 220.946098424521, a3 As Double = -275.928510446969
    Const a4 As Double = 138.357751867269, a5 As Double = -30.6647980661472, a6 As Double = 2.50662827745924
    Const b1 As Double = -54.4760987982241, b2 As Double = 161.585836858041, b3 As Double = -155.698979859887
    Const b4 As Double = 66.8013118877197, b5 As Double = -13.2806815528857
    Const c1 As Double = -7.78489400243029E-03, c2 As Double = -0.322396458041136, c3 As Double = -2.40075827716184
    Const c4 As Double = -2.54973253934373, c5 As Double = 4.37466414146497, c6 As Double = 2.93816398269878
    Const d1 As Double = 7.78469570904146E-03, d2 As Double = 0.32246712907004, d3 As Double = 2.445134137143
    Const d4 As Double = 3.75440866190742
    Const plow As Double = 0.02425
    Dim q As Double, r As Double
    If p < plow Then
        q = Sqr(-2 * Log(p))
        NormSInv = (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / _
                   ((((d1 * q + d2) * q + d3) * q + d4) * q + 1)
    ElseIf p <= 1 - plow Then
        q = p - 0.5
        r = q * q
        NormSInv = (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q / _
                   (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1)
    Else
        q = Sqr(-2 * Log(1 - p))
        NormSInv = -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / _
                   ((((d1 * q + d2) * q + d3) * q + d4) * q + 1)
    End If
End Function

' ------------------------------------------------------------
'  Salidas y escenarios
' ------------------------------------------------------------
Public Function SRSalida(Valor As Variant, Optional Nombre As Variant, Optional Grupo As Variant) As Variant
    Dim c As Range, rg As Object
    If gMode = 1 Then
        If CallerCell(c) Then RegisterOutput c, Nombre, Grupo
    End If
    If TypeName(Valor) = "Range" Then
        Set rg = Valor
        SRSalida = rg.Cells(1, 1).Value
    Else
        SRSalida = Valor
    End If
End Function

Public Function SRSimTabla(ParamArray Valores() As Variant) As Variant
    Dim lista() As Variant, n As Long, i As Long, x As Variant, c As Range, k As Long, rg As Object
    Application.Volatile True
    ReDim lista(1 To 1)
    For i = LBound(Valores) To UBound(Valores)
        If TypeName(Valores(i)) = "Range" Then
            Set rg = Valores(i)
            For Each c In rg.Cells
                n = n + 1
                ReDim Preserve lista(1 To n)
                lista(n) = c.Value
            Next c
        ElseIf IsArray(Valores(i)) Then
            For Each x In Valores(i)
                n = n + 1
                ReDim Preserve lista(1 To n)
                lista(n) = x
            Next x
        Else
            n = n + 1
            ReDim Preserve lista(1 To n)
            lista(n) = Valores(i)
        End If
    Next i
    If n = 0 Then
        SRSimTabla = CVErr(xlErrValue)
        Exit Function
    End If
    If gMode = 2 Then k = gSim Else k = 1
    k = ((k - 1) Mod n) + 1
    SRSimTabla = lista(k)
End Function

' ------------------------------------------------------------
'  Densidad, varianza y funciones auxiliares (ventana Definir distribucion)
' ------------------------------------------------------------
Public Function TipoCodigo(ByVal t As String) As Long
    Select Case LCase$(Replace(Replace(Trim$(t), " ", ""), "-", ""))
        Case "normal": TipoCodigo = D_NORMAL
        Case "triangular": TipoCodigo = D_TRIANG
        Case "pert": TipoCodigo = D_PERT
        Case "uniforme": TipoCodigo = D_UNIF
        Case "lognormal": TipoCodigo = D_LOGN
        Case "weibull": TipoCodigo = D_WEIB
        Case "exponencial": TipoCodigo = D_EXPO
        Case "gamma": TipoCodigo = D_GAMMA
        Case "beta": TipoCodigo = D_BETA
        Case "poisson": TipoCodigo = D_POIS
        Case "binomial": TipoCodigo = D_BINOM
        Case "bernoulli": TipoCodigo = D_BERN
        Case "loglogistica", "loglog" & ChrW$(237) & "stica": TipoCodigo = D_LOGLOG
        Case "pearsonv", "pearson5": TipoCodigo = D_PEARSON5
        Case "normaltruncada", "normaltrunc": TipoCodigo = D_NTRUNC
        Case Else: TipoCodigo = 0
    End Select
End Function

Public Function EsDiscreta(ByVal t As Long) As Boolean
    EsDiscreta = (t = D_POIS Or t = D_BINOM Or t = D_BERN Or t = D_DISC)
End Function

Private Function LnG(ByVal x As Double) As Double
    LnG = WorksheetFunction.GammaLn(x)
End Function

Public Function Densidad(ByVal t As Long, ByVal x As Double, ByRef p() As Double) As Double
    Dim a As Double, b As Double, c As Double, y As Double, z As Double, k As Double
    Select Case t
        Case D_NORMAL
            z = (x - p(1)) / p(2): Densidad = PhiPdf(z) / p(2)
        Case D_TRIANG
            a = p(1): c = p(2): b = p(3)
            If x < a Or x > b Then
                Densidad = 0
            ElseIf x < c Then
                Densidad = 2 * (x - a) / ((b - a) * (c - a))
            ElseIf x = c Then
                Densidad = 2 / (b - a)
            Else
                Densidad = 2 * (b - x) / ((b - a) * (b - c))
            End If
        Case D_PERT
            a = p(1): c = p(2): b = p(3)
            Densidad = BetaPdf((x - a) / (b - a), 1 + 4 * (c - a) / (b - a), 1 + 4 * (b - c) / (b - a)) / (b - a)
        Case D_UNIF
            If x >= p(1) And x <= p(2) Then Densidad = 1 / (p(2) - p(1))
        Case D_LOGN
            If x > 0 Then
                y = Log(1 + (p(2) / p(1)) ^ 2)
                z = (Log(x) - (Log(p(1)) - y / 2)) / Sqr(y)
                Densidad = PhiPdf(z) / (x * Sqr(y))
            End If
        Case D_WEIB
            If x >= 0 Then
                y = x / p(2)
                If y > 0 Or p(1) >= 1 Then Densidad = (p(1) / p(2)) * y ^ (p(1) - 1) * Exp(-(y ^ p(1)))
            End If
        Case D_EXPO
            If x >= 0 Then Densidad = Exp(-x / p(1)) / p(1)
        Case D_GAMMA
            If x > 0 Then Densidad = Exp((p(1) - 1) * Log(x) - x / p(2) - LnG(p(1)) - p(1) * Log(p(2)))
        Case D_BETA
            Densidad = BetaPdf((x - p(3)) / (p(4) - p(3)), p(1), p(2)) / (p(4) - p(3))
        Case D_POIS
            k = Int(x + 0.5)
            If k >= 0 And Abs(x - k) < 0.000001 Then Densidad = Exp(k * Log(p(1)) - p(1) - LnG(k + 1))
        Case D_BINOM
            k = Int(x + 0.5)
            If k >= 0 And k <= p(1) And Abs(x - k) < 0.000001 Then
                If p(2) <= 0 Then
                    If k = 0 Then Densidad = 1
                ElseIf p(2) >= 1 Then
                    If k = p(1) Then Densidad = 1
                Else
                    Densidad = Exp(LnG(p(1) + 1) - LnG(k + 1) - LnG(p(1) - k + 1) + k * Log(p(2)) + (p(1) - k) * Log(1 - p(2)))
                End If
            End If
        Case D_BERN
            If Abs(x - 1) < 0.000001 Then Densidad = p(1)
            If Abs(x) < 0.000001 Then Densidad = 1 - p(1)
        Case D_LOGLOG
            y = (x - p(3)) / p(1)
            If y > 0 Then Densidad = (p(2) / p(1)) * y ^ (p(2) - 1) / (1 + y ^ p(2)) ^ 2
        Case D_PEARSON5
            y = x - p(3)
            If y > 0 Then Densidad = Exp(p(1) * Log(p(2)) - LnG(p(1)) - (p(1) + 1) * Log(y) - p(2) / y)
        Case D_NTRUNC
            If x >= p(3) And x <= p(4) Then
                z = NormSDist((p(4) - p(1)) / p(2)) - NormSDist((p(3) - p(1)) / p(2))
                Densidad = PhiPdf((x - p(1)) / p(2)) / (p(2) * z)
            End If
    End Select
End Function

' ------------------------------------------------------------
'  Funcion de distribucion acumulada F(x) = P(X <= x)
' ------------------------------------------------------------
Private Function BetaCdfX(ByVal y As Double, ByVal a As Double, ByVal b As Double) As Double
    If y <= 0 Then Exit Function
    If y >= 1 Then BetaCdfX = 1: Exit Function
    On Error GoTo alt
    BetaCdfX = WorksheetFunction.Beta_Dist(y, a, b, True)
    Exit Function
alt:
    BetaCdfX = WorksheetFunction.BetaDist(y, a, b)
End Function

Private Function GammaCdfX(ByVal x As Double, ByVal a As Double, ByVal b As Double) As Double
    If x <= 0 Then Exit Function
    On Error GoTo alt
    GammaCdfX = WorksheetFunction.Gamma_Dist(x, a, b, True)
    Exit Function
alt:
    GammaCdfX = WorksheetFunction.GammaDist(x, a, b, True)
End Function

Public Function Cdf(ByVal t As Long, ByVal x As Double, ByRef p() As Double) As Double
    Dim a As Double, b As Double, c As Double, y As Double, k As Long, pk As Double, cum As Double
    Select Case t
        Case D_NORMAL
            Cdf = NormSDist((x - p(1)) / p(2))
        Case D_TRIANG
            a = p(1): c = p(2): b = p(3)
            If x <= a Then
                Cdf = 0
            ElseIf x >= b Then
                Cdf = 1
            ElseIf x <= c Then
                Cdf = (x - a) ^ 2 / ((b - a) * (c - a))
            Else
                Cdf = 1 - (b - x) ^ 2 / ((b - a) * (b - c))
            End If
        Case D_PERT
            a = p(1): c = p(2): b = p(3)
            Cdf = BetaCdfX((x - a) / (b - a), 1 + 4 * (c - a) / (b - a), 1 + 4 * (b - c) / (b - a))
        Case D_UNIF
            If x <= p(1) Then
                Cdf = 0
            ElseIf x >= p(2) Then
                Cdf = 1
            Else
                Cdf = (x - p(1)) / (p(2) - p(1))
            End If
        Case D_LOGN
            If x > 0 Then
                y = Log(1 + (p(2) / p(1)) ^ 2)
                Cdf = NormSDist((Log(x) - (Log(p(1)) - y / 2)) / Sqr(y))
            End If
        Case D_WEIB
            If x > 0 Then Cdf = 1 - Exp(-((x / p(2)) ^ p(1)))
        Case D_EXPO
            If x > 0 Then Cdf = 1 - Exp(-x / p(1))
        Case D_GAMMA
            Cdf = GammaCdfX(x, p(1), p(2))
        Case D_BETA
            Cdf = BetaCdfX((x - p(3)) / (p(4) - p(3)), p(1), p(2))
        Case D_POIS, D_BINOM, D_BERN
            If x < 0 Then Exit Function
            cum = 0
            For k = 0 To Int(x + 0.000001)
                pk = Densidad(t, k, p)
                cum = cum + pk
                If cum >= 1 Then Exit For
                If k > 100000 Then Exit For
            Next k
            If cum > 1 Then cum = 1
            Cdf = cum
        Case D_LOGLOG
            y = (x - p(3)) / p(1)
            If y > 0 Then Cdf = 1 / (1 + y ^ (-p(2)))
        Case D_PEARSON5
            y = x - p(3)
            If y > 0 Then Cdf = 1 - GammaCdfX(p(2) / y, p(1), 1)
        Case D_NTRUNC
            If x <= p(3) Then
                Cdf = 0
            ElseIf x >= p(4) Then
                Cdf = 1
            Else
                a = NormSDist((p(3) - p(1)) / p(2))
                b = NormSDist((p(4) - p(1)) / p(2))
                Cdf = (NormSDist((x - p(1)) / p(2)) - a) / (b - a)
            End If
    End Select
End Function

Private Function BetaPdf(ByVal y As Double, ByVal a As Double, ByVal b As Double) As Double
    If y <= 0 Or y >= 1 Then
        If (y = 0 And a = 1) Then BetaPdf = b
        If (y = 1 And b = 1) Then BetaPdf = a
        Exit Function
    End If
    BetaPdf = Exp((a - 1) * Log(y) + (b - 1) * Log(1 - y) - (LnG(a) + LnG(b) - LnG(a + b)))
End Function

' Varianza teorica; devuelve -1 si no existe
Public Function Varianza(ByVal t As Long, ByRef p() As Double) As Double
    Dim a As Double, b As Double, c As Double, m As Double, z1 As Double, z2 As Double, zz As Double
    Select Case t
        Case D_NORMAL, D_LOGN: Varianza = p(2) ^ 2
        Case D_TRIANG
            a = p(1): c = p(2): b = p(3)
            Varianza = (a * a + b * b + c * c - a * b - a * c - b * c) / 18
        Case D_PERT
            m = (p(1) + 4 * p(2) + p(3)) / 6
            a = 1 + 4 * (p(2) - p(1)) / (p(3) - p(1)): b = 1 + 4 * (p(3) - p(2)) / (p(3) - p(1))
            Varianza = (p(3) - p(1)) ^ 2 * a * b / ((a + b) ^ 2 * (a + b + 1))
        Case D_UNIF: Varianza = (p(2) - p(1)) ^ 2 / 12
        Case D_WEIB: Varianza = p(2) ^ 2 * (Exp(LnG(1 + 2 / p(1))) - Exp(2 * LnG(1 + 1 / p(1))))
        Case D_EXPO: Varianza = p(1) ^ 2
        Case D_GAMMA: Varianza = p(1) * p(2) ^ 2
        Case D_BETA: Varianza = (p(4) - p(3)) ^ 2 * p(1) * p(2) / ((p(1) + p(2)) ^ 2 * (p(1) + p(2) + 1))
        Case D_POIS: Varianza = p(1)
        Case D_BINOM: Varianza = p(1) * p(2) * (1 - p(2))
        Case D_BERN: Varianza = p(1) * (1 - p(1))
        Case D_LOGLOG
            If p(2) > 2 Then
                c = PI_ / p(2)
                Varianza = p(1) ^ 2 * (2 * c / Sin(2 * c) - (c / Sin(c)) ^ 2)
            Else
                Varianza = -1
            End If
        Case D_PEARSON5
            If p(1) > 2 Then Varianza = p(2) ^ 2 / ((p(1) - 1) ^ 2 * (p(1) - 2)) Else Varianza = -1
        Case D_NTRUNC
            z1 = (p(3) - p(1)) / p(2): z2 = (p(4) - p(1)) / p(2)
            zz = NormSDist(z2) - NormSDist(z1)
            Varianza = p(2) ^ 2 * (1 + (z1 * PhiPdf(z1) - z2 * PhiPdf(z2)) / zz - ((PhiPdf(z1) - PhiPdf(z2)) / zz) ^ 2)
        Case Else: Varianza = -1
    End Select
End Function

Private Function NumV(ByVal v As Variant) As Double
    If IsEmpty(v) Then NumV = 0 Else NumV = CDbl(v)
End Function

' Densidad (o probabilidad puntual en discretas) de una distribucion por nombre
Public Function SRDensidad(Tipo As String, X As Double, Optional P1 As Variant, Optional P2 As Variant, Optional P3 As Variant, Optional P4 As Variant) As Variant
    Dim p() As Double, t As Long
    On Error GoTo mal
    ReDim p(1 To 4)
    If Not IsMissing(P1) Then p(1) = NumV(P1)
    If Not IsMissing(P2) Then p(2) = NumV(P2)
    If Not IsMissing(P3) Then p(3) = NumV(P3)
    If Not IsMissing(P4) Then p(4) = NumV(P4)
    t = TipoCodigo(Tipo)
    If t = 0 Then GoTo mal
    SRDensidad = Densidad(t, X, p)
    Exit Function
mal:
    SRDensidad = CVErr(xlErrNA)
End Function

' Cuantil (inversa de la FDA) de una distribucion por nombre
Public Function SRCuantil(Tipo As String, Probabilidad As Double, Optional P1 As Variant, Optional P2 As Variant, Optional P3 As Variant, Optional P4 As Variant) As Variant
    Dim p() As Double, t As Long
    On Error GoTo mal
    ReDim p(1 To 4)
    If Not IsMissing(P1) Then p(1) = NumV(P1)
    If Not IsMissing(P2) Then p(2) = NumV(P2)
    If Not IsMissing(P3) Then p(3) = NumV(P3)
    If Not IsMissing(P4) Then p(4) = NumV(P4)
    t = TipoCodigo(Tipo)
    If t = 0 Then GoTo mal
    SRCuantil = InvCdf(t, Probabilidad, p)
    Exit Function
mal:
    SRCuantil = CVErr(xlErrNA)
End Function

' Momento teorico: Cual = "media", "desv", "discreta"
Public Function SRMomento(Tipo As String, Cual As String, Optional P1 As Variant, Optional P2 As Variant, Optional P3 As Variant, Optional P4 As Variant) As Variant
    Dim p() As Double, t As Long, v As Double
    On Error GoTo mal
    ReDim p(1 To 4)
    If Not IsMissing(P1) Then p(1) = NumV(P1)
    If Not IsMissing(P2) Then p(2) = NumV(P2)
    If Not IsMissing(P3) Then p(3) = NumV(P3)
    If Not IsMissing(P4) Then p(4) = NumV(P4)
    t = TipoCodigo(Tipo)
    If t = 0 Then GoTo mal
    Select Case LCase$(Cual)
        Case "media": SRMomento = ValorEsperado(t, p)
        Case "desv"
            v = Varianza(t, p)
            If v < 0 Then SRMomento = CVErr(xlErrNA) Else SRMomento = Sqr(v)
        Case "discreta": SRMomento = EsDiscreta(t)
        Case Else: GoTo mal
    End Select
    Exit Function
mal:
    SRMomento = CVErr(xlErrNA)
End Function
