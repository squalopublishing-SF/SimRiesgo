Attribute VB_Name = "modSRStats"
Option Explicit

' ============================================================
'  SimRiesgo - Estadisticos de resultados y utilidades numericas
' ============================================================

' Localiza la serie (salida o entrada) asociada a una celda y copia sus valores
Private Function SerieDeCelda(ByVal celda As Range, ByVal sim As Long, ByRef arr() As Double) As Long
    Dim key As String, idx As Long
    SerieDeCelda = -1
    If gMode <> 0 Then Exit Function
    If Not AsegurarResultados(celda.Worksheet.Parent) Then Exit Function
    If sim < 1 Or sim > gSimsDone Then Exit Function
    key = CellKey(celda.Cells(1, 1))
    If Not rOutIdx Is Nothing Then
        If rOutIdx.Exists(key) Then
            idx = rOutIdx(key)
            SerieDeCelda = DatosSerie(True, sim, idx, arr)
            Exit Function
        End If
    End If
    If Not rInIdx Is Nothing Then
        If rInIdx.Exists(key & "#1") Then
            idx = rInIdx(key & "#1")
            SerieDeCelda = DatosSerie(False, sim, idx, arr)
        End If
    End If
End Function

Public Function SRMedia(Celda As Range, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, s As Double
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRMedia = CVErr(xlErrNA): Exit Function
    For i = 1 To n
        s = s + a(i)
    Next i
    SRMedia = s / n
End Function

Public Function SRDesvEst(Celda As Range, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, s As Double, m As Double, q As Double
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 1 Then SRDesvEst = CVErr(xlErrNA): Exit Function
    For i = 1 To n
        s = s + a(i)
    Next i
    m = s / n
    For i = 1 To n
        q = q + (a(i) - m) ^ 2
    Next i
    SRDesvEst = Sqr(q / (n - 1))
End Function

Public Function SRMinimo(Celda As Range, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, m As Double
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRMinimo = CVErr(xlErrNA): Exit Function
    m = a(1)
    For i = 2 To n
        If a(i) < m Then m = a(i)
    Next i
    SRMinimo = m
End Function

Public Function SRMaximo(Celda As Range, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, m As Double
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRMaximo = CVErr(xlErrNA): Exit Function
    m = a(1)
    For i = 2 To n
        If a(i) > m Then m = a(i)
    Next i
    SRMaximo = m
End Function

Public Function SRPercentil(Celda As Range, Probabilidad As Double, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long
    If Probabilidad < 0 Or Probabilidad > 1 Then SRPercentil = CVErr(xlErrNum): Exit Function
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRPercentil = CVErr(xlErrNA): Exit Function
    OrdenarD a, 1, n
    SRPercentil = PercentilOrdenado(a, n, Probabilidad)
End Function

Public Function SRMediana(Celda As Range, Optional Simulacion As Long = 1) As Variant
    SRMediana = SRPercentil(Celda, 0.5, Simulacion)
End Function

' Probabilidad de que la variable sea menor o igual que Valor
Public Function SRObjetivo(Celda As Range, Valor As Double, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, k As Long
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRObjetivo = CVErr(xlErrNA): Exit Function
    For i = 1 To n
        If a(i) <= Valor Then k = k + 1
    Next i
    SRObjetivo = k / n
End Function

' Probabilidad de que la variable este entre Desde y Hasta (incluidos)
Public Function SRProbEntre(Celda As Range, Desde As Double, Hasta As Double, Optional Simulacion As Long = 1) As Variant
    Dim a() As Double, n As Long, i As Long, k As Long
    n = SerieDeCelda(Celda, Simulacion, a)
    If n <= 0 Then SRProbEntre = CVErr(xlErrNA): Exit Function
    For i = 1 To n
        If a(i) >= Desde And a(i) <= Hasta Then k = k + 1
    Next i
    SRProbEntre = k / n
End Function

' ============================================================
'  Utilidades numericas
' ============================================================
Public Function PercentilOrdenado(ByRef a() As Double, ByVal n As Long, ByVal p As Double) As Double
    Dim k As Long
    k = -Int(-p * n)
    If k < 1 Then k = 1
    If k > n Then k = n
    PercentilOrdenado = a(k)
End Function

' Ordenamiento rapido (no recursivo profundo: recursion en la particion menor)
Public Sub OrdenarD(ByRef a() As Double, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, piv As Double, t As Double
    Do While lo < hi
        i = lo: j = hi
        piv = a((lo + hi) \ 2)
        Do While i <= j
            Do While a(i) < piv
                i = i + 1
            Loop
            Do While a(j) > piv
                j = j - 1
            Loop
            If i <= j Then
                t = a(i): a(i) = a(j): a(j) = t
                i = i + 1: j = j - 1
            End If
        Loop
        If (j - lo) < (hi - i) Then
            If lo < j Then OrdenarD a, lo, j
            lo = i
        Else
            If i < hi Then OrdenarD a, i, hi
            hi = j
        End If
    Loop
End Sub

' Ordena claves llevando un vector de indices
Public Sub OrdenarIdx(ByRef k() As Double, ByRef ix() As Long, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, piv As Double, t As Double, ti As Long
    Do While lo < hi
        i = lo: j = hi
        piv = k((lo + hi) \ 2)
        Do While i <= j
            Do While k(i) < piv
                i = i + 1
            Loop
            Do While k(j) > piv
                j = j - 1
            Loop
            If i <= j Then
                t = k(i): k(i) = k(j): k(j) = t
                ti = ix(i): ix(i) = ix(j): ix(j) = ti
                i = i + 1: j = j - 1
            End If
        Loop
        If (j - lo) < (hi - i) Then
            If lo < j Then OrdenarIdx k, ix, lo, j
            lo = i
        Else
            If i < hi Then OrdenarIdx k, ix, i, hi
            hi = j
        End If
    Loop
End Sub

' Rangos con empates promediados
Public Sub Rangos(ByRef v() As Double, ByVal n As Long, ByRef r() As Double)
    Dim k() As Double, ix() As Long, i As Long, j As Long, m As Double, t As Long
    ReDim k(1 To n)
    ReDim ix(1 To n)
    ReDim r(1 To n)
    For i = 1 To n
        k(i) = v(i)
        ix(i) = i
    Next i
    OrdenarIdx k, ix, 1, n
    i = 1
    Do While i <= n
        j = i
        Do While j < n
            If k(j + 1) = k(i) Then j = j + 1 Else Exit Do
        Loop
        m = (i + j) / 2#
        For t = i To j
            r(ix(t)) = m
        Next t
        i = j + 1
    Loop
End Sub

Public Function Pearson(ByRef x() As Double, ByRef y() As Double, ByVal n As Long) As Double
    Dim i As Long, mx As Double, my As Double, sxy As Double, sxx As Double, syy As Double
    If n < 2 Then Exit Function
    For i = 1 To n
        mx = mx + x(i)
        my = my + y(i)
    Next i
    mx = mx / n: my = my / n
    For i = 1 To n
        sxy = sxy + (x(i) - mx) * (y(i) - my)
        sxx = sxx + (x(i) - mx) ^ 2
        syy = syy + (y(i) - my) ^ 2
    Next i
    If sxx <= 0 Or syy <= 0 Then
        Pearson = 0
    Else
        Pearson = sxy / Sqr(sxx * syy)
    End If
End Function
