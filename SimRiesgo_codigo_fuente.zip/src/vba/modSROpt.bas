Attribute VB_Name = "modSROpt"
Option Explicit

' ============================================================
'  SimRiesgo - Optimizacion bajo incertidumbre (algoritmo genetico + simulacion)
' ============================================================
'  Cada prueba fija las variables de decision, ejecuta una simulacion con la misma
'  semilla (numeros aleatorios comunes, para comparar soluciones sin ruido) y evalua
'  el estadistico objetivo y las restricciones sobre las salidas simuladas.

Public Const HOJA_OPT As String = "SR Optimizacion"
Public Const HOJA_OPTLOG As String = "SR Opt Registro"
Private Const FILA_V As Long = 12          ' primera fila de variables / restricciones
Private Const MAXV As Long = 20        ' maximo de variables
Private Const MAXR As Long = 10        ' maximo de restricciones

Private oVar() As Range, oMin() As Double, oMax() As Double, oPaso() As Double, oNV As Long
Private oObjIdx As Long, oObjStat As String, oObjPar As Double, oMax_ As Boolean
Private oRCel() As Range, oRIdx() As Long, oRStat() As String, oRPar() As Double, oROp() As String, oRLim() As Double, oNR As Long
Private oHayValor As Boolean

Public Function ListaEstadisticos() As Variant
    ListaEstadisticos = Array("Media", "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar", "Percentil", _
        "M" & ChrW$(237) & "nimo", "M" & ChrW$(225) & "ximo", "Probabilidad <= x", "Probabilidad >= x")
End Function

' ------------------------------------------------------------
'  Hoja de configuracion
' ------------------------------------------------------------
Public Sub SR_ConfigurarOptimizacion()
    Dim wb As Workbook, ws As Worksheet, obj As Range, dec As Range, c As Range, i As Long, est As Variant
    Dim shp As Object, r As Long, v As Double

    If ActiveWorkbook Is Nothing Then Exit Sub
    Set wb = ActiveWorkbook
    On Error Resume Next
    Set ws = wb.Worksheets(HOJA_OPT)
    On Error GoTo 0
    If Not ws Is Nothing Then
        ws.Activate
        Exit Sub
    End If

    On Error Resume Next
    Set obj = Application.InputBox("Seleccione la celda de SALIDA que desea optimizar (debe contener SRSalida):", _
                                   SR_APP & " - Optimizaci" & ChrW$(243) & "n", Type:=8)
    If obj Is Nothing Then Exit Sub
    Set dec = Application.InputBox("Seleccione las celdas de las VARIABLES DE DECISI" & ChrW$(211) & "N (valores constantes; " & _
                                   "puede usar Ctrl + clic):", SR_APP & " - Optimizaci" & ChrW$(243) & "n", Type:=8)
    If dec Is Nothing Then Exit Sub
    On Error GoTo falla

    Application.ScreenUpdating = False
    Set ws = wb.Worksheets.Add(After:=wb.Sheets(wb.Sheets.Count))
    ws.Name = HOJA_OPT
    ActiveWindow.DisplayGridlines = False
    ws.Cells.Font.Size = 10
    ws.Columns("A").ColumnWidth = 2
    ws.Columns("B").ColumnWidth = 28
    ws.Columns("C:F").ColumnWidth = 13
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 24
    ws.Columns("I").ColumnWidth = 20
    ws.Columns("J:L").ColumnWidth = 11

    With ws.Range("B2")
        .Value = "Optimizaci" & ChrW$(243) & "n bajo incertidumbre"
        .Font.Size = 15
        .Font.Bold = True
        .Font.Color = RGB(154, 61, 12)
    End With
    ws.Range("B3").Value = "Escriba las celdas como Hoja!Celda. Las celdas blancas son editables."
    ws.Range("B3").Font.Color = RGB(124, 123, 119)

    est = ListaEstadisticos()
    For i = 0 To UBound(est)
        ws.Cells(1 + i, 26).Value2 = est(i)
    Next i
    ws.Cells(UBound(est) + 2, 26).Value2 = "Valor (sin simular)"
    ws.Range("AA1").Value2 = "Maximizar"
    ws.Range("AA2").Value2 = "Minimizar"
    ws.Range("AB1").Value2 = "<="
    ws.Range("AB2").Value2 = ">="
    ws.Columns("Z:AB").Hidden = True

    Seccion ws, "B4", "Objetivo"
    ws.Range("B5").Value = "Celda de salida"
    ws.Range("C5").Value2 = "'" & RefTexto(obj.Cells(1, 1))
    ws.Range("B6").Value = "Estad" & ChrW$(237) & "stico"
    ws.Range("C6").Value2 = est(0)
    Lista ws.Range("C6"), "=$Z$1:$Z$" & (UBound(est) + 1)
    ws.Range("B7").Value = "Par" & ChrW$(225) & "metro (p del percentil o x)"
    ws.Range("C7").Value2 = 0.05
    ws.Range("B8").Value = "Sentido"
    ws.Range("C8").Value2 = "Maximizar"
    Lista ws.Range("C8"), "=$AA$1:$AA$2"
    Editable ws.Range("C5:C8")
    ws.Range("C5").HorizontalAlignment = xlLeft

    Seccion ws, "B10", "Variables de decisi" & ChrW$(243) & "n"
    ws.Range("B11:E11").Value = Array("Celda", "M" & ChrW$(237) & "nimo", "M" & ChrW$(225) & "ximo", "Paso (0 = continuo)")
    ws.Range("B11:E11").Font.Bold = True
    r = FILA_V
    For Each c In dec.Cells
        If r >= FILA_V + MAXV Then Exit For
        v = 0
        If VarType(c.Value2) = vbDouble Then v = c.Value2
        ws.Cells(r, 2).Value2 = "'" & RefTexto(c)
        If v = 0 Then
            ws.Cells(r, 3).Value2 = 0
            ws.Cells(r, 4).Value2 = 100
        Else
            ws.Cells(r, 3).Value2 = Sig6(v - Abs(v) * 0.5)
            ws.Cells(r, 4).Value2 = Sig6(v + Abs(v) * 0.5)
        End If
        ws.Cells(r, 5).Value2 = IIf(v = Int(v), 1, 0)
        r = r + 1
    Next c
    Editable ws.Range(ws.Cells(FILA_V, 2), ws.Cells(FILA_V + MAXV - 1, 5))

    Seccion ws, "H10", "Restricciones (opcional)"
    ws.Range("H11:L11").Value = Array("Celda", "Estad" & ChrW$(237) & "stico", "Par" & ChrW$(225) & "metro", "Operador", "L" & ChrW$(237) & "mite")
    ws.Range("H11:L11").Font.Bold = True
    Editable ws.Range(ws.Cells(FILA_V, 8), ws.Cells(FILA_V + MAXR - 1, 12))
    Lista ws.Range(ws.Cells(FILA_V, 9), ws.Cells(FILA_V + MAXR - 1, 9)), "=$Z$1:$Z$" & (UBound(est) + 2)
    Lista ws.Range(ws.Cells(FILA_V, 11), ws.Cells(FILA_V + MAXR - 1, 11)), "=$AB$1:$AB$2"
    ws.Range("H23").Value = "Ejemplo: Hoja1!F20 | Probabilidad <= x | 0 | <= | 0,05  (riesgo de p" & ChrW$(233) & "rdida " & ChrW$(8804) & " 5 %)"
    ws.Range("H23").Font.Color = RGB(124, 123, 119)
    ws.Range("H23").Font.Italic = True

    Seccion ws, "B34", "Configuraci" & ChrW$(243) & "n"
    ws.Range("B35").Value = "Iteraciones por prueba": ws.Range("C35").Value2 = 300
    ws.Range("B36").Value = "Pruebas m" & ChrW$(225) & "ximas": ws.Range("C36").Value2 = 300
    ws.Range("B37").Value = "Tama" & ChrW$(241) & "o de poblaci" & ChrW$(243) & "n": ws.Range("C37").Value2 = 20
    ws.Range("B38").Value = "Detener si no mejora en (pruebas)": ws.Range("C38").Value2 = 100
    ws.Range("B39").Value = "Semilla (n" & ChrW$(250) & "meros comunes)": ws.Range("C39").Value2 = 12345
    Editable ws.Range("C35:C39")

    Set shp = ws.Shapes.AddShape(5, ws.Range("B42").Left, ws.Range("B42").Top, 170, 28)
    shp.Fill.ForeColor.RGB = RGB(217, 86, 26)
    shp.Line.Visible = msoFalse
    With shp.TextFrame2
        .TextRange.Text = "Ejecutar optimizaci" & ChrW$(243) & "n"
        .TextRange.Font.Size = 10
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
    End With
    shp.OnAction = "'" & ThisWorkbook.Name & "'!SR_Optimizar"
    ws.Range("D42").Value = "Esc detiene la b" & ChrW$(250) & "squeda y conserva la mejor soluci" & ChrW$(243) & "n encontrada."
    ws.Range("D42").Font.Color = RGB(124, 123, 119)
    Application.ScreenUpdating = True
    ws.Range("C6").Select
    Exit Sub
falla:
    Application.ScreenUpdating = True
    MsgBox "No se pudo crear la hoja de optimizaci" & ChrW$(243) & "n: " & Err.Description, vbExclamation, SR_APP
End Sub

Private Sub Seccion(ByVal ws As Worksheet, ByVal dirc As String, ByVal texto As String)
    With ws.Range(dirc)
        .Value = texto
        .Font.Bold = True
        .Font.Size = 11
        .Font.Color = RGB(154, 61, 12)
    End With
End Sub

Private Sub Editable(ByVal rg As Range)
    rg.Interior.Color = RGB(255, 255, 255)
    rg.Borders.LineStyle = xlContinuous
    rg.Borders.Color = RGB(217, 216, 212)
End Sub

Private Sub Lista(ByVal rg As Range, ByVal fuente As String)
    rg.Validation.Delete
    rg.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=fuente
End Sub

Private Function RefTexto(ByVal c As Range) As String
    RefTexto = "'" & Replace(c.Worksheet.Name, "'", "''") & "'!" & c.Address(False, False)
End Function

Private Function ResolverRef(ByVal wb As Workbook, ByVal txt As String) As Range
    Dim p As Long, hoja As String, dirc As String
    On Error GoTo nada
    txt = Trim$(txt)
    If Left$(txt, 1) = "=" Then txt = Mid$(txt, 2)
    p = InStrRev(txt, "!")
    If p = 0 Then GoTo nada
    hoja = Left$(txt, p - 1)
    dirc = Mid$(txt, p + 1)
    If Left$(hoja, 1) = "'" And Right$(hoja, 1) = "'" Then hoja = Replace(Mid$(hoja, 2, Len(hoja) - 2), "''", "'")
    Set ResolverRef = wb.Worksheets(hoja).Range(dirc).Cells(1, 1)
    Exit Function
nada:
    Set ResolverRef = Nothing
End Function

Private Function CodigoEstad(ByVal s As String) As String
    Dim e As Variant
    e = ListaEstadisticos()
    Select Case True
        Case s = e(0): CodigoEstad = "media"
        Case s = e(1): CodigoEstad = "desv"
        Case s = e(2): CodigoEstad = "pct"
        Case s = e(3): CodigoEstad = "min"
        Case s = e(4): CodigoEstad = "max"
        Case s = e(5): CodigoEstad = "ple"
        Case s = e(6): CodigoEstad = "pge"
        Case Left$(s, 5) = "Valor": CodigoEstad = "valor"
        Case Else: CodigoEstad = ""
    End Select
End Function

' ------------------------------------------------------------
'  Estadisticos de una salida en la simulacion actual (simulacion 1)
' ------------------------------------------------------------
Private Function EstadSalida(ByVal o As Long, ByVal st As String, ByVal par As Double) As Double
    Dim a() As Double, n As Long, i As Long, s As Double, m As Double, q As Double, c As Long
    ReDim a(1 To gItersDone)
    For i = 1 To gItersDone
        If gOutErr(1, o, i) = 0 Then
            n = n + 1
            a(n) = gOutVals(1, o, i)
        End If
    Next i
    If n = 0 Then
        EstadSalida = 0
        Exit Function
    End If
    Select Case st
        Case "media", "desv"
            For i = 1 To n
                s = s + a(i)
            Next i
            m = s / n
            If st = "media" Then
                EstadSalida = m
            Else
                For i = 1 To n
                    q = q + (a(i) - m) ^ 2
                Next i
                If n > 1 Then EstadSalida = Sqr(q / (n - 1))
            End If
        Case "pct", "min", "max"
            OrdenarD a, 1, n
            If st = "min" Then
                EstadSalida = a(1)
            ElseIf st = "max" Then
                EstadSalida = a(n)
            Else
                EstadSalida = PercentilOrdenado(a, n, par)
            End If
        Case "ple", "pge"
            For i = 1 To n
                If st = "ple" Then
                    If a(i) <= par Then c = c + 1
                Else
                    If a(i) >= par Then c = c + 1
                End If
            Next i
            EstadSalida = c / n
    End Select
End Function

' ------------------------------------------------------------
'  Lectura de la configuracion
' ------------------------------------------------------------
Private Function LeerConfig(ByVal ws As Worksheet, ByRef msg As String) As Boolean
    Dim wb As Workbook, r As Long, c As Range, k As String
    Set wb = ws.Parent
    oNV = 0
    oNR = 0
    ReDim oVar(1 To MAXV): ReDim oMin(1 To MAXV): ReDim oMax(1 To MAXV): ReDim oPaso(1 To MAXV)
    ReDim oRCel(1 To MAXR): ReDim oRIdx(1 To MAXR): ReDim oRStat(1 To MAXR): ReDim oRPar(1 To MAXR)
    ReDim oROp(1 To MAXR): ReDim oRLim(1 To MAXR)

    ' objetivo
    Set c = ResolverRef(wb, CStr(ws.Range("C5").Value2))
    If c Is Nothing Then msg = "La celda objetivo (C5) no es v" & ChrW$(225) & "lida.": Exit Function
    k = CellKey(c)
    If Not gOutIdx.Exists(k) Then msg = "La celda objetivo " & CellLabel(c) & " no es una salida (use SRSalida).": Exit Function
    oObjIdx = gOutIdx(k)
    oObjStat = CodigoEstad(CStr(ws.Range("C6").Value2))
    If oObjStat = "" Or oObjStat = "valor" Then msg = "Elija un estad" & ChrW$(237) & "stico v" & ChrW$(225) & "lido para el objetivo.": Exit Function
    oObjPar = Val(Replace(CStr(ws.Range("C7").Value2), ",", "."))
    If VarType(ws.Range("C7").Value2) = vbDouble Then oObjPar = ws.Range("C7").Value2
    oMax_ = (CStr(ws.Range("C8").Value2) <> "Minimizar")

    ' variables
    For r = FILA_V To FILA_V + MAXV - 1
        If Len(Trim$(CStr(ws.Cells(r, 2).Value2))) > 0 Then
            Set c = ResolverRef(wb, CStr(ws.Cells(r, 2).Value2))
            If c Is Nothing Then msg = "La variable de la fila " & r & " no es una celda v" & ChrW$(225) & "lida.": Exit Function
            If c.HasFormula Then msg = "La variable " & CellLabel(c) & " contiene una f" & ChrW$(243) & "rmula; debe ser un valor constante.": Exit Function
            If VarType(ws.Cells(r, 3).Value2) <> vbDouble Or VarType(ws.Cells(r, 4).Value2) <> vbDouble Then
                msg = "Indique m" & ChrW$(237) & "nimo y m" & ChrW$(225) & "ximo num" & ChrW$(233) & "ricos en la fila " & r & ".": Exit Function
            End If
            oNV = oNV + 1
            Set oVar(oNV) = c
            oMin(oNV) = ws.Cells(r, 3).Value2
            oMax(oNV) = ws.Cells(r, 4).Value2
            If VarType(ws.Cells(r, 5).Value2) = vbDouble Then oPaso(oNV) = Abs(ws.Cells(r, 5).Value2) Else oPaso(oNV) = 0
            If oMax(oNV) <= oMin(oNV) Then msg = "En la fila " & r & " el m" & ChrW$(225) & "ximo debe ser mayor que el m" & ChrW$(237) & "nimo.": Exit Function
        End If
    Next r
    If oNV = 0 Then msg = "No hay variables de decisi" & ChrW$(243) & "n.": Exit Function

    ' restricciones
    oHayValor = False
    For r = FILA_V To FILA_V + MAXR - 1
        If Len(Trim$(CStr(ws.Cells(r, 8).Value2))) > 0 Then
            Set c = ResolverRef(wb, CStr(ws.Cells(r, 8).Value2))
            If c Is Nothing Then msg = "La restricci" & ChrW$(243) & "n de la fila " & r & " no tiene una celda v" & ChrW$(225) & "lida.": Exit Function
            oNR = oNR + 1
            Set oRCel(oNR) = c
            oRStat(oNR) = CodigoEstad(CStr(ws.Cells(r, 9).Value2))
            If oRStat(oNR) = "" Then msg = "Elija el estad" & ChrW$(237) & "stico de la restricci" & ChrW$(243) & "n de la fila " & r & ".": Exit Function
            If oRStat(oNR) = "valor" Then
                oHayValor = True
            Else
                k = CellKey(c)
                If Not gOutIdx.Exists(k) Then msg = "La celda " & CellLabel(c) & " de la restricci" & ChrW$(243) & "n no es una salida (use SRSalida o el estad" & ChrW$(237) & "stico 'Valor').": Exit Function
                oRIdx(oNR) = gOutIdx(k)
            End If
            If VarType(ws.Cells(r, 10).Value2) = vbDouble Then oRPar(oNR) = ws.Cells(r, 10).Value2
            oROp(oNR) = CStr(ws.Cells(r, 11).Value2)
            If oROp(oNR) <> ">=" Then oROp(oNR) = "<="
            If VarType(ws.Cells(r, 12).Value2) <> vbDouble Then msg = "Indique un l" & ChrW$(237) & "mite num" & ChrW$(233) & "rico en la fila " & r & ".": Exit Function
            oRLim(oNR) = ws.Cells(r, 12).Value2
        End If
    Next r
    LeerConfig = True
End Function

' ------------------------------------------------------------
'  Evaluacion de una solucion
' ------------------------------------------------------------
Private Function Ajustar(ByVal j As Long, ByVal v As Double) As Double
    If oPaso(j) > 0 Then v = oMin(j) + Round((v - oMin(j)) / oPaso(j)) * oPaso(j)
    If v < oMin(j) Then v = oMin(j)
    If v > oMax(j) Then v = oMax(j)
    Ajustar = Sig6(v)
End Function

Private Function ClaveSol(ByRef x() As Double) As String
    Dim j As Long, s As String
    For j = 1 To oNV
        s = s & "|" & CStr(x(j))
    Next j
    ClaveSol = s
End Function

' Devuelve 0 si la evaluacion fue correcta, 1 si se cancelo, 2 si hubo error
Private Function Evaluar(ByRef x() As Double, ByVal nIt As Long, ByVal seed As Double, _
                         ByRef obj As Double, ByRef viol As Double, ByRef msg As String) As Long
    Dim j As Long, r As Long, v As Double, res As Long, e As Double
    For j = 1 To oNV
        oVar(j).Value2 = x(j)
    Next j
    res = CorrerSimulacion(nIt, 1, True, seed, False, 0, True, msg)
    If res <> 0 Then
        Evaluar = res
        Exit Function
    End If
    obj = EstadSalida(oObjIdx, oObjStat, oObjPar)
    viol = 0
    If oHayValor Then
        gPass = gPass + 1
        Application.Calculate
    End If
    For r = 1 To oNR
        If oRStat(r) = "valor" Then
            If VarType(oRCel(r).Value2) = vbDouble Then v = oRCel(r).Value2 Else v = 1E+30
        Else
            v = EstadSalida(oRIdx(r), oRStat(r), oRPar(r))
        End If
        If oROp(r) = "<=" Then e = v - oRLim(r) Else e = oRLim(r) - v
        If e > 0 Then viol = viol + e / (Abs(oRLim(r)) + 1E-09)
    Next r
    Evaluar = 0
End Function

' a es mejor que b?
Private Function Mejor(ByVal oa As Double, ByVal va As Double, ByVal ob As Double, ByVal vb As Double) As Boolean
    If va <= 0 And vb > 0 Then Mejor = True: Exit Function
    If va > 0 And vb <= 0 Then Mejor = False: Exit Function
    If va > 0 And vb > 0 Then Mejor = (va < vb): Exit Function
    If oMax_ Then Mejor = (oa > ob) Else Mejor = (oa < ob)
End Function

' ------------------------------------------------------------
'  Optimizacion
' ------------------------------------------------------------
Public Sub SR_Optimizar()
    Dim wb As Workbook, ws As Worksheet, msg As String, calcMode As Long, aleat As Boolean
    Dim nIt As Long, maxP As Long, pob As Long, paciencia As Long, seed As Double
    Dim X() As Double, fo() As Double, fv() As Double, orig() As Double, i As Long, j As Long, k As Long
    Dim hijo() As Double, oh As Double, vh As Double, res As Long, pruebas As Long, sinMejora As Long
    Dim bestX() As Double, bestO As Double, bestV As Double, peor As Long, a As Long, b As Long
    Dim cache As Object, clave As String, logV() As Variant, nLog As Long, u As Double, alfa As Double
    Dim t0 As Double, txt As String, rgn As Double, cancelado As Boolean, origOk As Boolean

    If SimulacionEnCurso() Then Exit Sub
    If ActiveWorkbook Is Nothing Then Exit Sub
    Set wb = ActiveWorkbook
    On Error Resume Next
    Set ws = wb.Worksheets(HOJA_OPT)
    On Error GoTo 0
    If ws Is Nothing Then
        SR_ConfigurarOptimizacion
        Exit Sub
    End If

    calcMode = Application.Calculation
    Application.Calculation = xlCalculationManual
    aleat = gRandomMode
    gRandomMode = False
    MarcarEjecucion True
    gHasResults = False
    Application.StatusBar = SR_APP & ": preparando la optimizaci" & ChrW$(243) & "n..."
    If Not RegistrarModelo() Then
        msg = "No se pudo recalcular el modelo."
        GoTo salir
    End If
    If Not LeerConfig(ws, msg) Then GoTo salir
    gAvisos = ""
    LeerCorrelaciones wb

    nIt = LeerEntero(ws.Range("C35"), 300, 20, 100000)
    maxP = LeerEntero(ws.Range("C36"), 300, 10, 100000)
    pob = LeerEntero(ws.Range("C37"), 20, 4, 200)
    paciencia = LeerEntero(ws.Range("C38"), 100, 10, 100000)
    seed = LeerEntero(ws.Range("C39"), 12345, 1, 2000000000)

    ReDim orig(1 To oNV)
    For j = 1 To oNV
        If VarType(oVar(j).Value2) = vbDouble Then orig(j) = oVar(j).Value2 Else orig(j) = oMin(j)
    Next j
    origOk = True
    ReDim X(1 To pob, 1 To oNV)
    ReDim fo(1 To pob)
    ReDim fv(1 To pob)
    ReDim hijo(1 To oNV)
    ReDim bestX(1 To oNV)
    ReDim logV(1 To maxP + pob, 1 To 3 + oNV)
    Set cache = CreateObject("Scripting.Dictionary")
    RngSeed seed + 7
    t0 = Timer
    Application.ScreenUpdating = False
    Application.EnableCancelKey = xlErrorHandler
    On Error GoTo cancelar

    ' poblacion inicial: la solucion actual y puntos aleatorios
    For i = 1 To pob
        For j = 1 To oNV
            If i = 1 Then
                hijo(j) = Ajustar(j, orig(j))
            Else
                hijo(j) = Ajustar(j, oMin(j) + RngNext() * (oMax(j) - oMin(j)))
            End If
        Next j
        res = EvaluarCache(hijo, nIt, seed, oh, vh, msg, cache, logV, nLog)
        If res = 1 Then GoTo fin
        If res = 2 Then GoTo salir
        For j = 1 To oNV
            X(i, j) = hijo(j)
        Next j
        fo(i) = oh: fv(i) = vh
        If i = 1 Or Mejor(oh, vh, bestO, bestV) Then
            bestO = oh: bestV = vh
            For j = 1 To oNV: bestX(j) = hijo(j): Next j
        End If
        pruebas = pruebas + 1
        Progreso pruebas, maxP, bestO, bestV
    Next i

    ' generaciones (estado estacionario: un hijo reemplaza al peor si es mejor)
    alfa = 0.3
    Do While pruebas < maxP And sinMejora < paciencia
        a = Torneo(fo, fv, pob)
        b = Torneo(fo, fv, pob)
        For j = 1 To oNV
            rgn = Abs(X(a, j) - X(b, j))
            u = RngNext()
            hijo(j) = IIf(X(a, j) < X(b, j), X(a, j), X(b, j)) - alfa * rgn + u * (1 + 2 * alfa) * rgn
            If RngNext() < 1# / oNV + 0.1 Then
                hijo(j) = hijo(j) + NormSInv(0.0001 + 0.9998 * RngNext()) * 0.1 * (oMax(j) - oMin(j))
            End If
            hijo(j) = Ajustar(j, hijo(j))
        Next j
        clave = ClaveSol(hijo)
        If cache.Exists(clave) Then
            ' solucion repetida: mutacion fuerte de una coordenada
            k = Int(RngNext() * oNV) + 1
            If k > oNV Then k = oNV
            hijo(k) = Ajustar(k, oMin(k) + RngNext() * (oMax(k) - oMin(k)))
        End If
        res = EvaluarCache(hijo, nIt, seed, oh, vh, msg, cache, logV, nLog)
        If res = 1 Then GoTo fin
        If res = 2 Then GoTo salir
        pruebas = pruebas + 1
        peor = 1
        For i = 2 To pob
            If Mejor(fo(peor), fv(peor), fo(i), fv(i)) Then peor = i
        Next i
        If Mejor(oh, vh, fo(peor), fv(peor)) Then
            For j = 1 To oNV: X(peor, j) = hijo(j): Next j
            fo(peor) = oh: fv(peor) = vh
        End If
        If Mejor(oh, vh, bestO, bestV) Then
            bestO = oh: bestV = vh
            For j = 1 To oNV: bestX(j) = hijo(j): Next j
            sinMejora = 0
        Else
            sinMejora = sinMejora + 1
        End If
        Progreso pruebas, maxP, bestO, bestV
    Loop
    GoTo fin

cancelar:
    If Err.Number = 18 Then
        cancelado = True
        Resume fin
    End If
    msg = Err.Description
    Resume salir

fin:
    On Error Resume Next
    Application.EnableCancelKey = xlInterrupt
    ' restaurar valores originales
    For j = 1 To oNV
        oVar(j).Value2 = orig(j)
    Next j
    gMode = 0
    MarcarEjecucion False
    Application.ScreenUpdating = True
    Application.StatusBar = False
    Application.Calculation = calcMode
    gRandomMode = aleat
    If nLog > 0 Then EscribirRegistro wb, logV, nLog, bestX
    ws.Activate
    txt = IIf(cancelado, "B" & ChrW$(250) & "squeda detenida por el usuario." & vbCrLf & vbCrLf, "") & _
          "Pruebas evaluadas: " & nLog & "   (" & Format(Timer - t0, "0") & " s)" & vbCrLf & _
          "Mejor objetivo (" & CStr(ws.Range("C6").Value2) & "): " & Format(bestO, "#,##0.00##") & vbCrLf & _
          IIf(bestV > 0, "ATENCI" & ChrW$(211) & "N: no se encontr" & ChrW$(243) & " una soluci" & ChrW$(243) & "n que cumpla todas las restricciones." & vbCrLf, "") & vbCrLf
    For j = 1 To oNV
        If j > 10 Then
            txt = txt & "  ... (ver la hoja '" & HOJA_OPTLOG & "')" & vbCrLf
            Exit For
        End If
        txt = txt & "  " & CellLabel(oVar(j)) & " = " & Format(bestX(j), "#,##0.####") & vbCrLf
    Next j
    txt = txt & vbCrLf & ChrW$(191) & "Desea escribir estos valores en el modelo y simularlo?"
    If MsgBox(txt, vbYesNo + vbQuestion, SR_APP & " - Optimizaci" & ChrW$(243) & "n") = vbYes Then
        For j = 1 To oNV
            oVar(j).Value2 = bestX(j)
        Next j
        oVar(1).Worksheet.Activate
        SR_Simular
    Else
        Application.Calculate
    End If
    Exit Sub

salir:
    On Error Resume Next
    Application.EnableCancelKey = xlInterrupt
    If origOk Then
        For j = 1 To oNV
            oVar(j).Value2 = orig(j)
        Next j
    End If
    gMode = 0
    MarcarEjecucion False
    Application.ScreenUpdating = True
    Application.StatusBar = False
    Application.Calculation = calcMode
    gRandomMode = aleat
    If Len(msg) > 0 Then MsgBox msg, vbExclamation, SR_APP & " - Optimizaci" & ChrW$(243) & "n"
End Sub

Private Function LeerEntero(ByVal c As Range, ByVal defecto As Double, ByVal mn As Double, ByVal mx As Double) As Double
    Dim v As Double
    v = defecto
    If VarType(c.Value2) = vbDouble Then v = Int(c.Value2)
    If v < mn Then v = mn
    If v > mx Then v = mx
    LeerEntero = v
End Function

Private Function EvaluarCache(ByRef x() As Double, ByVal nIt As Long, ByVal seed As Double, ByRef obj As Double, _
                              ByRef viol As Double, ByRef msg As String, ByVal cache As Object, _
                              ByRef logV() As Variant, ByRef nLog As Long) As Long
    Dim clave As String, r As Variant, j As Long, est As Variant
    clave = ClaveSol(x)
    If cache.Exists(clave) Then
        r = cache(clave)
        obj = r(0)
        viol = r(1)
        EvaluarCache = 0
        Exit Function
    End If
    ' el generador de la busqueda no debe verse afectado por la simulacion
    est = EstadoRng()
    EvaluarCache = Evaluar(x, nIt, seed, obj, viol, msg)
    FijarRng est
    If EvaluarCache <> 0 Then Exit Function
    cache.Add clave, Array(obj, viol)
    nLog = nLog + 1
    If nLog <= UBound(logV, 1) Then
        logV(nLog, 1) = nLog
        logV(nLog, 2) = obj
        logV(nLog, 3) = IIf(viol <= 0, "S" & ChrW$(237), "No")
        For j = 1 To oNV
            logV(nLog, 3 + j) = x(j)
        Next j
    End If
End Function

Private Function Torneo(ByRef fo() As Double, ByRef fv() As Double, ByVal pob As Long) As Long
    Dim a As Long, b As Long
    a = Int(RngNext() * pob) + 1
    b = Int(RngNext() * pob) + 1
    If a > pob Then a = pob
    If b > pob Then b = pob
    If Mejor(fo(a), fv(a), fo(b), fv(b)) Then Torneo = a Else Torneo = b
End Function

Private Sub Progreso(ByVal k As Long, ByVal n As Long, ByVal o As Double, ByVal v As Double)
    Application.StatusBar = SR_APP & ": optimizaci" & ChrW$(243) & "n - prueba " & k & " de " & n & _
        "   mejor = " & Format(o, "#,##0.00##") & IIf(v > 0, " (no factible)", "") & "   (Esc para detener)"
    DoEvents
End Sub

Private Sub EscribirRegistro(ByVal wb As Workbook, ByRef logV() As Variant, ByVal nLog As Long, ByRef bestX() As Double)
    Dim ws As Worksheet, j As Long, i As Long, al As Boolean, act As Object, mejorO() As Variant, ch As Object
    Dim fila As Long, bo As Double, hay As Boolean, ok As Boolean
    On Error Resume Next
    Set act = wb.ActiveSheet
    al = Application.DisplayAlerts
    Application.DisplayAlerts = False
    wb.Worksheets(HOJA_OPTLOG).Delete
    Application.DisplayAlerts = al
    On Error GoTo 0
    If nLog > UBound(logV, 1) Then nLog = UBound(logV, 1)
    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(HOJA_OPT))
    ws.Name = HOJA_OPTLOG
    ActiveWindow.DisplayGridlines = False
    ws.Cells.Font.Size = 10
    ws.Range("A1").Value = "Registro de la optimizaci" & ChrW$(243) & "n  (" & Format(Now, "dd/mm/yyyy hh:nn") & ")"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 13
    ws.Range("A1").Font.Color = RGB(154, 61, 12)
    ws.Range("A3").Resize(1, 4).Value = Array("Prueba", "Objetivo", "Factible", "Mejor hasta ahora")
    For j = 1 To oNV
        ws.Cells(3, 4 + j).Value = CellLabel(oVar(j))
    Next j
    ws.Range("A3").Resize(1, 4 + oNV).Font.Bold = True
    ws.Range("A3").Resize(1, 4 + oNV).Interior.Color = RGB(253, 240, 231)
    ReDim mejorO(1 To nLog, 1 To 1)
    For i = 1 To nLog
        ok = (logV(i, 3) <> "No")
        If ok Then
            If Not hay Then
                bo = logV(i, 2)
                hay = True
            ElseIf (oMax_ And logV(i, 2) > bo) Or (Not oMax_ And logV(i, 2) < bo) Then
                bo = logV(i, 2)
            End If
        End If
        If hay Then mejorO(i, 1) = bo Else mejorO(i, 1) = Empty
    Next i
    ws.Range("A4").Resize(nLog, 3).Value2 = SubMatriz(logV, nLog, 1, 3)
    ws.Range("D4").Resize(nLog, 1).Value2 = mejorO
    ws.Range("E4").Resize(nLog, oNV).Value2 = SubMatriz(logV, nLog, 4, 3 + oNV)
    ws.Range("B4").Resize(nLog, 1).NumberFormat = "#,##0.00##"
    ws.Range("D4").Resize(nLog, 1).NumberFormat = "#,##0.00##"
    ws.Columns("A:D").ColumnWidth = 14
    ws.Range("E3").Resize(1, oNV).EntireColumn.ColumnWidth = 14
    If hay Then
        Set ch = ws.ChartObjects.Add(ws.Cells(3, 6 + oNV).Left, ws.Range("A3").Top, 420, 240)
        With ch.Chart
            .ChartType = xlLine
            Do While .SeriesCollection.Count < 1
                .SeriesCollection.NewSeries
            Loop
            .SeriesCollection(1).Values = ws.Range("D4").Resize(nLog, 1)
            .SeriesCollection(1).XValues = ws.Range("A4").Resize(nLog, 1)
            .SeriesCollection(1).Format.Line.ForeColor.RGB = RGB(217, 86, 26)
            .SeriesCollection(1).Format.Line.Weight = 2
            .HasLegend = False
            .HasTitle = True
            .ChartTitle.Text = "Mejor objetivo factible por prueba"
            .ChartTitle.Font.Size = 11
            .Axes(xlValue).MajorGridlines.Format.Line.ForeColor.RGB = RGB(236, 235, 232)
            .ChartArea.Format.Line.Visible = msoFalse
        End With
    End If
    If Not act Is Nothing Then act.Activate
End Sub

Private Function SubMatriz(ByRef m() As Variant, ByVal n As Long, ByVal c1 As Long, ByVal c2 As Long) As Variant
    Dim r() As Variant, i As Long, j As Long
    ReDim r(1 To n, 1 To c2 - c1 + 1)
    For i = 1 To n
        For j = c1 To c2
            r(i, j - c1 + 1) = m(i, j)
        Next j
    Next i
    SubMatriz = r
End Function
