Attribute VB_Name = "modSRAjuste"
Option Explicit

' ============================================================
'  SimRiesgo - Ajuste de distribuciones a datos (maxima verosimilitud)
' ============================================================
'  Candidatas continuas y discretas; estimacion por maxima verosimilitud
'  (formas cerradas cuando existen, Nelder-Mead en el resto) y ranking por AIC,
'  con BIC y el estadistico D de Kolmogorov-Smirnov como referencia.

Public Const HOJA_AJUSTE As String = "SR Ajuste"
Private Const FILA_TABLA As Long = 6
Private Const MAX_PUNTOS As Long = 400

Private aX() As Double          ' datos ordenados
Private aN As Long
Private aMin As Double, aMax As Double, aRng As Double
Private aSumX As Double, aSumLX As Double, aSumIX As Double

' ------------------------------------------------------------
'  Utilidades numericas
' ------------------------------------------------------------
Public Function LnGamma(ByVal x As Double) As Double
    Dim c As Variant, s As Double, t As Double, i As Long
    c = Array(76.1800917294715, -86.5053203294168, 24.0140982408309, -1.23173957245015, 1.20865097386618E-03, -5.395239384953E-06)
    t = x + 5.5
    t = t - (x + 0.5) * Log(t)
    s = 1.00000000019001
    For i = 0 To 5
        s = s + c(i) / (x + 1 + i)
    Next i
    LnGamma = -t + Log(2.506628274631 * s / x)
End Function

Private Function Logistica(ByVal z As Double) As Double
    If z > 40 Then
        Logistica = 1
    ElseIf z < -40 Then
        Logistica = 0
    Else
        Logistica = 1 / (1 + Exp(-z))
    End If
End Function

Private Function Logit(ByVal p As Double) As Double
    If p < 0.000001 Then p = 0.000001
    If p > 0.999999 Then p = 0.999999
    Logit = Log(p / (1 - p))
End Function

Private Function ExpS(ByVal z As Double) As Double
    If z > 700 Then z = 700
    If z < -700 Then z = -700
    ExpS = Exp(z)
End Function

' Redondea a 6 cifras significativas
Public Function Sig6(ByVal x As Double) As Double
    Dim d As Long
    If x = 0 Then Exit Function
    d = 5 - Int(Log(Abs(x)) / Log(10#))
    If d < 0 Then d = 0
    If d > 12 Then d = 12
    Sig6 = Round(x, d)
End Function

' ------------------------------------------------------------
'  Transformacion parametros libres <-> parametros de la distribucion
' ------------------------------------------------------------
Private Sub ThetaAParam(ByVal t As Long, ByRef th() As Double, ByRef p() As Double)
    Dim a As Double, b As Double
    ReDim p(1 To 4)
    Select Case t
        Case D_NORMAL
            p(1) = th(1): p(2) = ExpS(th(2))
        Case D_WEIB, D_GAMMA
            p(1) = ExpS(th(1)): p(2) = ExpS(th(2))
        Case D_LOGLOG
            p(1) = ExpS(th(1)): p(2) = ExpS(th(2)): p(3) = 0
        Case D_PEARSON5
            p(1) = ExpS(th(1)): p(2) = ExpS(th(2)): p(3) = 0
        Case D_TRIANG, D_PERT
            a = aMin - ExpS(th(1)) * aRng
            b = aMax + ExpS(th(2)) * aRng
            p(1) = a: p(3) = b: p(2) = a + (b - a) * Logistica(th(3))
        Case D_BETA
            a = aMin - ExpS(th(1)) * aRng
            b = aMax + ExpS(th(2)) * aRng
            p(3) = a: p(4) = b: p(1) = ExpS(th(3)): p(2) = ExpS(th(4))
        Case D_NTRUNC
            p(1) = th(1): p(2) = ExpS(th(2))
            p(3) = aMin - aRng / aN: p(4) = aMax + aRng / aN
    End Select
End Sub

' Log-verosimilitud con estadisticos suficientes cuando es posible (rapido)
Public Function LogVeros(ByVal t As Long, ByRef p() As Double) As Double
    Dim i As Long, s As Double, x As Double, y As Double, a As Double, b As Double, c As Double
    Dim al As Double, be As Double, lb As Double, z As Double
    Const MALO As Double = -1E+300
    On Error GoTo invalido
    Select Case t
        Case D_NORMAL
            If p(2) <= 0 Then GoTo invalido
            For i = 1 To aN
                z = (aX(i) - p(1)) / p(2)
                s = s + z * z
            Next i
            LogVeros = -aN * (0.918938533204673 + Log(p(2))) - s / 2
        Case D_NTRUNC
            If p(2) <= 0 Then GoTo invalido
            z = NormSDist((p(4) - p(1)) / p(2)) - NormSDist((p(3) - p(1)) / p(2))
            If z <= 0 Then GoTo invalido
            For i = 1 To aN
                y = (aX(i) - p(1)) / p(2)
                s = s + y * y
            Next i
            LogVeros = -aN * (0.918938533204673 + Log(p(2)) + Log(z)) - s / 2
        Case D_LOGN
            a = Log(1 + (p(2) / p(1)) ^ 2)
            b = Log(p(1)) - a / 2
            For i = 1 To aN
                z = Log(aX(i)) - b
                s = s + z * z
            Next i
            LogVeros = -aN * (0.918938533204673 + 0.5 * Log(a)) - aSumLX - s / (2 * a)
        Case D_EXPO
            LogVeros = -aN * Log(p(1)) - aSumX / p(1)
        Case D_UNIF
            If aMin < p(1) Or aMax > p(2) Then GoTo invalido
            LogVeros = -aN * Log(p(2) - p(1))
        Case D_GAMMA
            LogVeros = (p(1) - 1) * aSumLX - aSumX / p(2) - aN * (LnGamma(p(1)) + p(1) * Log(p(2)))
        Case D_PEARSON5
            LogVeros = aN * (p(1) * Log(p(2)) - LnGamma(p(1))) - (p(1) + 1) * aSumLX - p(2) * aSumIX
        Case D_WEIB
            For i = 1 To aN
                s = s + (aX(i) / p(2)) ^ p(1)
            Next i
            LogVeros = aN * (Log(p(1)) - p(1) * Log(p(2))) + (p(1) - 1) * aSumLX - s
        Case D_LOGLOG
            For i = 1 To aN
                s = s + Log(1 + (aX(i) / p(1)) ^ p(2))
            Next i
            LogVeros = aN * (Log(p(2)) - p(2) * Log(p(1))) + (p(2) - 1) * aSumLX - 2 * s
        Case D_TRIANG
            a = p(1): c = p(2): b = p(3)
            For i = 1 To aN
                x = aX(i)
                If x <= a Or x >= b Then GoTo invalido
                If x < c Then
                    s = s + Log(2 * (x - a) / ((b - a) * (c - a)))
                ElseIf x > c Then
                    s = s + Log(2 * (b - x) / ((b - a) * (b - c)))
                Else
                    s = s + Log(2 / (b - a))
                End If
            Next i
            LogVeros = s
        Case D_PERT, D_BETA
            If t = D_PERT Then
                a = p(1): b = p(3)
                al = 1 + 4 * (p(2) - a) / (b - a)
                be = 1 + 4 * (b - p(2)) / (b - a)
            Else
                a = p(3): b = p(4): al = p(1): be = p(2)
            End If
            If b <= a Or al <= 0 Or be <= 0 Then GoTo invalido
            lb = LnGamma(al) + LnGamma(be) - LnGamma(al + be)
            For i = 1 To aN
                y = (aX(i) - a) / (b - a)
                If y <= 0 Or y >= 1 Then GoTo invalido
                s = s + (al - 1) * Log(y) + (be - 1) * Log(1 - y)
            Next i
            LogVeros = s - aN * (lb + Log(b - a))
        Case D_POIS
            For i = 1 To aN
                s = s + LnGamma(aX(i) + 1)
            Next i
            LogVeros = aSumX * Log(p(1)) - aN * p(1) - s
        Case D_BINOM
            If p(2) <= 0 Or p(2) >= 1 Then GoTo invalido
            For i = 1 To aN
                If aX(i) > p(1) Then GoTo invalido
                s = s + LnGamma(p(1) + 1) - LnGamma(aX(i) + 1) - LnGamma(p(1) - aX(i) + 1)
            Next i
            LogVeros = s + aSumX * Log(p(2)) + (aN * p(1) - aSumX) * Log(1 - p(2))
        Case D_BERN
            a = aSumX
            If p(1) <= 0 Or p(1) >= 1 Then GoTo invalido
            LogVeros = a * Log(p(1)) + (aN - a) * Log(1 - p(1))
        Case Else
            GoTo invalido
    End Select
    Exit Function
invalido:
    LogVeros = MALO
End Function

Private Function Objetivo(ByVal t As Long, ByRef th() As Double) As Double
    Dim p() As Double, v As Double
    ThetaAParam t, th, p
    v = LogVeros(t, p)
    Objetivo = -v
End Function

' Minimizacion de Nelder-Mead sobre th (dimension d)
Private Sub NelderMead(ByVal t As Long, ByRef th() As Double, ByVal d As Long)
    Dim S() As Double, f() As Double, i As Long, j As Long, it As Long, h As Long, l As Long, sg As Long
    Dim c() As Double, xr() As Double, xe() As Double, xc() As Double, fr As Double, fe As Double, fc As Double
    Dim tmp As Double, paso As Double, k As Long
    ReDim S(1 To d + 1, 1 To d)
    ReDim f(1 To d + 1)
    ReDim c(1 To d): ReDim xr(1 To d): ReDim xe(1 To d): ReDim xc(1 To d)
    For i = 1 To d + 1
        For j = 1 To d
            S(i, j) = th(j)
        Next j
        If i > 1 Then
            paso = 0.3 * Abs(th(i - 1))
            If paso < 0.3 Then paso = 0.3
            S(i, i - 1) = S(i, i - 1) + paso
        End If
        For j = 1 To d
            xr(j) = S(i, j)
        Next j
        f(i) = Objetivo(t, xr)
    Next i
    For it = 1 To 600 * d
        ' mejor (l), peor (h) y segundo peor (sg)
        l = 1: h = 1
        For i = 2 To d + 1
            If f(i) < f(l) Then l = i
            If f(i) > f(h) Then h = i
        Next i
        sg = l
        For i = 1 To d + 1
            If i <> h And f(i) > f(sg) Then sg = i
        Next i
        If Abs(f(h) - f(l)) <= 0.000000001 * (Abs(f(l)) + 0.000000001) Then Exit For
        For j = 1 To d
            c(j) = 0
            For i = 1 To d + 1
                If i <> h Then c(j) = c(j) + S(i, j)
            Next i
            c(j) = c(j) / d
            xr(j) = c(j) + (c(j) - S(h, j))
        Next j
        fr = Objetivo(t, xr)
        If fr < f(l) Then
            For j = 1 To d
                xe(j) = c(j) + 2 * (c(j) - S(h, j))
            Next j
            fe = Objetivo(t, xe)
            If fe < fr Then
                For j = 1 To d: S(h, j) = xe(j): Next j
                f(h) = fe
            Else
                For j = 1 To d: S(h, j) = xr(j): Next j
                f(h) = fr
            End If
        ElseIf fr < f(sg) Then
            For j = 1 To d: S(h, j) = xr(j): Next j
            f(h) = fr
        Else
            If fr < f(h) Then
                For j = 1 To d: xc(j) = c(j) + 0.5 * (xr(j) - c(j)): Next j
            Else
                For j = 1 To d: xc(j) = c(j) + 0.5 * (S(h, j) - c(j)): Next j
            End If
            fc = Objetivo(t, xc)
            If fc < f(h) And fc < fr Then
                For j = 1 To d: S(h, j) = xc(j): Next j
                f(h) = fc
            Else
                ' encogimiento hacia el mejor punto
                For i = 1 To d + 1
                    If i <> l Then
                        For j = 1 To d
                            S(i, j) = S(l, j) + 0.5 * (S(i, j) - S(l, j))
                            xr(j) = S(i, j)
                        Next j
                        f(i) = Objetivo(t, xr)
                    End If
                Next i
            End If
        End If
    Next it
    l = 1
    For i = 2 To d + 1
        If f(i) < f(l) Then l = i
    Next i
    For j = 1 To d
        th(j) = S(l, j)
    Next j
End Sub

' Optimiza con un reinicio desde la solucion (mejora la robustez)
Private Sub Optimizar(ByVal t As Long, ByRef th() As Double, ByVal d As Long)
    NelderMead t, th, d
    NelderMead t, th, d
End Sub

' ------------------------------------------------------------
'  Ajuste de una distribucion: devuelve False si no aplica a los datos
' ------------------------------------------------------------
Public Function AjustarUna(ByVal t As Long, ByRef p() As Double, ByRef LL As Double, ByRef k As Long) As Boolean
    Dim th() As Double, i As Long, m As Double, v As Double, s As Double, ml As Double, vl As Double
    Dim a As Double, b As Double, c0 As Double, y As Double, cm As Double, enteros As Boolean
    ReDim p(1 To 4)
    m = aSumX / aN
    For i = 1 To aN
        v = v + (aX(i) - m) ^ 2
    Next i
    v = v / (aN - 1)
    s = Sqr(v)
    If s <= 0 Then Exit Function
    enteros = True
    For i = 1 To aN
        If aX(i) <> Int(aX(i)) Then
            enteros = False
            Exit For
        End If
    Next i

    Select Case t
        Case D_NORMAL
            k = 2
            p(1) = m: p(2) = Sqr(v * (aN - 1) / aN)
        Case D_UNIF
            k = 2
            p(1) = aMin - aRng / (aN - 1): p(2) = aMax + aRng / (aN - 1)
        Case D_LOGN
            If aMin <= 0 Then Exit Function
            k = 2
            ml = aSumLX / aN
            For i = 1 To aN
                vl = vl + (Log(aX(i)) - ml) ^ 2
            Next i
            vl = vl / aN
            p(1) = Exp(ml + vl / 2)
            p(2) = p(1) * Sqr(Exp(vl) - 1)
        Case D_EXPO
            If aMin < 0 Then Exit Function
            k = 1
            p(1) = m
        Case D_POIS
            If aMin < 0 Or Not enteros Then Exit Function
            k = 1
            p(1) = m
        Case D_BERN
            If Not enteros Or aMin < 0 Or aMax > 1 Then Exit Function
            k = 1
            p(1) = m
        Case D_BINOM
            If Not enteros Or aMin < 0 Or aMax < 2 Then Exit Function
            k = 2
            p(1) = aMax
            p(2) = m / aMax
        Case D_GAMMA, D_WEIB
            If aMin <= 0 Then Exit Function
            k = 2
            ReDim th(1 To 2)
            If t = D_GAMMA Then
                th(1) = Log(m * m / v): th(2) = Log(v / m)
            Else
                y = (s / m) ^ (-1.086)
                th(1) = Log(y): th(2) = Log(m / Exp(LnGamma(1 + 1 / y)))
            End If
            Optimizar t, th, 2
            ThetaAParam t, th, p
        Case D_LOGLOG
            If aMin <= 0 Then Exit Function
            k = 2
            ml = aSumLX / aN
            For i = 1 To aN
                vl = vl + (Log(aX(i)) - ml) ^ 2
            Next i
            vl = Sqr(vl / (aN - 1))
            ReDim th(1 To 2)
            th(1) = ml
            th(2) = Log(3.14159265358979 / (1.73205080756888 * vl))
            Optimizar t, th, 2
            ThetaAParam t, th, p
        Case D_PEARSON5
            If aMin <= 0 Then Exit Function
            k = 2
            ml = aSumIX / aN
            For i = 1 To aN
                vl = vl + (1 / aX(i) - ml) ^ 2
            Next i
            vl = vl / (aN - 1)
            ReDim th(1 To 2)
            th(1) = Log(ml * ml / vl)
            th(2) = Log(ml / vl)
            Optimizar t, th, 2
            ThetaAParam t, th, p
        Case D_TRIANG, D_PERT
            k = 3
            ReDim th(1 To 3)
            th(1) = Log(0.05): th(2) = Log(0.05)
            a = aMin - 0.05 * aRng: b = aMax + 0.05 * aRng
            If t = D_TRIANG Then c0 = 3 * m - a - b Else c0 = (6 * m - a - b) / 4
            th(3) = Logit((c0 - a) / (b - a))
            Optimizar t, th, 3
            ThetaAParam t, th, p
        Case D_BETA
            k = 4
            ReDim th(1 To 4)
            th(1) = Log(0.05): th(2) = Log(0.05)
            a = aMin - 0.05 * aRng: b = aMax + 0.05 * aRng
            y = (m - a) / (b - a)
            vl = v / (b - a) ^ 2
            cm = y * (1 - y) / vl - 1
            If cm <= 0 Then cm = 4
            th(3) = Log(y * cm): th(4) = Log((1 - y) * cm)
            Optimizar t, th, 4
            ThetaAParam t, th, p
        Case D_NTRUNC
            k = 4
            ReDim th(1 To 2)
            th(1) = m: th(2) = Log(s)
            Optimizar t, th, 2
            ThetaAParam t, th, p
        Case Else
            Exit Function
    End Select
    For i = 1 To 4
        p(i) = Sig6(p(i))
    Next i
    If t = D_TRIANG Or t = D_PERT Then
        If p(2) < p(1) Then p(2) = p(1)
        If p(2) > p(3) Then p(2) = p(3)
    End If
    If Len(ValidarParametros(t, p)) > 0 Then Exit Function
    LL = LogVeros(t, p)
    If LL <= -1E+299 Then Exit Function
    AjustarUna = True
End Function

' Estadistico D de Kolmogorov-Smirnov
Public Function EstadisticoKS(ByVal t As Long, ByRef p() As Double) As Double
    Dim i As Long, F As Double, d As Double, m As Double
    On Error GoTo malo
    For i = 1 To aN
        F = Cdf(t, aX(i), p)
        d = Abs(i / aN - F)
        If d > m Then m = d
        d = Abs(F - (i - 1) / aN)
        If d > m Then m = d
    Next i
    EstadisticoKS = m
    Exit Function
malo:
    EstadisticoKS = -1
End Function

' Carga datos (ordenados) en el modulo; devuelve n
Public Function CargarDatosAjuste(ByVal v As Variant) As Long
    Dim x As Variant, n As Long, c As Range, tot As Long
    If TypeName(v) = "Range" Then
        tot = v.Cells.Count
    Else
        For Each x In v
            tot = tot + 1
        Next x
    End If
    If tot < 1 Then tot = 1
    ReDim aX(1 To tot)
    If TypeName(v) = "Range" Then
        For Each c In v.Cells
            If VarType(c.Value2) = vbDouble Then
                n = n + 1
                aX(n) = c.Value2
            End If
        Next c
    Else
        For Each x In v
            If VarType(x) = vbDouble Then
                n = n + 1
                aX(n) = x
            End If
        Next x
    End If
    aN = n
    CargarDatosAjuste = n
    If n < 2 Then Exit Function
    ReDim Preserve aX(1 To n)
    OrdenarD aX, 1, n
    aMin = aX(1): aMax = aX(n): aRng = aMax - aMin
    If aRng <= 0 Then aRng = 1
    aSumX = 0: aSumLX = 0: aSumIX = 0
    For n = 1 To aN
        aSumX = aSumX + aX(n)
        If aX(n) > 0 Then
            aSumLX = aSumLX + Log(aX(n))
            aSumIX = aSumIX + 1 / aX(n)
        End If
    Next n
End Function

Public Function DatoAjuste(ByVal i As Long) As Double
    DatoAjuste = aX(i)
End Function

Public Function NDatosAjuste() As Long
    NDatosAjuste = aN
End Function

' Formula de celda (separador ingles) para una distribucion ajustada
Public Function FormulaAjuste(ByVal t As Long, ByRef p() As Double) As String
    Dim idx As Long, np As Long, i As Long, s As String
    For idx = 0 To 14
        If CatalogoCodigo(idx) = t Then Exit For
    Next idx
    If idx > 14 Then Exit Function
    np = UBound(EtiquetasParam(t)) + 1
    s = "=" & CatalogoFuncion(idx) & "("
    For i = 1 To np
        s = s & IIf(i > 1, ",", "") & NumJ(p(i))
    Next i
    FormulaAjuste = s & ")"
End Function

' ------------------------------------------------------------
'  Comando de la cinta
' ------------------------------------------------------------
Public Sub SR_AjustarDistribucion()
    Dim rg As Range, n As Long, cand As Variant, i As Long, j As Long, t As Long, p() As Double
    Dim LL As Double, k As Long, nRes As Long, resT() As Long, resP() As Double, resLL() As Double
    Dim resK() As Long, resAIC() As Double, resBIC() As Double, resKS() As Double, orden() As Long
    Dim wb As Workbook, ws As Worksheet, r As Long, m As Double, v As Double, sk As Double, tmp As Long
    Dim shp As Object, pp() As Double, origen As String, dcol() As Variant, enteros As Boolean, distintos As Long

    If TypeName(Selection) = "Range" Then
        If Selection.Cells.Count >= 10 Then Set rg = Selection
    End If
    If rg Is Nothing Then
        On Error Resume Next
        Set rg = Application.InputBox("Seleccione el rango con los datos a ajustar (al menos 10 valores):", _
                                      SR_APP & " - Ajustar distribuci" & ChrW$(243) & "n", Type:=8)
        On Error GoTo 0
        If rg Is Nothing Then Exit Sub
    End If
    origen = CellLabel(rg.Cells(1, 1)) & ":" & rg.Cells(rg.Rows.Count, rg.Columns.Count).Address(False, False)
    n = CargarDatosAjuste(rg)
    If n < 10 Then
        MsgBox "Se necesitan al menos 10 valores num" & ChrW$(233) & "ricos (hay " & n & ").", vbExclamation, SR_APP
        Exit Sub
    End If
    If aMax = aMin Then
        MsgBox "Todos los datos son iguales; no hay variabilidad que ajustar.", vbExclamation, SR_APP
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = SR_APP & ": ajustando distribuciones a " & n & " datos..."
    ' datos enteros con pocos valores distintos -> distribuciones discretas
    enteros = True
    distintos = 1
    For i = 1 To n
        If aX(i) <> Int(aX(i)) Then enteros = False
        If i > 1 Then
            If aX(i) <> aX(i - 1) Then distintos = distintos + 1
        End If
    Next i
    If enteros And distintos <= 30 And aMin >= 0 Then
        cand = Array(D_POIS, D_BINOM, D_BERN)
    Else
        cand = Array(D_NORMAL, D_LOGN, D_GAMMA, D_WEIB, D_EXPO, D_LOGLOG, D_PEARSON5, D_TRIANG, D_PERT, _
                     D_UNIF, D_BETA, D_NTRUNC)
    End If
    ReDim resT(1 To 20): ReDim resP(1 To 20, 1 To 4): ReDim resLL(1 To 20): ReDim resK(1 To 20)
    ReDim resAIC(1 To 20): ReDim resBIC(1 To 20): ReDim resKS(1 To 20)
    For i = 0 To UBound(cand)
        t = cand(i)
        If AjustarUna(t, p, LL, k) Then
            nRes = nRes + 1
            resT(nRes) = t
            For j = 1 To 4
                resP(nRes, j) = p(j)
            Next j
            resLL(nRes) = LL
            resK(nRes) = k
            resAIC(nRes) = 2 * k - 2 * LL
            resBIC(nRes) = k * Log(n) - 2 * LL
            resKS(nRes) = EstadisticoKS(t, p)
        End If
        DoEvents
    Next i
    If nRes = 0 Then
        Application.StatusBar = False
        Application.ScreenUpdating = True
        MsgBox "Ninguna distribuci" & ChrW$(243) & "n pudo ajustarse a los datos.", vbExclamation, SR_APP
        Exit Sub
    End If
    ReDim orden(1 To nRes)
    For i = 1 To nRes
        orden(i) = i
    Next i
    For i = 2 To nRes
        tmp = orden(i)
        j = i - 1
        Do While j >= 1
            If resAIC(orden(j)) <= resAIC(tmp) Then Exit Do
            orden(j + 1) = orden(j)
            j = j - 1
        Loop
        orden(j + 1) = tmp
    Next i

    On Error GoTo falla
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set ws = wb.Worksheets(1)
    ws.Name = HOJA_AJUSTE
    ActiveWindow.DisplayGridlines = False
    ws.Cells.Font.Size = 10
    ws.Columns("A").ColumnWidth = 2
    ws.Columns("B").ColumnWidth = 16
    ws.Columns("C").ColumnWidth = 12
    ws.Columns("D").ColumnWidth = 3
    ws.Columns("E").ColumnWidth = 4
    ws.Columns("F").ColumnWidth = 17
    ws.Columns("G").ColumnWidth = 34
    ws.Columns("H:J").ColumnWidth = 11
    ws.Columns("K").ColumnWidth = 44

    With ws.Range("B2")
        .Value = "Ajuste de distribuciones"
        .Font.Size = 15
        .Font.Bold = True
        .Font.Color = RGB(154, 61, 12)
    End With
    ws.Range("B3").Value = "Datos: " & origen & "   " & ChrW$(183) & "   n = " & Format(n, "#,##0") & _
        "   " & ChrW$(183) & "   ranking por AIC (menor es mejor)"
    ws.Range("B3").Font.Color = RGB(124, 123, 119)

    ' resumen de datos
    m = aSumX / n
    For i = 1 To n
        v = v + (aX(i) - m) ^ 2
        sk = sk + (aX(i) - m) ^ 3
    Next i
    sk = (sk / n) / (v / n) ^ 1.5
    v = Sqr(v / (n - 1))
    ws.Range("B5").Value = "Datos"
    ws.Range("B5").Font.Bold = True
    ws.Range("B6").Value = "n": ws.Range("C6").Value2 = n
    ws.Range("B7").Value = "Media": ws.Range("C7").Value2 = m
    ws.Range("B8").Value = "Desv. est" & ChrW$(225) & "ndar": ws.Range("C8").Value2 = v
    ws.Range("B9").Value = "M" & ChrW$(237) & "nimo": ws.Range("C9").Value2 = aMin
    ws.Range("B10").Value = "Mediana": ws.Range("C10").Value2 = PercentilOrdenado(aX, n, 0.5)
    ws.Range("B11").Value = "M" & ChrW$(225) & "ximo": ws.Range("C11").Value2 = aMax
    ws.Range("B12").Value = "Asimetr" & ChrW$(237) & "a": ws.Range("C12").Value2 = sk
    ws.Range("C7:C12").NumberFormat = "#,##0.00##"

    ' tabla de resultados
    r = FILA_TABLA - 1
    ws.Range("E" & r & ":K" & r).Value = Array("#", "Distribuci" & ChrW$(243) & "n", "Par" & ChrW$(225) & "metros", _
        "AIC", "BIC", "K-S (D)", "F" & ChrW$(243) & "rmula")
    With ws.Range("E" & r & ":K" & r)
        .Font.Bold = True
        .Interior.Color = RGB(253, 240, 231)
        .Borders(xlEdgeBottom).Color = RGB(217, 86, 26)
    End With
    For i = 1 To nRes
        j = orden(i)
        r = FILA_TABLA - 1 + i
        ReDim pp(1 To 4)
        For k = 1 To 4
            pp(k) = resP(j, k)
            ws.Cells(r, 42 + k).Value2 = pp(k)
        Next k
        ws.Cells(r, 42).Value2 = resT(j)
        ws.Cells(r, 5).Value2 = i
        ws.Cells(r, 6).Value = NombreTipo(resT(j))
        ws.Cells(r, 7).Value = Mid$(Descripcion(resT(j), pp), InStr(Descripcion(resT(j), pp), "("))
        ws.Cells(r, 8).Value2 = resAIC(j)
        ws.Cells(r, 9).Value2 = resBIC(j)
        ws.Cells(r, 10).Value2 = resKS(j)
        ws.Cells(r, 11).Value2 = "'" & FormulaAjuste(resT(j), pp)
        ws.Cells(r, 11).Font.Name = "Consolas"
        ws.Cells(r, 11).Font.Size = 9
    Next i
    ws.Range("H" & FILA_TABLA & ":I" & (FILA_TABLA + nRes - 1)).NumberFormat = "#,##0.0"
    ws.Range("J" & FILA_TABLA & ":J" & (FILA_TABLA + nRes - 1)).NumberFormat = "0.0000"
    ws.Range("E" & FILA_TABLA & ":K" & (FILA_TABLA + nRes - 1)).Borders(xlInsideHorizontal).Color = RGB(236, 235, 232)
    ws.Range("E" & FILA_TABLA & ":K" & FILA_TABLA).Font.Bold = True
    ws.Range("AV1").Value2 = nRes
    ws.Range("AV2").Value2 = n
    ws.Columns("AA:AV").Hidden = True

    ' datos para graficos
    ReDim dcol(1 To n, 1 To 1)
    For i = 1 To n
        dcol(i, 1) = aX(i)
    Next i
    ws.Range("AA1").Resize(n, 1).Value2 = dcol

    r = FILA_TABLA + nRes + 1
    ws.Cells(r, 5).Value = "Seleccione una fila de la tabla para ver su ajuste. " & _
        "Use el bot" & ChrW$(243) & "n para escribir la f" & ChrW$(243) & "rmula en el modelo."
    ws.Cells(r, 5).Font.Color = RGB(124, 123, 119)
    ws.Cells(r, 5).Font.Italic = True
    Set shp = ws.Shapes.AddShape(5, ws.Range("B14").Left, ws.Range("B14").Top, 150, 26)
    shp.Fill.ForeColor.RGB = RGB(217, 86, 26)
    shp.Line.Visible = msoFalse
    With shp.TextFrame2
        .TextRange.Text = "Usar en una celda..."
        .TextRange.Font.Size = 10
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
    End With
    shp.OnAction = "'" & ThisWorkbook.Name & "'!SR_AjusteAplicar"

    CrearGraficosAjuste ws, r + 2
    AjusteGraficos ws, FILA_TABLA
    ThisWorkbook.ArmarEventos
    ws.Range("F" & FILA_TABLA).Select
    wb.Saved = True
    Application.StatusBar = False
    Application.ScreenUpdating = True
    Exit Sub
falla:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "No se pudo completar el ajuste: " & Err.Description, vbExclamation, SR_APP
End Sub

Public Function NombreTipo(ByVal t As Long) As String
    Dim i As Long, nm As Variant
    nm = CatalogoNombres()
    For i = 0 To UBound(nm)
        If CatalogoCodigo(i) = t Then
            NombreTipo = nm(i)
            Exit Function
        End If
    Next i
End Function

Private Sub CrearGraficosAjuste(ByVal ws As Worksheet, ByVal fila As Long)
    Dim ch As Object, top As Double, lf As Double
    top = ws.Cells(fila, 5).Top
    lf = ws.Cells(fila, 5).Left
    ' histograma + densidad ajustada
    Set ch = ws.ChartObjects.Add(lf, top, 440, 280)
    ch.Name = "SRAjHist"
    With ch.Chart
        .ChartType = xlColumnClustered
        Do While .SeriesCollection.Count < 2
            .SeriesCollection.NewSeries
        Loop
        .SeriesCollection(1).Name = "Datos"
        .SeriesCollection(1).Format.Fill.ForeColor.RGB = RGB(205, 201, 195)
        .SeriesCollection(2).Name = "Ajuste"
        .SeriesCollection(2).ChartType = xlLine
        .SeriesCollection(2).Format.Line.ForeColor.RGB = RGB(217, 86, 26)
        .SeriesCollection(2).Format.Line.Weight = 2.25
        .ChartGroups(1).GapWidth = 0
        .HasLegend = True
        .Legend.Position = xlLegendPositionTop
        .HasTitle = True
        .ChartTitle.Font.Size = 11
        .PlotVisibleOnly = False
        .Axes(xlValue).MajorGridlines.Format.Line.ForeColor.RGB = RGB(236, 235, 232)
        .Axes(xlValue).TickLabels.NumberFormat = "General"
        .Axes(xlValue).TickLabels.Font.Size = 8
        .Axes(xlCategory).TickLabels.Font.Size = 8
        .ChartArea.Format.Line.Visible = msoFalse
    End With
    ' P-P
    Set ch = ws.ChartObjects.Add(lf + 450, top, 250, 280)
    ch.Name = "SRAjPP"
    ConfigDispersion ch.Chart, "Gr" & ChrW$(225) & "fico P-P", "Probabilidad emp" & ChrW$(237) & "rica", "Probabilidad ajustada"
    ' Q-Q
    Set ch = ws.ChartObjects.Add(lf + 710, top, 250, 280)
    ch.Name = "SRAjQQ"
    ConfigDispersion ch.Chart, "Gr" & ChrW$(225) & "fico Q-Q", "Cuantil de los datos", "Cuantil ajustado"
End Sub

Private Sub ConfigDispersion(ByVal c As Object, ByVal titulo As String, ByVal ex As String, ByVal ey As String)
    With c
        .ChartType = xlXYScatter
        Do While .SeriesCollection.Count < 2
            .SeriesCollection.NewSeries
        Loop
        .SeriesCollection(1).ChartType = xlXYScatter
        .SeriesCollection(1).MarkerStyle = xlMarkerStyleCircle
        .SeriesCollection(1).MarkerSize = 4
        .SeriesCollection(1).MarkerBackgroundColor = RGB(217, 86, 26)
        .SeriesCollection(1).MarkerForegroundColor = RGB(217, 86, 26)
        .SeriesCollection(2).ChartType = xlXYScatterLinesNoMarkers
        .SeriesCollection(2).Format.Line.ForeColor.RGB = RGB(124, 123, 119)
        .SeriesCollection(2).Format.Line.Weight = 1
        .SeriesCollection(2).Format.Line.DashStyle = msoLineDash
        .HasLegend = False
        .HasTitle = True
        .ChartTitle.Text = titulo
        .ChartTitle.Font.Size = 11
        .PlotVisibleOnly = False
        .Axes(xlCategory).HasTitle = True
        .Axes(xlCategory).AxisTitle.Text = ex
        .Axes(xlCategory).AxisTitle.Font.Size = 8
        .Axes(xlValue).HasTitle = True
        .Axes(xlValue).AxisTitle.Text = ey
        .Axes(xlValue).AxisTitle.Font.Size = 8
        .Axes(xlValue).MajorGridlines.Format.Line.ForeColor.RGB = RGB(236, 235, 232)
        .Axes(xlValue).TickLabels.Font.Size = 8
        .Axes(xlCategory).TickLabels.Font.Size = 8
        .ChartArea.Format.Line.Visible = msoFalse
    End With
End Sub

' Actualiza los graficos para la fila de la tabla indicada
Public Sub AjusteGraficos(ByVal ws As Worksheet, ByVal fila As Long)
    Dim n As Long, t As Long, p() As Double, i As Long, j As Long, nb As Long, w As Double, lo As Double
    Dim x() As Double, v As Variant, cnt() As Double, cen() As Variant, fit() As Variant, den() As Variant
    Dim m As Long, paso As Double, idx As Long, pe As Double, q As Double, pts() As Variant, ln() As Variant
    Dim enteros As Boolean, ev As Boolean, nRes As Long, c As Object, a As Double, b As Double

    On Error GoTo fin
    nRes = ws.Range("AV1").Value2
    If fila < FILA_TABLA Or fila > FILA_TABLA + nRes - 1 Then Exit Sub
    ev = Application.EnableEvents
    Application.EnableEvents = False
    t = ws.Cells(fila, 42).Value2
    ReDim p(1 To 4)
    For i = 1 To 4
        p(i) = ws.Cells(fila, 42 + i).Value2
    Next i
    n = ws.Range("AV2").Value2
    v = ws.Range("AA1").Resize(n, 1).Value2
    ReDim x(1 To n)
    enteros = True
    For i = 1 To n
        x(i) = v(i, 1)
        If x(i) <> Int(x(i)) Then enteros = False
    Next i

    ' histograma
    If enteros And x(n) - x(1) <= 60 Then
        nb = x(n) - x(1) + 1
        w = 1
        lo = x(1) - 0.5
    Else
        nb = Int(Sqr(n) + 0.5)
        If nb < 8 Then nb = 8
        If nb > 50 Then nb = 50
        w = (x(n) - x(1)) / nb
        lo = x(1)
    End If
    ReDim cnt(1 To nb)
    ReDim cen(1 To nb, 1 To 1)
    ReDim den(1 To nb, 1 To 1)
    ReDim fit(1 To nb, 1 To 1)
    For i = 1 To n
        j = Int((x(i) - lo) / w) + 1
        If j < 1 Then j = 1
        If j > nb Then j = nb
        cnt(j) = cnt(j) + 1
    Next i
    For j = 1 To nb
        cen(j, 1) = Sig6(lo + (j - 0.5) * w)
        den(j, 1) = cnt(j) / (n * w)
        If EsDiscreta(t) Then
            fit(j, 1) = Densidad(t, CDbl(cen(j, 1)), p) / w
        Else
            fit(j, 1) = (Cdf(t, lo + j * w, p) - Cdf(t, lo + (j - 1) * w, p)) / w
        End If
    Next j
    ws.Range("AB1:AL" & (MAX_PUNTOS + 60)).ClearContents
    ws.Range("AB1").Resize(nb, 1).Value2 = cen
    ws.Range("AC1").Resize(nb, 1).Value2 = den
    ws.Range("AD1").Resize(nb, 1).Value2 = fit
    Set c = ws.ChartObjects("SRAjHist").Chart
    c.SeriesCollection(1).Values = ws.Range("AC1").Resize(nb, 1)
    c.SeriesCollection(1).XValues = ws.Range("AB1").Resize(nb, 1)
    c.SeriesCollection(2).Values = ws.Range("AD1").Resize(nb, 1)
    c.SeriesCollection(2).XValues = ws.Range("AB1").Resize(nb, 1)
    c.Axes(xlCategory).TickLabelSpacing = IIf(nb > 12, Int(nb / 6), 1)
    c.ChartTitle.Text = NombreTipo(t) & "  " & CStr(ws.Cells(fila, 7).Value)

    ' P-P y Q-Q (submuestra uniforme de a lo sumo MAX_PUNTOS)
    m = n
    If m > MAX_PUNTOS Then m = MAX_PUNTOS
    ReDim pts(1 To m, 1 To 4)
    paso = n / m
    For i = 1 To m
        idx = Int((i - 0.5) * paso) + 1
        If idx > n Then idx = n
        pe = (idx - 0.5) / n
        pts(i, 1) = pe
        pts(i, 2) = Cdf(t, x(idx), p)
        pts(i, 3) = x(idx)
        pts(i, 4) = InvCdf(t, pe, p)
    Next i
    ws.Range("AE1").Resize(m, 4).Value2 = pts
    ReDim ln(1 To 2, 1 To 4)
    ln(1, 1) = 0: ln(1, 2) = 0: ln(2, 1) = 1: ln(2, 2) = 1
    a = x(1): b = x(n)
    If pts(1, 4) < a Then a = pts(1, 4)
    If pts(m, 4) > b Then b = pts(m, 4)
    ln(1, 3) = a: ln(1, 4) = a: ln(2, 3) = b: ln(2, 4) = b
    ws.Range("AI1").Resize(2, 4).Value2 = ln
    Set c = ws.ChartObjects("SRAjPP").Chart
    c.SeriesCollection(1).XValues = ws.Range("AE1").Resize(m, 1)
    c.SeriesCollection(1).Values = ws.Range("AF1").Resize(m, 1)
    c.SeriesCollection(2).XValues = ws.Range("AI1").Resize(2, 1)
    c.SeriesCollection(2).Values = ws.Range("AJ1").Resize(2, 1)
    Set c = ws.ChartObjects("SRAjQQ").Chart
    c.SeriesCollection(1).XValues = ws.Range("AG1").Resize(m, 1)
    c.SeriesCollection(1).Values = ws.Range("AH1").Resize(m, 1)
    c.SeriesCollection(2).XValues = ws.Range("AK1").Resize(2, 1)
    c.SeriesCollection(2).Values = ws.Range("AL1").Resize(2, 1)
    ws.Range("E" & FILA_TABLA & ":K" & (FILA_TABLA + nRes - 1)).Interior.Pattern = xlNone
    ws.Range("E" & fila & ":K" & fila).Interior.Color = RGB(253, 240, 231)
fin:
    Application.EnableEvents = ev
End Sub

Public Sub AjusteSeleccion(ByVal ws As Worksheet, ByVal Target As Range)
    On Error Resume Next
    If ws.Name <> HOJA_AJUSTE Then Exit Sub
    If Target.Cells.Count > 20 Then Exit Sub
    If Target.Column > 11 Then Exit Sub
    AjusteGraficos ws, Target.Row
End Sub

Public Sub SR_AjusteAplicar()
    Dim ws As Worksheet, fila As Long, nRes As Long, fx As String, destino As Range
    On Error Resume Next
    Set ws = ActiveSheet
    If ws.Name <> HOJA_AJUSTE Then Exit Sub
    nRes = ws.Range("AV1").Value2
    fila = ActiveCell.Row
    If fila < FILA_TABLA Or fila > FILA_TABLA + nRes - 1 Then fila = FILA_TABLA
    fx = CStr(ws.Cells(fila, 11).Value2)
    Set destino = Application.InputBox("Distribuci" & ChrW$(243) & "n elegida: " & ws.Cells(fila, 6).Value & vbCrLf & vbCrLf & _
        "Seleccione la celda del modelo donde escribir la f" & ChrW$(243) & "rmula" & vbCrLf & fx, SR_APP, Type:=8)
    If destino Is Nothing Then Exit Sub
    On Error GoTo falla
    destino.Cells(1, 1).Formula = fx
    destino.Worksheet.Parent.Activate
    destino.Worksheet.Activate
    destino.Cells(1, 1).Select
    Exit Sub
falla:
    MsgBox "No se pudo escribir la f" & ChrW$(243) & "rmula: " & Err.Description, vbExclamation, SR_APP
End Sub
