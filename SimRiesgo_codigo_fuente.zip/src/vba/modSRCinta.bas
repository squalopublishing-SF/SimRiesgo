Attribute VB_Name = "modSRCinta"
Option Explicit

' ============================================================
'  SimRiesgo - Cinta de opciones, configuracion y comandos
' ============================================================

Public gRibbon As Object

' ------------------------------------------------------------
'  Configuracion (se guarda en el registro de Windows del usuario)
' ------------------------------------------------------------
Public Function CfgIter() As Long
    Dim v As Long
    v = Val(GetSetting(SR_APP, "Config", "Iteraciones", "1000"))
    If v < 10 Then v = 10
    If v > 1000000 Then v = 1000000
    CfgIter = v
End Function

Public Function CfgSims() As Long
    Dim v As Long
    v = Val(GetSetting(SR_APP, "Config", "Simulaciones", "1"))
    If v < 1 Then v = 1
    If v > 50 Then v = 50
    CfgSims = v
End Function

Public Function CfgSampling() As Long
    CfgSampling = Val(GetSetting(SR_APP, "Config", "Muestreo", "0"))
End Function

Public Function CfgSeed() As Double
    CfgSeed = Val(GetSetting(SR_APP, "Config", "Semilla", "0"))
End Function

Public Function CfgConv() As Boolean
    CfgConv = (GetSetting(SR_APP, "Config", "Convergencia", "0") = "1")
End Function

' Tolerancia de convergencia como fraccion (0,03 = 3 %)
Public Function CfgTol() As Double
    Dim v As Double
    v = Val(GetSetting(SR_APP, "Config", "Tolerancia", "3")) / 100
    If v < 0.001 Then v = 0.001
    If v > 0.5 Then v = 0.5
    CfgTol = v
End Function

Public Function CfgGuardar() As Boolean
    CfgGuardar = (GetSetting(SR_APP, "Config", "GuardarEnLibro", "1") = "1")
End Function

Private Function EnteroDeTexto(ByVal txt As String, ByRef v As Double) As Boolean
    Dim t As String
    t = Replace(Replace(Replace(Trim$(txt), ".", ""), ",", ""), " ", "")
    If Len(t) = 0 Then Exit Function
    If Not IsNumeric(t) Then Exit Function
    v = Int(CDbl(t))
    EnteroDeTexto = True
End Function

Private Sub Refrescar(ByVal id As String)
    On Error Resume Next
    If Not gRibbon Is Nothing Then gRibbon.InvalidateControl id
End Sub

' ------------------------------------------------------------
'  Callbacks de la cinta
' ------------------------------------------------------------
Public Sub SR_OnLoad(ribbon As Object)
    Set gRibbon = ribbon
End Sub

Public Sub SR_GetIter(control As Object, ByRef returnedVal)
    returnedVal = CStr(CfgIter())
End Sub

Public Sub SR_SetIter(control As Object, text As String)
    Dim v As Double
    If EnteroDeTexto(text, v) Then
        If v < 10 Then v = 10
        If v > 1000000 Then v = 1000000
        SaveSetting SR_APP, "Config", "Iteraciones", CStr(v)
    Else
        MsgBox "Escriba un n" & ChrW$(250) & "mero entero de iteraciones (m" & ChrW$(237) & "nimo 10).", vbExclamation, SR_APP
    End If
    Refrescar "srIter"
End Sub

Public Sub SR_GetSims(control As Object, ByRef returnedVal)
    returnedVal = CStr(CfgSims())
End Sub

Public Sub SR_SetSims(control As Object, text As String)
    Dim v As Double
    If EnteroDeTexto(text, v) Then
        If v < 1 Then v = 1
        If v > 50 Then v = 50
        SaveSetting SR_APP, "Config", "Simulaciones", CStr(v)
    Else
        MsgBox "Escriba un n" & ChrW$(250) & "mero entero de simulaciones (1 a 50).", vbExclamation, SR_APP
    End If
    Refrescar "srSims"
End Sub

Public Sub SR_GetSeed(control As Object, ByRef returnedVal)
    Dim v As Double
    v = CfgSeed()
    If v <= 0 Then returnedVal = "Aleatoria" Else returnedVal = CStr(v)
End Sub

Public Sub SR_SetSeed(control As Object, text As String)
    Dim v As Double
    If LCase$(Left$(Trim$(text), 3)) = "ale" Or Trim$(text) = "" Or Trim$(text) = "0" Then
        SaveSetting SR_APP, "Config", "Semilla", "0"
    ElseIf EnteroDeTexto(text, v) Then
        If v < 0 Then v = 0
        SaveSetting SR_APP, "Config", "Semilla", CStr(v)
    Else
        MsgBox "Escriba un n" & ChrW$(250) & "mero entero como semilla, o 0 para semilla aleatoria.", vbExclamation, SR_APP
    End If
    Refrescar "srSeed"
End Sub

Public Sub SR_GetSampling(control As Object, ByRef returnedVal)
    returnedVal = CfgSampling()
End Sub

Public Sub SR_SetSampling(control As Object, selectedId As String, selectedIndex As Integer)
    SaveSetting SR_APP, "Config", "Muestreo", CStr(selectedIndex)
End Sub

Public Sub SR_GetRandom(control As Object, ByRef returnedVal)
    returnedVal = gRandomMode
End Sub

Public Sub SR_ToggleRandom(control As Object, pressed As Boolean)
    gRandomMode = pressed
    On Error Resume Next
    Application.CalculateFull
End Sub

Public Sub SR_GetConv(control As Object, ByRef returnedVal)
    returnedVal = CfgConv()
End Sub

Public Sub SR_ToggleConv(control As Object, pressed As Boolean)
    SaveSetting SR_APP, "Config", "Convergencia", IIf(pressed, "1", "0")
    Refrescar "srTol"
End Sub

Public Sub SR_GetTol(control As Object, ByRef returnedVal)
    returnedVal = Replace(Format(CfgTol() * 100, "0.0#"), ",", Application.International(xlDecimalSeparator))
End Sub

Public Sub SR_SetTol(control As Object, text As String)
    Dim t As String, v As Double
    t = Replace(Replace(Trim$(text), "%", ""), ",", ".")
    If Len(t) > 0 And IsNumeric(Replace(t, ".", Application.International(xlDecimalSeparator))) Then
        v = Val(t)
        If v < 0.1 Then v = 0.1
        If v > 50 Then v = 50
        SaveSetting SR_APP, "Config", "Tolerancia", Replace(CStr(v), ",", ".")
    Else
        MsgBox "Escriba la tolerancia como porcentaje (por ejemplo 3).", vbExclamation, SR_APP
    End If
    Refrescar "srTol"
End Sub

Public Sub SR_GetTolEnabled(control As Object, ByRef returnedVal)
    returnedVal = CfgConv()
End Sub

Public Sub SR_GetGuardar(control As Object, ByRef returnedVal)
    returnedVal = CfgGuardar()
End Sub

Public Sub SR_ToggleGuardar(control As Object, pressed As Boolean)
    SaveSetting SR_APP, "Config", "GuardarEnLibro", IIf(pressed, "1", "0")
End Sub

Public Sub SR_BtnCorrelacion(control As Object)
    SR_DefinirCorrelaciones
End Sub

Public Sub SR_BtnDefinir(control As Object)
    SR_VentanaDistribucion
End Sub

Public Sub SR_BtnAjuste(control As Object)
    SR_AjustarDistribucion
End Sub

Public Sub SR_BtnOptimizar(control As Object)
    SR_Optimizar
End Sub

Public Sub SR_BtnConfigOpt(control As Object)
    SR_ConfigurarOptimizacion
End Sub

Public Sub SR_BtnPdf(control As Object)
    SR_InformePDF
End Sub

Public Sub SR_BtnBorrarRes(control As Object)
    SR_BorrarResultadosLibro
End Sub

Public Sub SR_BtnSimular(control As Object)
    SR_Simular
End Sub

Public Sub SR_BtnVisor(control As Object)
    SR_AbrirVisor False
End Sub

Public Sub SR_BtnInforme(control As Object)
    SR_InformeExcel
End Sub

Public Sub SR_BtnSalida(control As Object)
    SR_AgregarSalida
End Sub

Public Sub SR_BtnModelo(control As Object)
    SR_ListaModelo
End Sub

Public Sub SR_BtnAyuda(control As Object)
    SR_Ayuda
End Sub

Public Sub SR_BtnAcerca(control As Object)
    MsgBox SR_APP & " " & SR_VER & vbCrLf & _
        "An" & ChrW$(225) & "lisis de riesgo con simulaci" & ChrW$(243) & "n Monte Carlo para Excel." & vbCrLf & vbCrLf & _
        "  " & ChrW$(8226) & " Generador MRG32k3a (L'Ecuyer)" & vbCrLf & _
        "  " & ChrW$(8226) & " Muestreo Monte Carlo o Hipercubo latino" & vbCrLf & _
        "  " & ChrW$(8226) & " 17 distribuciones por inversi" & ChrW$(243) & "n de la FDA y ajuste a datos" & vbCrLf & _
        "  " & ChrW$(8226) & " Correlaci" & ChrW$(243) & "n de rangos (Iman-Conover) y convergencia autom" & ChrW$(225) & "tica" & vbCrLf & _
        "  " & ChrW$(8226) & " Optimizaci" & ChrW$(243) & "n bajo incertidumbre (algoritmo gen" & ChrW$(233) & "tico)" & vbCrLf & _
        "  " & ChrW$(8226) & " Visor interactivo, informe Excel y PDF" & vbCrLf & vbCrLf & _
        "Desarrollado por SQUALO SOFTWARE" & vbCrLf & _
        ChrW$(169) & " 2026 SQUALO SOFTWARE. Todos los derechos reservados.", vbInformation, "Acerca de " & SR_APP
End Sub

Public Sub SR_InsertarDist(control As Object)
    InsertarDistribucion CStr(control.Tag)
End Sub

' ------------------------------------------------------------
'  Comandos
' ------------------------------------------------------------
Private Function NumF(ByVal x As Double) As String
    NumF = NumJ(Round(x, 6))
End Function

Public Sub InsertarDistribucion(ByVal tipo As String)
    Dim c As Range, v As Double, f As String
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    If c.HasFormula Then
        If MsgBox("La celda " & c.Address(False, False) & " ya contiene una f" & ChrW$(243) & "rmula. " & _
                  "Desea reemplazarla por una distribuci" & ChrW$(243) & "n?", vbYesNo + vbQuestion, SR_APP) = vbNo Then Exit Sub
    End If
    v = 0
    If VarType(c.Value2) = vbDouble Then v = c.Value2
    If v = 0 Then v = 100
    Select Case tipo
        Case "Normal": f = "=SRNormal(" & NumF(v) & "," & NumF(Abs(v) * 0.1) & ")"
        Case "Triangular": f = "=SRTriangular(" & NumF(v * 0.9) & "," & NumF(v) & "," & NumF(v * 1.2) & ")"
        Case "Pert": f = "=SRPert(" & NumF(v * 0.9) & "," & NumF(v) & "," & NumF(v * 1.2) & ")"
        Case "Uniforme": f = "=SRUniforme(" & NumF(v * 0.9) & "," & NumF(v * 1.1) & ")"
        Case "Lognormal": f = "=SRLognormal(" & NumF(Abs(v)) & "," & NumF(Abs(v) * 0.1) & ")"
        Case "Weibull": f = "=SRWeibull(2," & NumF(Abs(v)) & ")"
        Case "Exponencial": f = "=SRExponencial(" & NumF(Abs(v)) & ")"
        Case "Gamma": f = "=SRGamma(2," & NumF(Abs(v) / 2) & ")"
        Case "Beta": f = "=SRBeta(2,3," & NumF(v * 0.8) & "," & NumF(v * 1.3) & ")"
        Case "Poisson": f = "=SRPoisson(" & NumF(Abs(v)) & ")"
        Case "Binomial": f = "=SRBinomial(10,0.5)"
        Case "Bernoulli": f = "=SRBernoulli(0.3)"
        Case "Discreta": f = "=SRDiscreta({1,2,3},{0.2,0.5,0.3})"
        Case "LogLogistica": f = "=SRLogLogistica(" & NumF(Abs(v)) & ",4)"
        Case "Pearson5": f = "=SRPearson5(4," & NumF(Abs(v) * 3) & ")"
        Case "NormalTrunc": f = "=SRNormalTrunc(" & NumF(v) & "," & NumF(Abs(v) * 0.1) & "," & NumF(v - Abs(v) * 0.15) & "," & NumF(v + Abs(v) * 0.15) & ")"
        Case "Empirica"
            Dim rg As Range
            On Error Resume Next
            Set rg = Application.InputBox("Seleccione el rango con los datos hist" & ChrW$(243) & "ricos:", SR_APP, Type:=8)
            On Error GoTo 0
            If rg Is Nothing Then Exit Sub
            f = "=SREmpirica(" & rg.Address(True, True, xlA1, rg.Worksheet.Name <> c.Worksheet.Name) & ")"
        Case Else: Exit Sub
    End Select
    On Error GoTo falla
    c.Formula = f
    On Error Resume Next
    Application.Dialogs(xlDialogFunctionWizard).Show
    Exit Sub
falla:
    MsgBox "No se pudo escribir la distribuci" & ChrW$(243) & "n: " & Err.Description, vbExclamation, SR_APP
End Sub

Public Sub SR_AgregarSalida()
    Dim c As Range, f As String, grupo As String, multi As Boolean, nombre As String
    If TypeName(Selection) <> "Range" Then Exit Sub
    multi = (Selection.Cells.Count > 1)
    If multi Then
        grupo = InputBox("Se agregar" & ChrW$(225) & "n " & Selection.Cells.Count & " salidas." & vbCrLf & _
                         "Nombre del grupo (por ejemplo: Flujo de caja):", SR_APP, "Grupo")
        If StrPtr(grupo) = 0 Then Exit Sub
    End If
    On Error GoTo falla
    For Each c In Selection.Cells
        If c.HasFormula Then
            f = Mid$(c.Formula, 2)
        ElseIf Len(CStr(c.Value2)) > 0 And VarType(c.Value2) = vbDouble Then
            f = NumJ(c.Value2)
        Else
            f = ""
        End If
        If Len(f) > 0 Then
            If UCase$(Left$(f, 9)) <> "SRSALIDA(" Then
                If multi Then
                    c.Formula = "=SRSalida(" & f & ",""""," & """" & Replace(grupo, """", "") & """)"
                Else
                    c.Formula = "=SRSalida(" & f & ")"
                End If
            End If
        End If
    Next c
    Exit Sub
falla:
    MsgBox "No se pudo agregar la salida: " & Err.Description, vbExclamation, SR_APP
End Sub

Public Sub SR_ListaModelo()
    Dim calcMode As Long, wb As Workbook, ws As Worksheet, i As Long, r As Long
    If ActiveWorkbook Is Nothing Then Exit Sub
    calcMode = Application.Calculation
    Application.Calculation = xlCalculationManual
    If Not RegistrarModelo() Then
        Application.Calculation = calcMode
        MsgBox "No se pudo recalcular el modelo.", vbExclamation, SR_APP
        Exit Sub
    End If
    Application.CalculateFull
    Application.Calculation = calcMode
    If gInCount = 0 And gOutCount = 0 Then
        MsgBox "El modelo no contiene entradas (distribuciones SR...) ni salidas (SRSalida).", vbInformation, SR_APP
        Exit Sub
    End If
    Application.ScreenUpdating = False
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set ws = wb.Worksheets(1)
    ws.Name = "Modelo"
    ws.Range("A1").Value = SR_APP & " - Entradas y salidas del modelo"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 14
    r = 3
    ws.Cells(r, 1).Resize(1, 3).Value = Array("Salida", "Celda", "Grupo")
    ws.Cells(r, 1).Resize(1, 3).Font.Bold = True
    ws.Cells(r, 1).Resize(1, 3).Interior.Color = RGB(253, 240, 231)
    For i = 1 To gOutCount
        r = r + 1
        ws.Cells(r, 1).Value = gOutName(i)
        ws.Cells(r, 2).Value = gOutCell(i)
        ws.Cells(r, 3).Value = gOutGroup(i)
    Next i
    r = r + 2
    ws.Cells(r, 1).Resize(1, 3).Value = Array("Entrada", "Celda", "Distribuci" & ChrW$(243) & "n")
    ws.Cells(r, 1).Resize(1, 3).Font.Bold = True
    ws.Cells(r, 1).Resize(1, 3).Interior.Color = RGB(236, 240, 252)
    For i = 1 To gInCount
        r = r + 1
        ws.Cells(r, 1).Value = gInName(i)
        ws.Cells(r, 2).Value = gInCell(i)
        ws.Cells(r, 3).Value = gInDist(i)
    Next i
    ws.Columns("A:C").AutoFit
    Application.ScreenUpdating = True
End Sub

Public Sub SR_Ayuda()
    MsgBox "DISTRIBUCIONES (entradas)" & vbCrLf & _
        "  SRNormal(media; desv)            SRLognormal(media; desv)" & vbCrLf & _
        "  SRTriangular(m" & ChrW$(237) & "n; m" & ChrW$(225) & "s prob; m" & ChrW$(225) & "x)   SRPert(m" & ChrW$(237) & "n; m" & ChrW$(225) & "s prob; m" & ChrW$(225) & "x)" & vbCrLf & _
        "  SRUniforme(m" & ChrW$(237) & "n; m" & ChrW$(225) & "x)          SRWeibull(forma; escala)" & vbCrLf & _
        "  SRExponencial(media)             SRGamma(forma; escala)" & vbCrLf & _
        "  SRBeta(alfa1; alfa2; [m" & ChrW$(237) & "n]; [m" & ChrW$(225) & "x])   SRPoisson(lambda)" & vbCrLf & _
        "  SRBinomial(n; p)  SRBernoulli(p)  SRDiscreta(valores; probabilidades)" & vbCrLf & _
        "  SRLogLogistica(escala; forma; [ubic])   SRPearson5(alfa; beta; [ubic])" & vbCrLf & _
        "  SRNormalTrunc(media; desv; m" & ChrW$(237) & "n; m" & ChrW$(225) & "x)   SREmpirica(datos)" & vbCrLf & _
        "  Todas aceptan un " & ChrW$(250) & "ltimo argumento opcional: nombre.", vbInformation, SR_APP & " - Funciones (1 de 2)"
    MsgBox "SALIDAS" & vbCrLf & _
        "  SRSalida(valor; [nombre]; [grupo])" & vbCrLf & vbCrLf & _
        "ESCENARIOS (varias simulaciones)" & vbCrLf & _
        "  SRSimTabla(valor1; valor2; ...)  usa el valor k en la simulaci" & ChrW$(243) & "n k" & vbCrLf & vbCrLf & _
        "ESTAD" & ChrW$(205) & "STICOS DE RESULTADOS (despu" & ChrW$(233) & "s de simular)" & vbCrLf & _
        "  SRMedia, SRDesvEst, SRMinimo, SRMaximo, SRMediana (celda; [sim])" & vbCrLf & _
        "  SRPercentil(celda; p; [sim])     SRObjetivo(celda; x; [sim]) = P(X <= x)" & vbCrLf & _
        "  SRProbEntre(celda; desde; hasta; [sim])" & vbCrLf & vbCrLf & _
        "TE" & ChrW$(211) & "RICOS (sin simular)" & vbCrLf & _
        "  SRDensidad(tipo; x; p1..p4)  SRCuantil(tipo; prob; p1..p4)  SRMomento(tipo; cual; p1..p4)", vbInformation, SR_APP & " - Funciones (2 de 2)"
End Sub

' ------------------------------------------------------------
'  Descripciones de funciones para el asistente de Excel
' ------------------------------------------------------------
Public Sub SR_RegistrarFunciones()
    Dim nm As String
    On Error Resume Next
    nm = "Nombre opcional de la entrada (texto)"
    Reg "SRNormal", "Distribuci" & ChrW$(243) & "n normal.", Array("Media", "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar", nm)
    Reg "SRTriangular", "Distribuci" & ChrW$(243) & "n triangular.", Array("Valor m" & ChrW$(237) & "nimo", "Valor m" & ChrW$(225) & "s probable", "Valor m" & ChrW$(225) & "ximo", nm)
    Reg "SRPert", "Distribuci" & ChrW$(243) & "n PERT (beta suavizada a partir de tres puntos).", Array("Valor m" & ChrW$(237) & "nimo", "Valor m" & ChrW$(225) & "s probable", "Valor m" & ChrW$(225) & "ximo", nm)
    Reg "SRUniforme", "Distribuci" & ChrW$(243) & "n uniforme continua.", Array("Valor m" & ChrW$(237) & "nimo", "Valor m" & ChrW$(225) & "ximo", nm)
    Reg "SRLognormal", "Distribuci" & ChrW$(243) & "n lognormal definida por su media y desviaci" & ChrW$(243) & "n.", Array("Media (mayor que 0)", "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar", nm)
    Reg "SRWeibull", "Distribuci" & ChrW$(243) & "n de Weibull.", Array("Par" & ChrW$(225) & "metro de forma", "Par" & ChrW$(225) & "metro de escala", nm)
    Reg "SRExponencial", "Distribuci" & ChrW$(243) & "n exponencial.", Array("Media", nm)
    Reg "SRGamma", "Distribuci" & ChrW$(243) & "n gamma.", Array("Par" & ChrW$(225) & "metro de forma", "Par" & ChrW$(225) & "metro de escala", nm)
    Reg "SRBeta", "Distribuci" & ChrW$(243) & "n beta, opcionalmente escalada entre m" & ChrW$(237) & "nimo y m" & ChrW$(225) & "ximo.", Array("Alfa 1", "Alfa 2", "M" & ChrW$(237) & "nimo (por defecto 0)", "M" & ChrW$(225) & "ximo (por defecto 1)", nm)
    Reg "SRPoisson", "Distribuci" & ChrW$(243) & "n de Poisson.", Array("Media (lambda)", nm)
    Reg "SRBinomial", "Distribuci" & ChrW$(243) & "n binomial.", Array("N" & ChrW$(250) & "mero de ensayos", "Probabilidad de " & ChrW$(233) & "xito", nm)
    Reg "SRBernoulli", "Evento de riesgo: devuelve 1 con probabilidad p y 0 en caso contrario.", Array("Probabilidad de ocurrencia", nm)
    Reg "SRDiscreta", "Distribuci" & ChrW$(243) & "n discreta con valores y probabilidades.", Array("Valores (rango o matriz)", "Probabilidades (rango o matriz)", nm)
    Reg "SRLogLogistica", "Distribuci" & ChrW$(243) & "n log-log" & ChrW$(237) & "stica (Fisk).", Array("Escala (mayor que 0)", "Forma (mayor que 0)", "Ubicaci" & ChrW$(243) & "n (por defecto 0)", nm)
    Reg "SRPearson5", "Distribuci" & ChrW$(243) & "n Pearson tipo V (gamma inversa).", Array("Alfa (forma)", "Beta (escala)", "Ubicaci" & ChrW$(243) & "n (por defecto 0)", nm)
    Reg "SRNormalTrunc", "Distribuci" & ChrW$(243) & "n normal truncada entre un m" & ChrW$(237) & "nimo y un m" & ChrW$(225) & "ximo.", Array("Media de la normal original", "Desviaci" & ChrW$(243) & "n de la normal original", "M" & ChrW$(237) & "nimo", "M" & ChrW$(225) & "ximo", nm)
    Reg "SREmpirica", "Distribuci" & ChrW$(243) & "n emp" & ChrW$(237) & "rica continua construida a partir de datos hist" & ChrW$(243) & "ricos.", Array("Rango con los datos", nm)
    Reg "SRDensidad", "Densidad (o probabilidad puntual) te" & ChrW$(243) & "rica de una distribuci" & ChrW$(243) & "n.", Array("Tipo (""Normal"", ""Triangular"", ...)", "Valor x", "Par" & ChrW$(225) & "metro 1", "Par" & ChrW$(225) & "metro 2", "Par" & ChrW$(225) & "metro 3", "Par" & ChrW$(225) & "metro 4")
    Reg "SRCuantil", "Cuantil te" & ChrW$(243) & "rico (inversa de la FDA) de una distribuci" & ChrW$(243) & "n.", Array("Tipo", "Probabilidad entre 0 y 1", "Par" & ChrW$(225) & "metro 1", "Par" & ChrW$(225) & "metro 2", "Par" & ChrW$(225) & "metro 3", "Par" & ChrW$(225) & "metro 4")
    Reg "SRMomento", "Momento te" & ChrW$(243) & "rico: 1 media, 2 desviaci" & ChrW$(243) & "n, 3 asimetr" & ChrW$(237) & "a, 4 curtosis.", Array("Tipo", "Cu" & ChrW$(225) & "l (1 a 4)", "Par" & ChrW$(225) & "metro 1", "Par" & ChrW$(225) & "metro 2", "Par" & ChrW$(225) & "metro 3", "Par" & ChrW$(225) & "metro 4")
    Reg "SRSalida", "Marca una celda como salida de la simulaci" & ChrW$(243) & "n y devuelve el valor.", Array("Valor o f" & ChrW$(243) & "rmula de la salida", "Nombre opcional de la salida", "Grupo opcional (para gr" & ChrW$(225) & "ficos de tendencia)")
    Reg "SRSimTabla", "Devuelve el valor k en la simulaci" & ChrW$(243) & "n k (escenarios con varias simulaciones).", Array("Valores por simulaci" & ChrW$(243) & "n")
    Reg "SRMedia", "Media simulada de una salida o entrada.", Array("Celda de la salida o entrada", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRDesvEst", "Desviaci" & ChrW$(243) & "n est" & ChrW$(225) & "ndar simulada.", Array("Celda de la salida o entrada", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRMinimo", "M" & ChrW$(237) & "nimo simulado.", Array("Celda de la salida o entrada", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRMaximo", "M" & ChrW$(225) & "ximo simulado.", Array("Celda de la salida o entrada", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRMediana", "Mediana simulada.", Array("Celda de la salida o entrada", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRPercentil", "Valor del percentil p de los resultados simulados.", Array("Celda de la salida o entrada", "Probabilidad entre 0 y 1", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRObjetivo", "Probabilidad de que la variable sea menor o igual que un valor.", Array("Celda de la salida o entrada", "Valor objetivo", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
    Reg "SRProbEntre", "Probabilidad de que la variable est" & ChrW$(233) & " entre dos valores.", Array("Celda de la salida o entrada", "Desde", "Hasta", "N" & ChrW$(250) & "mero de simulaci" & ChrW$(243) & "n (por defecto 1)")
End Sub

Private Sub Reg(ByVal macro As String, ByVal desc As String, ByVal args As Variant)
    On Error Resume Next
    Application.MacroOptions Macro:=macro, Description:=desc, Category:=SR_APP, ArgumentDescriptions:=args
End Sub
