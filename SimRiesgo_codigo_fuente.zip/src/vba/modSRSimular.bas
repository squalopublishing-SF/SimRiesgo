Attribute VB_Name = "modSRSimular"
Option Explicit

' ============================================================
'  SIMULACION
' ============================================================
' Nucleo de simulacion: asume el modelo ya registrado (RegistrarModelo + LeerCorrelaciones).
' Devuelve 0 = completada, 1 = detenida por el usuario (con resultados parciales), 2 = error.
Public Function CorrerSimulacion(ByVal nIt As Long, ByVal nSim As Long, ByVal lhs As Boolean, ByVal seed As Double, _
                                 ByVal usarConv As Boolean, ByVal tol As Double, ByVal silencioso As Boolean, _
                                 ByRef msgError As String) As Long
    Dim s As Long, i As Long, o As Long, v As Variant, nUsar As Long, conv As Boolean
    Dim sumV() As Double, sumQ() As Double, cnt() As Long

    If gInCount > 0 Then
        ReDim gInVals(1 To nSim, 1 To gInCount, 1 To nIt)
    Else
        ReDim gInVals(1 To nSim, 1 To 1, 1 To nIt)
    End If
    ReDim gOutVals(1 To nSim, 1 To gOutCount, 1 To nIt)
    ReDim gOutErr(1 To nSim, 1 To gOutCount, 1 To nIt)
    RngSeed seed
    gItersDone = 0
    gSimsDone = 0
    gConvAlcanzada = False
    nUsar = nIt

    Application.EnableCancelKey = xlErrorHandler
    On Error GoTo EH

    For s = 1 To nSim
        gSim = s
        GenerarU nUsar, lhs
        AplicarCorrelaciones nUsar
        If usarConv And s = 1 Then
            ReDim sumV(1 To gOutCount)
            ReDim sumQ(1 To gOutCount)
            ReDim cnt(1 To gOutCount)
        End If
        gMode = 2
        For i = 1 To nUsar
            gIter = i
            gPass = gPass + 1
            Application.Calculate
            For o = 1 To gOutCount
                v = gOutRng(o).Value2
                Select Case VarType(v)
                    Case vbDouble, vbInteger, vbLong, vbSingle, vbCurrency, vbDecimal, vbByte
                        gOutVals(s, o, i) = CDbl(v)
                    Case vbBoolean
                        gOutVals(s, o, i) = IIf(v, 1#, 0#)
                    Case Else
                        gOutErr(s, o, i) = 1
                End Select
                If usarConv And s = 1 Then
                    If gOutErr(s, o, i) = 0 Then
                        sumV(o) = sumV(o) + gOutVals(s, o, i)
                        sumQ(o) = sumQ(o) + gOutVals(s, o, i) ^ 2
                        cnt(o) = cnt(o) + 1
                    End If
                End If
            Next o
            If (i Mod 25) = 0 Then
                If Not silencioso Then
                    Application.StatusBar = SR_APP & ": simulaci" & ChrW$(243) & "n " & s & " de " & nSim & _
                        "  -  iteraci" & ChrW$(243) & "n " & i & " de " & nUsar & "   (Esc para detener)"
                End If
                DoEvents
            End If
            If usarConv And s = 1 And i >= 200 And (i Mod 100) = 0 Then
                conv = True
                For o = 1 To gOutCount
                    If Not Convergio(sumV(o), sumQ(o), cnt(o), tol) Then
                        conv = False
                        Exit For
                    End If
                Next o
                If conv Then
                    gConvAlcanzada = True
                    nUsar = i
                    Exit For
                End If
            End If
        Next i
        gMode = 0
        gSimsDone = s
    Next s
    gItersDone = nUsar
    Application.EnableCancelKey = xlInterrupt
    CorrerSimulacion = 0
    Exit Function

EH:
    gMode = 0
    If Err.Number = 18 Then
        If silencioso Then
            gCancel = True
            gSimsDone = 0
            Application.EnableCancelKey = xlInterrupt
            CorrerSimulacion = 1
            Exit Function
        End If
        If MsgBox("Desea detener la simulaci" & ChrW$(243) & "n?", vbYesNo + vbQuestion, SR_APP) = vbYes Then
            If s <= 1 Then
                gSimsDone = 1
                gItersDone = i - 1
            Else
                gSimsDone = s - 1
                gItersDone = nUsar
            End If
            Application.EnableCancelKey = xlInterrupt
            CorrerSimulacion = 1
            Exit Function
        Else
            gMode = 2
            Resume
        End If
    Else
        msgError = "Simulaci" & ChrW$(243) & "n " & s & ", iteraci" & ChrW$(243) & "n " & i & ": " & Err.Description
        Application.EnableCancelKey = xlInterrupt
        CorrerSimulacion = 2
    End If
End Function

' Criterio de convergencia (95 %): media y desviacion estimadas con error relativo <= tol
Public Function Convergio(ByVal sv As Double, ByVal sq As Double, ByVal n As Long, ByVal tol As Double) As Boolean
    Dim m As Double, sd As Double, ref As Double
    If n < 30 Then Exit Function
    m = sv / n
    sd = (sq - n * m * m) / (n - 1)
    If sd <= 0 Then
        Convergio = True
        Exit Function
    End If
    sd = Sqr(sd)
    ref = Abs(m)
    If ref < sd Then ref = sd
    If 1.96 * sd / Sqr(n) > tol * ref Then Exit Function
    If 1.96 / Sqr(2# * n) > tol Then Exit Function
    Convergio = True
End Function

Public Sub SR_Simular()
    Dim nIt As Long, nSim As Long, lhs As Boolean, seed As Double, usarConv As Boolean, tol As Double
    Dim calcMode As Long, t0 As Double, wb As Workbook, res As Long, msg As String
    Dim celdas As Double, abrir As Boolean

    If SimulacionEnCurso() Then Exit Sub
    If ActiveWorkbook Is Nothing Then
        MsgBox "Abra un libro con un modelo antes de simular.", vbExclamation, SR_APP
        Exit Sub
    End If
    MarcarEjecucion True
    Set wb = ActiveWorkbook
    gHasResults = False
    OlvidarFallidos

    nIt = CfgIter()
    nSim = CfgSims()
    lhs = (CfgSampling() = 0)
    seed = CfgSeed()
    usarConv = CfgConv()
    tol = CfgTol()

    calcMode = Application.Calculation
    Application.Calculation = xlCalculationManual
    Application.StatusBar = SR_APP & ": identificando entradas y salidas del modelo..."

    If Not RegistrarModelo() Then
        MsgBox "No se pudo recalcular el modelo para identificar entradas y salidas.", vbCritical, SR_APP
        GoTo restaurar
    End If

    If gOutCount = 0 Then
        MsgBox "El modelo no tiene salidas definidas." & vbCrLf & vbCrLf & _
               "Seleccione la celda de resultado y use el bot" & ChrW$(243) & "n 'Agregar salida' " & _
               "(o escriba =SRSalida(formula)).", vbExclamation, SR_APP
        GoTo restaurar
    End If

    celdas = CDbl(nSim) * (gInCount + gOutCount) * nIt
    If celdas > 40000000# Then
        MsgBox "La simulaci" & ChrW$(243) & "n pedida es demasiado grande para la memoria disponible " & _
               "(" & Format(celdas, "#,##0") & " valores). Reduzca iteraciones o simulaciones.", vbExclamation, SR_APP
        GoTo restaurar
    End If

    gAvisos = ""
    LeerCorrelaciones wb

    If seed <= 0 Then
        Randomize
        seed = Int(Rnd() * 2000000000#) + 1
    End If
    gSeedUsed = seed
    gConvUsada = usarConv
    gConvTol = tol

    t0 = Timer
    Application.ScreenUpdating = False
    res = CorrerSimulacion(nIt, nSim, lhs, seed, usarConv, tol, False, msg)
    If res = 2 Then
        MsgBox "Error durante la simulaci" & ChrW$(243) & "n (" & msg & ")", vbCritical, SR_APP
        gHasResults = False
        GoTo restaurar
    End If

    If usarConv And Not gConvAlcanzada And res = 0 Then
        gAvisos = gAvisos & "No se alcanz" & ChrW$(243) & " la convergencia (tolerancia " & Format(tol * 100, "0.0") & _
                  " %) en " & Format(nIt, "#,##0") & " iteraciones; aumente el n" & ChrW$(250) & "mero m" & ChrW$(225) & _
                  "ximo de iteraciones." & vbCrLf
    End If
    On Error Resume Next
    gElapsed = Timer - t0
    If gElapsed < 0 Then gElapsed = gElapsed + 86400
    gSampling = IIf(lhs, "Hipercubo latino", "Monte Carlo")
    gModelName = wb.Name
    gSimDate = Now
    gHasResults = (gItersDone >= 2 And gSimsDone >= 1)
    If gHasResults Then
        TomarFoto
        If CfgGuardar() Then
            Application.StatusBar = SR_APP & ": guardando resultados en el libro..."
            GuardarResultados wb
        End If
    End If
    abrir = gHasResults
    gLastViewer = ""

restaurar:
    On Error Resume Next
    gMode = 0
    MarcarEjecucion False
    Application.EnableCancelKey = xlInterrupt
    Application.StatusBar = SR_APP & ": actualizando el libro..."
    Application.ScreenUpdating = True
    Application.CalculateFull
    Application.Calculation = calcMode
    Application.StatusBar = False
    If abrir Then
        If Len(gAvisos) > 0 Then MsgBox gAvisos, vbInformation, SR_APP
        SR_AbrirVisor True
    End If
End Sub

