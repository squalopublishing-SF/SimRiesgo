"""Comprobaciones estaticas sencillas del codigo VBA (Option Explicit, duplicados)."""
import re, os, sys, glob
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "vba")
BUILTIN = set("""
and or not xor mod is like to step then else elseif end if for next each in do loop while wend until select case with
dim redim preserve as long integer double string boolean variant object byte date currency single
function sub property get let set call exit goto resume on error public private const option explicit byval byref optional paramarray
true false nothing empty null new me attribute vb_name withevents type enum friend static debug print
application selection activecell activeworkbook activesheet thisworkbook workbooks worksheets sheets range cells rows columns
worksheetfunction msgbox inputbox format format$ left left$ right right$ mid mid$ len trim trim$ ucase ucase$ lcase lcase$ replace instr instrrev
split join val cstr cdbl clng cint cbool cdate cvar int fix abs sqr exp log sin cos tan atn sgn rnd randomize timer now date time
isnumeric isempty isarray ismissing isobject isnull iserror typename vartype ubound lbound array erase chrw chrw$ chr chr$ asc ascw space string$
strcomp strptr cverr iif choose doevents createobject getsetting savesetting dir dir$ environ environ$ round filelen kill mkdir
vbcrlf vblf vbcr vbtab vbnullstring vbtextcompare vbbinarycompare vbinformation vbexclamation vbcritical vbquestion vbyesno vbyes vbno vbokonly
vbdouble vbinteger vblong vbsingle vbcurrency vbdecimal vbbyte vbboolean vbstring vbwhite vbempty
rgb err number description clear raise
xlcalculationmanual xlcalculationautomatic xlerrna xlerrnum xlerrvalue xlerrdiv0 xlinterrupt xlerrorhandler xlleft xlcenter xlright
xlcontinuous xlnone xlsheetvisible xlsheetveryhidden xlsheethidden xlvalidatelist xlvalidatedecimal xlvalidalertstop xlbetween
xlwbatworksheet xlcolumnstacked xlcolumnclustered xlline xlxyscatter xlxyscatterlinesnomarkers xlmarkerstylecircle xlvalue xlcategory
xllegendpositiontop xllegendpositionbottom xledgebottom xlinsidehorizontal xlup xldown xltoleft xltoright xla1 xldialogfunctionwizard xllandscape xltypepdf xlqualitystandard xldecimalseparator
xlbarclustered xlpatternnone
msofalse msotrue msoaligncenter msoanchormiddle msolinedash msoshaperectangle
""".split())
MEMBER_AFTER_DOT = re.compile(r"\.\s*([A-Za-z_]\w*)")

def strip(line):
    out, q = [], False
    i = 0
    while i < len(line):
        c = line[i]
        if c == '"':
            q = not q; out.append(" "); i += 1; continue
        if not q and c == "'":
            break
        out.append(" " if q else c); i += 1
    return "".join(out)

files = sorted(glob.glob(os.path.join(SRC, "*.bas")) + glob.glob(os.path.join(SRC, "*.cls")))
globals_, procs = set(), []
mod_level = {}
for f in files:
    lines = [strip(l) for l in open(f, encoding="utf-8").read().split("\n")]
    # unir continuaciones
    joined = []
    buf = ""
    for l in lines:
        if l.rstrip().endswith(" _"):
            buf += l.rstrip()[:-1] + " "
        else:
            joined.append(buf + l); buf = ""
    mod = os.path.basename(f)
    mod_level[mod] = set()
    cur = None
    for l in joined:
        s = l.strip()
        m = re.match(r"(?i)(public |private |friend )?(static )?(function|sub|property (get|let|set)) (\w+)\s*\((.*)\)", s)
        if m:
            name = m.group(5).lower()
            if (m.group(1) or "").lower().strip() != "private":
                globals_.add(name)
            mod_level[mod].add(name)
            params = set()
            for p in m.group(6).split(","):
                p = re.sub(r"(?i)\b(optional|byval|byref|paramarray)\b", "", p).strip()
                pm = re.match(r"(\w+)", p)
                if pm: params.add(pm.group(1).lower())
            cur = {"mod": mod, "name": name, "decl": set(params) | {name}, "lines": [], "dims": []}
            procs.append(cur)
            continue
        if re.match(r"(?i)end (function|sub|property)\b", s):
            cur = None; continue
        if cur is None:
            m = re.match(r"(?i)(public|private|dim|global)\s+(const\s+|withevents\s+)?(.*)", s)
            if m and not re.match(r"(?i)(public|private)\s+(declare|type|enum)", s):
                for part in re.split(r",(?![^()]*\))", m.group(3)):
                    pm = re.match(r"\s*(\w+)", part)
                    if pm:
                        n = pm.group(1).lower()
                        mod_level[mod].add(n)
                        if m.group(1).lower() in ("public", "global"):
                            globals_.add(n)
            continue
        cur["lines"].append(l)
        for m in re.finditer(r"(?i)\b(dim|redim(?:\s+preserve)?|const|static)\s+(.*)", s):
            if m.group(1).lower().startswith("redim"):
                continue
            body = m.group(2)
            for part in re.split(r",(?![^()]*\))", body):
                pm = re.match(r"\s*(\w+)", part)
                if pm:
                    n = pm.group(1).lower()
                    if n in cur["decl"] and m.group(1).lower() != "redim":
                        print("DUPLICADO", cur["mod"], cur["name"], n)
                    cur["decl"].add(n)
        for lab in re.findall(r"(?m)^\s*(\w+):\s*$", l):
            cur["decl"].add(lab.lower())
        for lab in re.findall(r"^\s*(\w+):", l):
            cur["decl"].add(lab.lower())

problems = 0
for p in procs:
    known = BUILTIN | globals_ | mod_level[p["mod"]] | p["decl"]
    for l in p["lines"]:
        t = re.sub(r"\.\s*[A-Za-z_]\w*", " ", l)          # miembros
        t = re.sub(r"\b\w+:=", " ", t)                     # argumentos con nombre
        t = re.sub(r"(?i)\bgoto\s+\w+|\bresume\s+\w+|\bon error goto\s+\w+", " ", t)
        t = re.sub(r"&H[0-9A-Fa-f]+|\b\d+(\.\d*)?(E[+-]?\d+)?#?", " ", t)
        for w in re.findall(r"\b[A-Za-z_]\w*\$?", t):
            lw = w.lower()
            if lw not in known and lw.rstrip("$") not in known:
                print("NO DECLARADO", p["mod"], p["name"], w, "|", l.strip()[:90])
                problems += 1
print("problemas:", problems)
