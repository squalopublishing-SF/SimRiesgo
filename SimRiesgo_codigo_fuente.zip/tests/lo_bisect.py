import os, sys, shutil, subprocess, time, zipfile, tempfile, uno
from com.sun.star.beans import PropertyValue
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
import build
mods = sys.argv[1].split(",")
work = tempfile.mkdtemp(prefix="srlo_")
src = os.path.join(work, "vba"); os.makedirs(src)
for f in ["ThisWorkbook.cls", "Sheet1.cls"]: shutil.copy(os.path.join(build.SRC_VBA, f), src)
# LibreOffice no carga modulos de documento con WithEvents Application: se prueba sin eventos
_tw = open(os.path.join(src, "ThisWorkbook.cls")).read()
_i = _tw.index("Private WithEvents App"); _j = _tw.index("Private Sub Workbook_Open()")
open(os.path.join(src, "ThisWorkbook.cls"), "w").write(_tw[:_i] + "Public Sub ArmarEventos()\nEnd Sub\n\n" + _tw[_j:].replace("    ArmarEventos\n", ""))
import re
DICTS = r"\b(gInIdx|gOutIdx|rInIdx|rOutIdx|gNames|gCellIdx|gEmpCache|gFallidos|cache)\("
for m in mods:
    p = os.path.join(build.SRC_VBA, m + ".bas")
    if not os.path.exists(p): p = os.path.join(ROOT, "tests", m + ".bas")
    if not os.path.exists(p): p = os.path.join(ROOT, "tests", m + ".cls")
    dst = os.path.join(src, os.path.basename(p))
    t = open(p, encoding="utf-8").read()
    if os.environ.get("SR_DICT") and p.endswith(".bas"):
        # LibreOffice no ofrece Scripting.Dictionary: se usa la clase de prueba SRDict
        t = t.replace('CreateObject("Scripting.Dictionary")', "New SRDict")
        t = re.sub(DICTS, lambda mm: mm.group(1) + ".Item(", t)
    open(dst, "w", encoding="utf-8").write(t)
build.SRC_VBA = src
out = os.path.join(work, "t.xlsm")
vba = build.build_vba(work); base = os.path.join(work, "b.xlsx"); build.build_base_xlsx(base); build.assemble(base, vba, out)
z = zipfile.ZipFile(out); files = {n: z.read(n) for n in z.namelist()}; z.close()
files["[Content_Types].xml"] = files["[Content_Types].xml"].replace(b"addin.macroEnabled.main", b"sheet.macroEnabled.main")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zz:
    for n, d in files.items(): zz.writestr(n, d)
env = dict(os.environ, HOME=os.path.join(work, "home"))
port = 2100 + os.getpid() % 500
proc = subprocess.Popen(["soffice", "--headless", "--norestore", '--accept=socket,host=localhost,port=%d;urp;' % port], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
local = uno.getComponentContext()
res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
for _ in range(60):
    try: ctx = res.resolve("uno:socket,host=localhost,port=%d;urp;StarOffice.ComponentContext" % port); break
    except Exception: time.sleep(1)
desk = ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
def pv(n, v): p = PropertyValue(); p.Name = n; p.Value = v; return p
doc = desk.loadComponentFromURL(uno.systemPathToFileUrl(out), "_blank", 0, (pv("Hidden", True), pv("MacroExecutionMode", 4)))
sp = doc.getScriptProvider()
if os.environ.get("SR_MODEL"):
    sh = doc.Sheets.getByIndex(0)
    for i, (lab, f) in enumerate([("Costo A", "=SRNORMAL(100;10)"), ("Costo B", "=SRPERT(10;20;40)"), ("Evento", "=SRBERNOULLI(0,25)*50"),
                                  ("Doble", "=SRUNIFORME(0;1)+SRUNIFORME(10;11)"), ("Total", "=SRSALIDA(D1+D2+D3+D4)"), ("Ratio", "=SRSALIDA(D1/D2;\"Razon A/B\")")]):
        sh.getCellByPosition(2, i).setString(lab)
        sh.getCellByPosition(3, i).setFormula(f.replace("0,25", "0.25"))
    doc.calculateAll()
    print("cells:", [sh.getCellByPosition(3, i).getString() for i in range(6)])
for fn in sys.argv[2].split(","):
    try:
        r = sp.getScript("vnd.sun.star.script:VBAProject.%s?language=Basic&location=document" % fn).invoke((), (), ())
        print(fn, "=>", repr(r[0])[:4000])
    except Exception as e: print(fn, "ERR", str(e)[:500])
doc.close(True); proc.terminate()
