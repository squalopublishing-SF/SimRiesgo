Attribute VB_Name = "modTest"
Option Explicit

Public Function T_Rng() As String
    Dim i As Long, x As Double, s As Double, s2 As Double, mn As Double, mx As Double, n As Long
    RngSeed 12345
    n = 200000
    mn = 1: mx = 0
    For i = 1 To n
        x = RngNext()
        s = s + x
        s2 = s2 + x * x
        If x < mn Then mn = x
        If x > mx Then mx = x
    Next i
    T_Rng = "mean=" & NumJ(s / n) & ";var=" & NumJ(s2 / n - (s / n) ^ 2) & ";min=" & NumJ(mn) & ";max=" & NumJ(mx)
    RngSeed 12345
    T_Rng = T_Rng & ";first=" & NumJ(RngNext()) & "," & NumJ(RngNext())
End Function

Public Function T_Norm() As String
    T_Norm = NumJ(NormSInv(0.975)) & ";" & NumJ(NormSInv(0.5)) & ";" & NumJ(NormSInv(0.001)) & ";" & NumJ(NormSInv(0.9999))
End Function

Public Function T_Sort() As String
    Dim a() As Double, i As Long, ok As Boolean, r() As Double, v(1 To 6) As Double
    ReDim a(1 To 5000)
    RngSeed 7
    For i = 1 To 5000
        a(i) = Int(RngNext() * 100)
    Next i
    OrdenarD a, 1, 5000
    ok = True
    For i = 2 To 5000
        If a(i) < a(i - 1) Then ok = False
    Next i
    v(1) = 3: v(2) = 1: v(3) = 3: v(4) = 2: v(5) = 3: v(6) = 0
    Rangos v, 6, r
    T_Sort = "sorted=" & ok & ";ranks=" & r(1) & "," & r(2) & "," & r(3) & "," & r(4) & "," & r(5) & "," & r(6) & _
             ";p50=" & PercentilOrdenado(a, 5000, 0.5) & ";p5=" & PercentilOrdenado(a, 5000, 0.05)
End Function

Public Function T_Json() As String
    T_Json = JsonStr("A" & ChrW$(241) & "o <x> ""q"" \ ok") & "|" & NumJ(0.5) & "|" & NumJ(-0.25) & "|" & NumJ(0.0000001) & "|" & NumJ(123456789.125) & "|" & NumJ(-3)
End Function

Public Function T_Hello() As String
    T_Hello = "hi"
End Function

Public Function T_Hello2()
    T_Hello2 = 1 + 2
End Function

Public Function T_Inv2() As String
    Dim p(1 To 4) As Double, r As String
    On Error GoTo h
    p(1) = 100: p(2) = 10
    r = "N:" & NumJ(InvCdf(1, 0.9, p))
    p(1) = 10: p(2) = 20: p(3) = 40
    r = r & "|T:" & NumJ(InvCdf(2, 0.9, p))
    r = r & "|P:" & NumJ(InvCdf(3, 0.9, p)) & " E=" & NumJ(ValorEsperado(3, p))
    p(1) = 100: p(2) = 20
    r = r & "|LN:" & NumJ(InvCdf(5, 0.9, p))
    p(1) = 2: p(2) = 50
    r = r & "|W:" & NumJ(InvCdf(6, 0.9, p)) & " E=" & NumJ(ValorEsperado(6, p))
    p(1) = 8
    r = r & "|EXP:" & NumJ(InvCdf(7, 0.9, p))
    p(1) = 2: p(2) = 3
    r = r & "|G:" & NumJ(InvCdf(8, 0.9, p))
    p(1) = 2: p(2) = 5: p(3) = 0: p(4) = 10
    r = r & "|B:" & NumJ(InvCdf(9, 0.9, p))
    p(1) = 4
    r = r & "|POI:" & NumJ(InvCdf(10, 0.9, p))
    p(1) = 10: p(2) = 0.3
    r = r & "|BIN:" & NumJ(InvCdf(11, 0.9, p))
    p(1) = 0.25
    r = r & "|BER:" & NumJ(InvCdf(12, 0.9, p)) & "," & NumJ(InvCdf(12, 0.5, p))
    T_Inv2 = r
    Exit Function
h:
    T_Inv2 = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Inv3() As String
    Dim p(1 To 4) As Double
    p(1) = 100: p(2) = 10
    T_Inv3 = "N:" & NumJ(InvCdf(1, 0.9, p))
End Function

Public Function T_Inv4() As String
    Dim p() As Double
    ReDim p(1 To 4)
    p(1) = 100: p(2) = 10
    T_Inv4 = "N:" & NumJ(InvCdf(1, 0.9, p))
End Function

Public Function T_Inv5() As String
    T_Inv5 = "N:" & NumJ(NormSInv(0.9))
End Function

Public Function T_Sim() As String
    Dim r As String, s As Long, i As Long, o As Long, nIt As Long, v As Variant, m As Double, j As Long
    On Error GoTo h
    nIt = 400
    r = "reg=" & RegistrarModelo()
    r = r & ";in=" & gInCount & ";out=" & gOutCount
    For j = 1 To gInCount
        r = r & ";IN" & j & "=" & gInName(j) & "@" & gInCell(j) & "~" & gInDist(j)
    Next j
    For j = 1 To gOutCount
        r = r & ";OUT" & j & "=" & gOutName(j) & "@" & gOutCell(j) & "g=" & gOutGroup(j)
    Next j
    ReDim gInVals(1 To 1, 1 To gInCount, 1 To nIt)
    ReDim gOutVals(1 To 1, 1 To gOutCount, 1 To nIt)
    ReDim gOutErr(1 To 1, 1 To gOutCount, 1 To nIt)
    RngSeed 99
    gSim = 1
    GenerarU nIt, True
    gMode = 2
    For i = 1 To nIt
        gIter = i
        gPass = gPass + 1
        Application.Calculate
        For o = 1 To gOutCount
            v = gOutRng(o).Value2
            If VarType(v) = vbDouble Then gOutVals(1, o, i) = v Else gOutErr(1, o, i) = 1
        Next o
    Next i
    gMode = 0
    gItersDone = nIt: gSimsDone = 1: gHasResults = True
    For o = 1 To gOutCount
        m = 0
        For i = 1 To nIt
            m = m + gOutVals(1, o, i)
        Next i
        r = r & ";MEAN" & o & "=" & NumJ(m / nIt) & ";first=" & NumJ(gOutVals(1, o, 1)) & "," & NumJ(gOutVals(1, o, 2))
    Next o
    For j = 1 To gInCount
        m = 0
        For i = 1 To nIt
            m = m + gInVals(1, j, i)
        Next i
        r = r & ";INMEAN" & j & "=" & NumJ(m / nIt)
    Next j
    T_Sim = r
    Exit Function
h:
    gMode = 0
    T_Sim = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Out() As String
    Dim v As Variant
    On Error GoTo h
    v = SRSalida(5)
    T_Out = "a=" & v
    v = SRSalida(7, "x", "g")
    T_Out = T_Out & ";b=" & v
    T_Out = T_Out & ";c=" & SRSimTabla(1, 2, 3)
    Exit Function
h:
    T_Out = T_Out & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function F1(Valor As Variant) As Variant
    F1 = Valor
End Function

Public Function F2(Valor As Variant, Optional Nombre As Variant) As Variant
    Dim c As Range
    If gMode = 1 Then
        If CallerCell(c) Then F2 = 0
    End If
    F2 = Valor
End Function

Public Function F3(Valor As Variant) As Variant
    If IsObject(Valor) Then
        F3 = Valor.Cells(1, 1).Value
    Else
        F3 = Valor
    End If
End Function

Public Function T_F() As String
    On Error GoTo h
    T_F = "f1=" & F1(5)
    T_F = T_F & ";f2=" & F2(6)
    T_F = T_F & ";f3=" & F3(7)
    Exit Function
h:
    T_F = T_F & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function F4(Valor As Variant) As Variant
    If TypeName(Valor) = "Range" Then
        F4 = 1
    Else
        F4 = Valor
    End If
End Function

Public Function T_G() As String
    On Error GoTo h
    T_G = "tn=" & TypeName(5)
    T_G = T_G & ";f4=" & F4(7)
    T_G = T_G & ";s=" & SRSalida(8)
    Exit Function
h:
    T_G = T_G & " ERROR " & Err.Number & " " & Err.Description & " gmode=" & gMode
End Function

Public Function F5(Valor As Variant, Optional Nombre As Variant, Optional Grupo As Variant) As Variant
    Dim c As Range
    If gMode = 1 Then
        If CallerCell(c) Then RegisterOutput c, Nombre, Grupo
    End If
    If TypeName(Valor) = "Range" Then
        F5 = Valor.Cells(1, 1).Value
    Else
        F5 = Valor
    End If
End Function

Public Function F6(Valor As Variant, Optional Nombre As Variant, Optional Grupo As Variant) As Variant
    If TypeName(Valor) = "Range" Then
        F6 = Valor.Cells(1, 1).Value
    Else
        F6 = Valor
    End If
End Function

Public Function F7(Valor As Variant) As Variant
    If TypeName(Valor) = "Range" Then
        F7 = Valor.Cells(1, 1).Value
    Else
        F7 = Valor
    End If
End Function

Public Function T_H() As String
    On Error Resume Next
    T_H = "f7=" & F7(1): If Err.Number Then T_H = T_H & "E" & Err.Number: Err.Clear
    T_H = T_H & ";f6=" & F6(2): If Err.Number Then T_H = T_H & "E" & Err.Number: Err.Clear
    T_H = T_H & ";f5=" & F5(3): If Err.Number Then T_H = T_H & "E" & Err.Number: Err.Clear
End Function

Public Function F8(Valor As Variant) As Variant
    Dim rg As Object
    If TypeName(Valor) = "Range" Then
        Set rg = Valor
        F8 = rg.Cells(1, 1).Value
    Else
        F8 = Valor
    End If
End Function

Public Function T_I() As String
    On Error Resume Next
    T_I = "f8=" & F8(1): If Err.Number Then T_I = T_I & "E" & Err.Number & Err.Description: Err.Clear
End Function

Public Function T_C() As String
    On Error Resume Next
    ResetRegistry: If Err.Number Then T_C = T_C & "reset E" & Err.Number & " " & Err.Description & ";": Err.Clear
    Application.CalculateFull: If Err.Number Then T_C = T_C & "full E" & Err.Number & ";": Err.Clear
    Application.Calculate: If Err.Number Then T_C = T_C & "calc E" & Err.Number & ";": Err.Clear
    T_C = T_C & "done"
End Function

Public Function T_C2() As String
    Dim c As Range
    On Error Resume Next
    ResetRegistry
    gMode = 1
    gPass = gPass + 1
    Application.Calculate: If Err.Number Then T_C2 = T_C2 & "calc E" & Err.Number & " " & Err.Description & ";": Err.Clear
    gMode = 0
    T_C2 = T_C2 & "in=" & gInCount & ";out=" & gOutCount
    T_C2 = T_C2 & ";caller=" & CallerCell(c)
End Function

Public Function T_LHS() As String
    Dim r As String, j As Long, i As Long
    RngSeed 2026
    gInCount = 2
    GenerarU 10, True
    For j = 1 To 2
        For i = 1 To 10
            r = r & NumJ(gU(j, i)) & ","
        Next i
        r = r & "|"
    Next j
    RngSeed 2026
    GenerarU 5, False
    For i = 1 To 5
        r = r & NumJ(gU(1, i)) & ","
    Next i
    gInCount = 0
    T_LHS = r
End Function

Public Function T_New() As String
    Dim r As String
    On Error GoTo h
    r = "LL:" & NumJ(SRCuantil("LogLogistica", 0.9, 10, 3, 5))
    r = r & "|LLm:" & NumJ(SRMomento("LogLogistica", "media", 10, 3, 5)) & "|LLs:" & NumJ(SRMomento("LogLogistica", "desv", 10, 3, 5))
    r = r & "|LLd:" & NumJ(SRDensidad("LogLogistica", 14, 10, 3, 5))
    r = r & "|P5:" & NumJ(SRCuantil("Pearson V", 0.9, 4, 30, 0)) & "|P5m:" & NumJ(SRMomento("PearsonV", "media", 4, 30)) & "|P5s:" & NumJ(SRMomento("PearsonV", "desv", 4, 30))
    r = r & "|P5d:" & NumJ(SRDensidad("Pearson V", 8, 4, 30))
    r = r & "|NT:" & NumJ(SRCuantil("Normal truncada", 0.9, 100, 20, 90, 150)) & "|NTm:" & NumJ(SRMomento("Normal truncada", "media", 100, 20, 90, 150)) & "|NTs:" & NumJ(SRMomento("Normal truncada", "desv", 100, 20, 90, 150))
    r = r & "|NTd:" & NumJ(SRDensidad("Normal truncada", 110, 100, 20, 90, 150))
    r = r & "|PERTd:" & NumJ(SRDensidad("PERT", 25, 10, 20, 40)) & "|PERTs:" & NumJ(SRMomento("PERT", "desv", 10, 20, 40))
    r = r & "|Wd:" & NumJ(SRDensidad("Weibull", 30, 2, 50)) & "|Ws:" & NumJ(SRMomento("Weibull", "desv", 2, 50))
    r = r & "|Gd:" & NumJ(SRDensidad("Gamma", 5, 2, 3)) & "|LNd:" & NumJ(SRDensidad("Lognormal", 90, 100, 20))
    r = r & "|Bd:" & NumJ(SRDensidad("Beta", 3, 2, 5, 0, 10)) & "|POd:" & NumJ(SRDensidad("Poisson", 3, 4)) & "|BId:" & NumJ(SRDensidad("Binomial", 4, 10, 0.3))
    r = r & "|Td:" & NumJ(SRDensidad("Triangular", 15, 10, 20, 40)) & "|Ts:" & NumJ(SRMomento("Triangular", "desv", 10, 20, 40))
    T_New = r
    Exit Function
h:
    T_New = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Private Function Spear(ByVal a As Long, ByVal b As Long, ByVal n As Long) As Double
    Dim x() As Double, y() As Double, rx() As Double, ry() As Double, i As Long
    ReDim x(1 To n): ReDim y(1 To n)
    For i = 1 To n
        x(i) = gU(a, i): y(i) = gU(b, i)
    Next i
    Rangos x, n, rx
    Rangos y, n, ry
    Spear = Pearson(rx, ry, n)
End Function

Public Function T_Corr() As String
    Dim n As Long, idx() As Long, C() As Double, r As String, i As Long, s1() As Double, s2() As Double, ok As Boolean, fx As Boolean
    On Error GoTo h
    n = 2000
    ReDim idx(1 To 3): idx(1) = 1: idx(2) = 2: idx(3) = 3
    ReDim C(1 To 3, 1 To 3)
    C(1, 1) = 1: C(2, 2) = 1: C(3, 3) = 1
    C(1, 2) = 0.8: C(2, 1) = 0.8: C(1, 3) = -0.5: C(3, 1) = -0.5: C(2, 3) = -0.3: C(3, 2) = -0.3
    fx = GrupoPrueba(idx, C, 3)
    gInCount = 3
    RngSeed 2024
    GenerarU n, True
    ReDim s1(1 To n)
    For i = 1 To n: s1(i) = gU(2, i): Next i
    OrdenarD s1, 1, n
    AplicarCorrelaciones n
    ReDim s2(1 To n)
    For i = 1 To n: s2(i) = gU(2, i): Next i
    OrdenarD s2, 1, n
    ok = True
    For i = 1 To n
        If s1(i) <> s2(i) Then ok = False
    Next i
    r = "fixed=" & fx & ";marginal=" & ok & ";r12=" & NumJ(Round(Spear(1, 2, n), 4)) & ";r13=" & NumJ(Round(Spear(1, 3, n), 4)) & ";r23=" & NumJ(Round(Spear(2, 3, n), 4))
    ' matriz incoherente
    C(1, 2) = 0.9: C(2, 1) = 0.9: C(1, 3) = -0.9: C(3, 1) = -0.9: C(2, 3) = 0.9: C(3, 2) = 0.9
    fx = GrupoPrueba(idx, C, 3)
    RngSeed 2024
    GenerarU n, True
    AplicarCorrelaciones n
    r = r & "|fixed=" & fx & ";C12=" & NumJ(Round(C(1, 2), 4)) & ";C13=" & NumJ(Round(C(1, 3), 4)) & ";C23=" & NumJ(Round(C(2, 3), 4)) & _
        ";r12=" & NumJ(Round(Spear(1, 2, n), 4)) & ";r13=" & NumJ(Round(Spear(1, 3, n), 4)) & ";r23=" & NumJ(Round(Spear(2, 3, n), 4))
    T_Corr = r
    Exit Function
h:
    T_Corr = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Fit() As String
    Dim tipos As Variant, t As Variant, p(1 To 4) As Double, q() As Double, x() As Double, n As Long, i As Long
    Dim LL As Double, k As Long, r As String, j As Long, ks As Double
    On Error GoTo h
    n = 400
    tipos = Array(Array(1, 100, 15, 0, 0), Array(5, 50, 20, 0, 0), Array(8, 3, 4, 0, 0), Array(6, 2.5, 30, 0, 0), _
                  Array(7, 12, 0, 0, 0), Array(14, 20, 5, 0, 0), Array(15, 5, 40, 0, 0), Array(2, 10, 14, 30, 0), _
                  Array(3, 10, 14, 30, 0), Array(9, 2, 5, 10, 30), Array(16, 50, 10, 40, 70), Array(4, 3, 9, 0, 0), Array(10, 4, 0, 0, 0))
    For Each t In tipos
        For j = 1 To 4: p(j) = t(j): Next j
        If t(0) = 14 Or t(0) = 15 Then p(3) = 0
        ReDim x(1 To n)
        For i = 1 To n
            x(i) = InvCdf(CLng(t(0)), (i - 0.5) / n, p)
        Next i
        CargarDatosAjuste x
        If AjustarUna(CLng(t(0)), q, LL, k) Then
            ks = EstadisticoKS(CLng(t(0)), q)
            r = r & "|" & t(0) & ":" & NumJ(q(1)) & "," & NumJ(q(2)) & "," & NumJ(q(3)) & "," & NumJ(q(4)) & ";LL=" & NumJ(Round(LL, 6)) & ";KS=" & NumJ(Round(ks, 6))
        Else
            r = r & "|" & t(0) & ":NOFIT"
        End If
    Next t
    T_Fit = r
    Exit Function
h:
    T_Fit = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Cdf() As String
    Dim tipos As Variant, t As Variant, p(1 To 4) As Double, r As String, j As Long, x As Double, u As Variant
    On Error GoTo h
    tipos = Array(Array(1, 100, 15, 0, 0), Array(2, 10, 14, 30, 0), Array(3, 10, 14, 30, 0), Array(4, 3, 9, 0, 0), _
                  Array(5, 50, 20, 0, 0), Array(6, 2.5, 30, 0, 0), Array(7, 12, 0, 0, 0), Array(8, 3, 4, 0, 0), _
                  Array(9, 2, 5, 10, 30), Array(14, 20, 5, 3, 0), Array(15, 5, 40, 2, 0), Array(16, 50, 10, 40, 70))
    For Each t In tipos
        For j = 1 To 4: p(j) = t(j): Next j
        r = r & "|" & t(0) & ":"
        For Each u In Array(0.05, 0.5, 0.9)
            x = InvCdf(CLng(t(0)), CDbl(u), p)
            r = r & NumJ(Round(Cdf(CLng(t(0)), x, p) - u, 9)) & ","
        Next u
    Next t
    p(1) = 4
    r = r & "|POI:" & NumJ(Round(Cdf(10, 3, p), 9))
    T_Cdf = r
    Exit Function
h:
    T_Cdf = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Conv() As String
    Dim r As String, res As Long, msg As String
    On Error GoTo h
    r = "reg=" & RegistrarModelo() & ";in=" & gInCount & ";out=" & gOutCount
    res = CorrerSimulacion(50000, 1, True, 77, True, 0.03, True, msg)
    r = r & ";res=" & res & ";iters=" & gItersDone & ";conv=" & gConvAlcanzada & ";msg=" & msg
    res = CorrerSimulacion(300, 2, False, 77, False, 0.03, True, msg)
    r = r & "|res=" & res & ";iters=" & gItersDone & ";sims=" & gSimsDone
    T_Conv = r
    Exit Function
h:
    T_Conv = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_FitDbg() As String
    Dim p(1 To 4) As Double, x() As Double, n As Long, i As Long, r As String
    n = 400
    p(1) = 100: p(2) = 15
    ReDim x(1 To n)
    For i = 1 To n
        x(i) = InvCdf(1, (i - 0.5) / n, p)
    Next i
    r = "x1=" & NumJ(x(1)) & ";x200=" & NumJ(x(200))
    r = r & ";n=" & CargarDatosAjuste(x) & ";d1=" & NumJ(DatoAjuste(1)) & ";d400=" & NumJ(DatoAjuste(400)) & ";nd=" & NDatosAjuste()
    T_FitDbg = r
End Function

Public Function T_Step() As String
    Dim r As String
    On Error GoTo h
    r = "a"
    ResetRegistry
    r = r & "b"
    gMode = 1
    gPass = gPass + 1
    Application.Calculate
    r = r & "c" & gInCount
    gMode = 0
    r = r & ";reg=" & RegistrarModelo() & ";in=" & gInCount
    T_Step = r
    Exit Function
h:
    T_Step = r & " ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Dic() As String
    Dim d As Object
    On Error GoTo h
    Set d = CreateObject("Scripting.Dictionary")
    d.Add "a", 1
    T_Dic = "ok " & d.Count
    Exit Function
h:
    T_Dic = "ERROR " & Err.Number & " " & Err.Description
End Function

Public Function T_Mods() As String
    Dim r As String, p(1 To 4) As Double, v As Variant
    On Error GoTo h
    r = "vent=" & CatalogoIndice("Pearson V") & "," & CatalogoFuncion(14) & "," & UBound(EtiquetasParam(D_BETA))
    p(1) = 10: p(2) = 5: p(3) = 3
    r = r & ";valid=" & (ValidarParametros(D_TRIANG, p) <> "")
    r = r & ";opt=" & UBound(ListaEstadisticos())
    r = r & ";conv=" & Convergio(1000 * 50#, 1000 * (2500# + 1#), 1000, 0.05) & "," & Convergio(100 * 50#, 100 * (2500# + 400#), 100, 0.01)
    r = r & ";guard=" & LibroTieneResultados(ActiveWorkbook)
    r = r & ";cinta=" & NumJ(CfgTol()) & "," & CfgGuardar() & "," & CfgConv()
    r = r & ";sig=" & NumJ(Sig6(123.456789)) & "," & NumJ(Sig6(0.000123456789))
    T_Mods = r
    Exit Function
h:
    T_Mods = r & " ERROR " & Err.Number & " " & Err.Description
End Function
