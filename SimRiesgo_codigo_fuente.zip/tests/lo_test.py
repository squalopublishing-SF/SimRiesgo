"""Construye una variante .xlsm con un modulo de pruebas y ejecuta funciones VBA en LibreOffice (headless)."""
import os, sys, shutil, subprocess, time, zipfile, tempfile, uno
from com.sun.star.beans import PropertyValue

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
import build

work = tempfile.mkdtemp(prefix="srlo_")
src_copy = os.path.join(work, "vba")
shutil.copytree(build.SRC_VBA, src_copy)
shutil.copy(os.path.join(ROOT, "tests", "modTest.bas"), src_copy)
build.SRC_VBA = src_copy
out = os.path.join(work, "SimRiesgo_test.xlsm")
build.OUT = out
vba = build.build_vba(work)
base = os.path.join(work, "base.xlsx")
build.build_base_xlsx(base)
build.assemble(base, vba, out)
z = zipfile.ZipFile(out); files = {n: z.read(n) for n in z.namelist()}; z.close()
files["[Content_Types].xml"] = files["[Content_Types].xml"].replace(b"addin.macroEnabled.main", b"sheet.macroEnabled.main")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zz:
    for n, d in files.items(): zz.writestr(n, d)

env = dict(os.environ, HOME=os.path.join(work, "home"))
proc = subprocess.Popen(["soffice", "--headless", "--norestore", "--nologo",
                         '--accept=socket,host=localhost,port=2099;urp;'], env=env,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ctx = None
local = uno.getComponentContext()
resolver = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
for _ in range(60):
    try:
        ctx = resolver.resolve("uno:socket,host=localhost,port=2099;urp;StarOffice.ComponentContext"); break
    except Exception:
        time.sleep(1)
smgr = ctx.ServiceManager
desktop = smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
def pv(n, v):
    p = PropertyValue(); p.Name = n; p.Value = v; return p
doc = desktop.loadComponentFromURL(uno.systemPathToFileUrl(out), "_blank", 0,
                                   (pv("Hidden", True), pv("MacroExecutionMode", 4)))
sp = doc.getScriptProvider()
for fn in ["T_Hello", "T_Hello2", "T_Rng", "T_Norm", "T_Inv", "T_Sort", "T_Json"]:
    try:
        script = sp.getScript("vnd.sun.star.script:VBAProject.modTest.%s?language=Basic&location=document" % fn)
        res = script.invoke((), (), ())
        print(fn, "=>", res[0])
    except Exception as e:
        print(fn, "ERROR", e)
sh = doc.Sheets.getByIndex(0)
for i, fn in enumerate(["T_HELLO", "T_HELLO2", "T_RNG", "T_NORM", "T_INV", "T_SORT", "T_JSON"]):
    c = sh.getCellByPosition(3, i); c.setFormula("=" + fn + "()")
doc.calculateAll()
for i in range(7):
    c = sh.getCellByPosition(3, i); print("cell", c.getFormula(), "=>", c.getString()[:900])
# compilar todos los modulos
lib = doc.BasicLibraries.getByName("VBAProject")
print("modules:", lib.getElementNames())
print(repr(lib.getByName("modTest")[:400]))
print(repr(lib.getByName("modSRMotor")[:300]))
doc.close(True)
proc.terminate()
