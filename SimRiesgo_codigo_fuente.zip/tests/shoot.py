"""Abre el visor de prueba en Chrome sin interfaz, recorre las pestanas y guarda capturas."""
import sys, asyncio
from playwright.async_api import async_playwright

HTML, OUT = sys.argv[1], sys.argv[2]


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        pg = await b.new_page(viewport={"width": 1500, "height": 950}, device_scale_factor=1)
        errs = []
        pg.on("console", lambda m: errs.append(m.text) if m.type in ("error", "warning") else None)
        pg.on("pageerror", lambda e: errs.append("PAGEERROR " + str(e)))
        await pg.goto("file://" + HTML)
        await pg.wait_for_timeout(600)
        await pg.screenshot(path=OUT + "_1dist.png")
        # arrastrar delimitador izquierdo
        box = await pg.locator("#cvDist").bounding_box()
        info = await pg.evaluate("({x: DG.X(S.lx), y: DG.pt + 40})")
        await pg.mouse.move(box["x"] + info["x"], box["y"] + info["y"])
        await pg.mouse.down(); await pg.mouse.move(box["x"] + info["x"] + 80, box["y"] + info["y"], steps=5); await pg.mouse.up()
        await pg.click("#ovSims")
        await pg.select_option("#ovVar", "o2"); await pg.click("#ovAdd")
        await pg.fill("#mkVal", "350000"); await pg.click("#mkAdd")
        await pg.wait_for_timeout(300)
        await pg.screenshot(path=OUT + "_1overlay.png")
        await pg.click("#ctype button[data-v=histS]")
        await pg.fill("#mkVal", "0"); await pg.click("#mkAdd")
        await pg.click("#vlist .vitem[data-id=o1]")
        await pg.click("#ctype button[data-v=histS]")
        await pg.wait_for_timeout(300)
        await pg.screenshot(path=OUT + "_2distS.png")
        await pg.click("#ctype button[data-v=cumA]"); await pg.wait_for_timeout(200)
        await pg.screenshot(path=OUT + "_3cum.png")
        await pg.click("#ctype button[data-v=box]"); await pg.wait_for_timeout(200)
        await pg.screenshot(path=OUT + "_3box.png")
        await pg.click("#vlist .vitem[data-id=o6]"); await pg.click("#ctype button[data-v=hist]"); await pg.wait_for_timeout(200)
        await pg.screenshot(path=OUT + "_3disc.png")
        await pg.click("#vlist .vitem[data-id=o1]")
        for t in ["sens", "scat", "scen", "summ", "data"]:
            await pg.click("#tabs button[data-t=%s]" % t)
            await pg.wait_for_timeout(400)
            await pg.screenshot(path=OUT + "_4%s.png" % t, full_page=True)
        await pg.click("#tabs button[data-t=sens]")
        for m in ["chg", "corr", "regmap", "cvar"]:
            await pg.select_option("#sMethod", m); await pg.wait_for_timeout(250)
            await pg.screenshot(path=OUT + "_5sens_%s.png" % m)
        await pg.click("#tabs button[data-t=dist]"); await pg.select_option("#fmt", "k"); await pg.wait_for_timeout(250)
        await pg.screenshot(path=OUT + "_6fmtk.png")
        await pg.click("#sqFoot"); await pg.wait_for_timeout(300)
        await pg.screenshot(path=OUT + "_7about.png")
        print("ERRORS:", errs)
        await b.close()

asyncio.run(main())
