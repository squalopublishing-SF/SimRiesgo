"""Genera un visor de prueba con datos simulados (mismo formato JSON que produce el VBA)."""
import json, math, random, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import build

random.seed(7)
N, SIMS = 2000, 2


def pert(a, m, b):
    al = 1 + 4 * (m - a) / (b - a); be = 1 + 4 * (b - m) / (b - a)
    return a + (b - a) * random.betavariate(al, be)


inputs = {"Costo de materiales": [], "Mano de obra": [], "Precio de venta": [], "Demanda anual": [],
          "Retraso de obra (evento)": [], "Tasa de descuento": []}
outputs = {"Costo total del proyecto": [], "VAN": [], "Flujo / Año 1": [], "Flujo / Año 2": [],
           "Flujo / Año 3": [], "Flujo / Año 4": [], "Unidades defectuosas": []}
for s in range(SIMS):
    for k in inputs: inputs[k].append([])
    for k in outputs: outputs[k].append([])
    for i in range(N):
        mat = pert(180000, 200000, 260000)
        zm = (mat - 206666) / 16000
        mo = 120000 + 15000 * (0.6 * zm + 0.8 * random.gauss(0, 1))
        price = random.triangular(9, 14, 11) * (1 + 0.05 * s)
        dem = random.lognormvariate(math.log(30000), 0.15)
        ev = 1 if random.random() < 0.25 else 0
        r = random.uniform(0.08, 0.12)
        cost = mat + mo + ev * 45000
        flows = [dem * price * (1.04 ** t) - 0.6 * cost / 4 - 0.35 * dem * price for t in range(4)]
        npv = -cost + sum(f / (1 + r) ** (t + 1) for t, f in enumerate(flows))
        defect = sum(1 for _ in range(20) if random.random() < 0.1)
        vals = [mat, mo, price, dem, ev, r]
        for k, v in zip(inputs, vals): inputs[k][s].append(round(v, 6))
        outv = [cost, npv] + flows + [defect]
        for k, v in zip(outputs, outv):
            outputs[k][s].append(None if (k == "VAN" and i % 997 == 13) else round(v, 4))

data = {"meta": {"app": "SimRiesgo", "ver": "2.0", "model": "Proyecto_Planta.xlsx", "date": "11/11/2026 09:30",
                 "iter": N, "sims": SIMS, "sampling": "Hipercubo latino", "seed": 12345, "elapsed": 14.2,
                 "conv": {"used": True, "tol": 0.03, "reached": True},
                 "corr": [{"name": "Matriz 1", "vars": [0, 1], "target": [[1, 0.6], [0.6, 1]], "fixed": False}]},
        "simNames": ["Simulación 1", "Simulación 2"],
        "inputs": [{"n": k, "c": "Modelo!C%d" % (5 + j), "d": d, "v": v} for j, ((k, v), d) in enumerate(zip(inputs.items(),
                   ["PERT(180000; 200000; 260000)", "Normal(120000; 15000)", "Triangular(9; 11; 14)", "Lognormal(30000; 4500)", "Bernoulli(0,25)", "Uniforme(0,08; 0,12)"]))],
        "outputs": [{"n": k, "c": "Modelo!F%d" % (5 + j), "g": "Flujo" if k.startswith("Flujo") else "", "v": v} for j, (k, v) in enumerate(outputs.items())]}

tpl = build.ascii_template(open(build.VISOR, encoding="utf-8").read())
js = json.dumps(data, ensure_ascii=True).replace("<", "\\u003c")
out = tpl.replace("__SR_DATA__", js)
assert all(ord(c) < 127 for c in out)
path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/visor_test.html"
open(path, "w").write(out)
print(path, len(out))
