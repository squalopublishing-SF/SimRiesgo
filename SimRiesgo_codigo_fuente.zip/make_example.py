"""Crea el libro de ejemplo Ejemplo_SimRiesgo.xlsx (modelo de inversion con registro de riesgos)."""
import sys, os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation
import random, math

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "dist", "Ejemplo_SimRiesgo.xlsx")
RED = "D9561A"
wb = Workbook()
ws = wb.active
ws.title = "Modelo"
title = Font(bold=True, size=15, color=RED)
h2 = Font(bold=True, size=12, color="FFFFFF")
fill_h = PatternFill("solid", fgColor=RED)
fill_in = PatternFill("solid", fgColor="EAF2FC")
fill_out = PatternFill("solid", fgColor="FDF0E7")
fill_st = PatternFill("solid", fgColor="F3F3F1")
thin = Border(bottom=Side(style="thin", color="D9D8D4"))
note = Font(italic=True, size=9, color="7C7B77")

def header(r, text, cols=8):
    for c in range(1, cols + 1):
        ws.cell(r, c).fill = fill_h
    ws.cell(r, 1, text).font = h2

ws["A1"] = "Evaluación de riesgo – Proyecto de nueva línea de producción"
ws["A1"].font = title
ws["A2"] = "Modelo de ejemplo para SimRiesgo. Las celdas azules son entradas inciertas (distribuciones); las rojas, salidas de la simulación."
ws["A2"].font = note

header(4, "ENTRADAS INCIERTAS")
ws.append([])
rows_in = [
    ("Inversión en maquinaria (USD)", "=SRPert(180000,200000,260000)", "PERT(mín; más probable; máx)"),
    ("Costo de instalación (USD)", "=SRTriangular(20000,25000,40000)", "Triangular"),
    ("Demanda del año 1 (unidades)", "=SRLognormal(30000,4500)", "Lognormal(media; desv.)"),
    ("Precio de venta (USD/unidad)", "=SRTriangular(9,11,14)", "Triangular"),
    ("Costo variable (USD/unidad)", "=SRNormal(6.5,0.4)", "Normal(media; desv.)"),
    ("Costos fijos anuales (USD)", "=SRUniforme(50000,70000)", "Uniforme(mín; máx)"),
    ("Tasa de descuento", "=SRUniforme(0.09,0.12)", "Uniforme"),
    ("Crecimiento anual de la demanda", "=SRSimTabla(0.03,0.06)", "Escenario: 3% en la simulación 1, 6% en la 2"),
]
r = 5
ws.cell(r, 1, "Variable").font = Font(bold=True)
ws.cell(r, 2, "Valor").font = Font(bold=True)
ws.cell(r, 3, "Distribución").font = Font(bold=True)
refs = {}
for i, (lab, f, d) in enumerate(rows_in):
    rr = r + 1 + i
    ws.cell(rr, 1, lab)
    c = ws.cell(rr, 2, f); c.fill = fill_in
    ws.cell(rr, 3, d).font = note
    refs[i] = "B%d" % rr
fmt_in = ["#,##0", "#,##0", "#,##0", "0.00", "0.00", "#,##0", "0.0%", "0.0%"]
for i, f in enumerate(fmt_in):
    ws.cell(r + 1 + i, 2).number_format = f
INV, INST, DEM, PRICE, CV, CF, RATE, GROW = [refs[i] for i in range(8)]

r = r + 1 + len(rows_in) + 1
header(r, "REGISTRO DE RIESGOS (eventos)")
r += 1
for c, t in enumerate(["Riesgo", "Costo simulado", "Probabilidad", "Costo si ocurre"], start=1):
    ws.cell(r, c, t).font = Font(bold=True)
risks = [
    ("Retraso en la entrega de equipos", "SRPert(20000,45000,90000)", 0.25, "PERT(20.000; 45.000; 90.000)"),
    ("Falla del proveedor de materia prima", "SRUniforme(15000,30000)", 0.10, "Uniforme(15.000; 30.000)"),
    ("Cambio regulatorio", "60000", 0.05, "60.000 fijo"),
]
rk = []
for i, (lab, imp, p, desc) in enumerate(risks):
    rr = r + 1 + i
    ws.cell(rr, 1, lab)
    c = ws.cell(rr, 2, "=SRBernoulli(C%d)*%s" % (rr, imp)); c.fill = fill_in; c.number_format = "#,##0"
    ws.cell(rr, 3, p).number_format = "0%"
    ws.cell(rr, 4, desc).font = note
    rk.append("B%d" % rr)
r = r + 1 + len(risks)
ws.cell(r, 1, "Costo total de riesgos").font = Font(bold=True)
ws.cell(r, 2, "=SUM(%s:%s)" % (rk[0], rk[-1])).number_format = "#,##0"
RISK = "B%d" % r

r += 2
header(r, "DECISIONES (variables que puede optimizar)")
r += 1
ws.cell(r, 1, "Capacidad instalada (unidades/año)")
c = ws.cell(r, 2, 32000); c.number_format = "#,##0"; c.fill = PatternFill("solid", fgColor="FFF7D6")
ws.cell(r, 3, "Valor constante: la optimización lo cambia").font = note
CAP = "B%d" % r
r += 1
ws.cell(r, 1, "Inversión por unidad de capacidad (USD)")
c = ws.cell(r, 2, 1.2); c.number_format = "0.00"
CAPC = "B%d" % r

r += 2
header(r, "FLUJO DE CAJA")
r += 1
years = ["Año 0", "Año 1", "Año 2", "Año 3", "Año 4", "Año 5"]
ws.cell(r, 1, "Concepto").font = Font(bold=True)
for j, y in enumerate(years):
    ws.cell(r, 2 + j, y).font = Font(bold=True)
    ws.cell(r, 2 + j).alignment = Alignment(horizontal="right")
hr = r
lines = ["Ventas (unidades)", "Ingresos", "Costos variables", "Costos fijos", "Inversión y riesgos", "Flujo de caja"]
for k, lab in enumerate(lines):
    ws.cell(hr + 1 + k, 1, lab)
rD, rI, rCV, rCF, rInv, rF = [hr + 1 + k for k in range(6)]
for j in range(6):
    col = get_column_letter(2 + j)
    if j == 0:
        ws.cell(rD, 2 + j, 0); ws.cell(rI, 2 + j, 0); ws.cell(rCV, 2 + j, 0); ws.cell(rCF, 2 + j, 0)
        ws.cell(rInv, 2 + j, "=-(%s+%s+%s+%s*%s)" % (INV, INST, RISK, CAP, CAPC))
    else:
        ws.cell(rD, 2 + j, "=MIN(%s*(1+%s)^%d,%s)" % (DEM, GROW, j - 1, CAP))
        ws.cell(rI, 2 + j, "=%s%d*%s" % (col, rD, PRICE))
        ws.cell(rCV, 2 + j, "=-%s%d*%s" % (col, rD, CV))
        ws.cell(rCF, 2 + j, "=-%s" % CF)
        ws.cell(rInv, 2 + j, 0)
    if j == 0:
        ws.cell(rF, 2 + j, "=SUM(%s%d:%s%d)" % (col, rI, col, rInv))
    else:
        ws.cell(rF, 2 + j, '=SRSalida(SUM(%s%d:%s%d),"","Flujo de caja")' % (col, rI, col, rInv)).fill = fill_out
    for rr in (rD, rI, rCV, rCF, rInv, rF):
        ws.cell(rr, 2 + j).number_format = "#,##0"
ws.cell(rF, 1).font = Font(bold=True)

r = rF + 2
header(r, "SALIDAS DE LA SIMULACIÓN")
r += 1
outs = [
    ("Costo total del proyecto (USD)", '=SRSalida(%s+%s+%s+%s*%s,"Costo total del proyecto")' % (INV, INST, RISK, CAP, CAPC), "#,##0"),
    ("Valor actual neto - VAN (USD)", '=SRSalida(NPV(%s,C%d:G%d)+B%d,"VAN")' % (RATE, rF, rF, rF), "#,##0"),
    ("Tasa interna de retorno - TIR", '=SRSalida(IRR(B%d:G%d),"TIR")' % (rF, rF), "0.0%"),
]
orefs = []
for i, (lab, f, nf) in enumerate(outs):
    rr = r + i
    ws.cell(rr, 1, lab).font = Font(bold=True)
    c = ws.cell(rr, 2, f); c.fill = fill_out; c.number_format = nf
    orefs.append("B%d" % rr)
COST, VAN, TIR = orefs

r = r + len(outs) + 1
header(r, "RESULTADOS (se actualizan al terminar la simulación)")
r += 1
stats = [
    ("Probabilidad de que el VAN sea negativo", "=SRObjetivo(%s,0)" % VAN, "0.0%"),
    ("VAN medio (USD)", "=SRMedia(%s)" % VAN, "#,##0"),
    ("VAN – percentil 5% (USD)", "=SRPercentil(%s,0.05)" % VAN, "#,##0"),
    ("VAN – percentil 95% (USD)", "=SRPercentil(%s,0.95)" % VAN, "#,##0"),
    ("Presupuesto aprobado (USD)", 300000, "#,##0"),
    ("Probabilidad de exceder el presupuesto", "=1-SRObjetivo(%s,B%d)" % (COST, r + 4), "0.0%"),
    ("Costo total – percentil 80% (USD)", "=SRPercentil(%s,0.8)" % COST, "#,##0"),
]
for i, (lab, f, nf) in enumerate(stats):
    rr = r + i
    ws.cell(rr, 1, lab)
    c = ws.cell(rr, 2, f); c.number_format = nf
    c.fill = fill_st if not isinstance(f, (int, float)) else PatternFill("solid", fgColor="FFF7D6")

ws.column_dimensions["A"].width = 42
for col in "BCDEFG":
    ws.column_dimensions[col].width = 15
ws.column_dimensions["C"].width = 18
ws.sheet_view.showGridLines = False
ws.freeze_panes = "A4"

# ------------------------- Leame -------------------------
ld = wb.create_sheet("Léame")
txt = [
    ("SimRiesgo 2.0 – libro de ejemplo", title),
    ("", None),
    ("1. Instale el complemento SimRiesgo.xlam (Archivo > Opciones > Complementos > Administrar: Complementos de Excel > Ir > Examinar).", None),
    ("2. Abra este libro: aparecerá la pestaña SimRiesgo en la cinta.", None),
    ("3. En la pestaña SimRiesgo escriba las iteraciones (por ejemplo 5000), active 'Detener al converger' si lo desea, y pulse Simular.", None),
    ("4. Al terminar se abre el visor de resultados en el navegador: histogramas con delimitadores, curvas S, tornados, dispersión, escenarios y convergencia.", None),
    ("5. Para comparar los dos escenarios de crecimiento de la demanda, ponga Simulaciones = 2 (la celda usa SRSimTabla).", None),
    ("", None),
    ("Qué trae preparado este ejemplo", Font(bold=True, size=12, color=RED)),
    ("• Hoja 'SR Correlaciones': inversión e instalación correlacionadas (+0,6) y demanda y precio (-0,5). Cambie los coeficientes del triángulo superior y vuelva a simular.", None),
    ("• Hoja 'SR Optimizacion': busca la capacidad instalada que maximiza el VAN medio sin que el percentil 80 % del costo total supere 320.000 USD. Pulse Optimizar en la cinta.", None),
    ("• Hoja 'Datos históricos': 60 meses de demanda. Selecciónelos y pulse 'Ajustar a datos' para ver el ranking de distribuciones (AIC, BIC, K-S, P-P, Q-Q).", None),
    ("• 'Definir distribución': seleccione una celda azul y pulse el botón para ver la curva, los delimitadores y los estadísticos antes de aplicarla.", None),
    ("• Con 'Guardar en el libro' activado, los resultados quedan dentro del archivo: al reabrirlo, el visor, el informe y SRMedia/SRPercentil siguen disponibles.", None),
    ("", None),
    ("Funciones de entrada: SRNormal, SRTriangular, SRPert, SRUniforme, SRLognormal, SRWeibull, SRExponencial, SRGamma, SRBeta, SRPoisson, SRBinomial, SRBernoulli, SRDiscreta, SRLogLogistica, SRPearson5, SRNormalTrunc, SREmpirica.", None),
    ("Salidas: SRSalida(valor; [nombre]; [grupo]).  Estadísticos: SRMedia, SRDesvEst, SRMinimo, SRMaximo, SRMediana, SRPercentil, SRObjetivo, SRProbEntre.  Teóricos: SRDensidad, SRCuantil, SRMomento.", None),
    ("Fuera de la simulación cada distribución muestra su valor esperado. Active 'Valores aleatorios' en la cinta para ver muestras al pulsar F9.", None),
]
for i, (t, f) in enumerate(txt, start=1):
    c = ld.cell(i, 1, t)
    if f: c.font = f
ld.column_dimensions["A"].width = 150
ld.sheet_view.showGridLines = False

# ------------------------- Correlaciones -------------------------
grey = Font(size=8, color="969591")
wc = wb.create_sheet("SR Correlaciones")
wc.sheet_view.showGridLines = False
wc["A1"] = "Matrices de correlación de rangos (SimRiesgo)"; wc["A1"].font = Font(bold=True, size=13)
wc["A2"] = "Edite solo el triángulo superior (celdas blancas): el inferior se completa solo. Valores entre -1 y 1."; wc["A2"].font = Font(italic=True, color="7C7B77")
wc.column_dimensions["A"].width = 30
for col in "BC": wc.column_dimensions[col].width = 26
cell_of = {"inv": INV, "inst": INST, "dem": DEM, "price": PRICE}
labels = {"inv": "Inversión en maquinaria (USD)", "inst": "Costo de instalación (USD)", "dem": "Demanda del año 1 (unidades)", "price": "Precio de venta (USD/unidad)"}
white = PatternFill("solid", fgColor="FFFFFF"); diag = PatternFill("solid", fgColor="ECEBE8"); low = PatternFill("solid", fgColor="F6F6F4"); head = PatternFill("solid", fgColor="FDF0E7")
box = Border(*(Side(style="thin", color="D9D8D4"),) * 4)
for k, (pair, rho, r0) in enumerate([(("inv", "inst"), 0.6, 4), (("dem", "price"), -0.5, 10)], start=1):
    wc.cell(r0, 1, "Matriz %d" % k).font = Font(bold=True, color="9A3D0C")
    for i, key in enumerate(pair):
        a = wc.cell(r0, 2 + i, "Modelo!" + cell_of[key]); a.font = grey; a.alignment = Alignment(horizontal="center")
        h = wc.cell(r0 + 1, 2 + i, labels[key]); h.font = Font(bold=True); h.fill = head; h.alignment = Alignment(horizontal="center", wrap_text=True)
        v = wc.cell(r0 + 2 + i, 1, labels[key]); v.font = Font(bold=True); v.fill = head
    tl = "$B$%d" % (r0 + 2)
    for i in range(2):
        for j in range(2):
            c = wc.cell(r0 + 2 + i, 2 + j)
            if i == j: c.value = 1; c.fill = diag
            elif j > i: c.value = rho; c.fill = white
            else: c.value = "=%s%d" % (get_column_letter(2 + i), r0 + 2 + j); c.fill = low; c.font = Font(color="7C7B77")
            c.number_format = "0.00"; c.alignment = Alignment(horizontal="center"); c.border = box
    dv = DataValidation(type="decimal", operator="between", formula1="-1", formula2="1", allow_blank=True)
    wc.add_data_validation(dv); dv.add("C%d" % (r0 + 2))
    wb.defined_names["SR_Corr_%d" % k] = DefinedName("SR_Corr_%d" % k, attr_text="'SR Correlaciones'!$B$%d:$C$%d" % (r0 + 2, r0 + 3))
    for i, key in enumerate(pair, start=1):
        col, row = cell_of[key][0], cell_of[key][1:]
        wb.defined_names["SR_CorrIn_%d_%d" % (k, i)] = DefinedName("SR_CorrIn_%d_%d" % (k, i), attr_text="Modelo!$%s$%s" % (col, row), hidden=True)

# ------------------------- Optimizacion -------------------------
wo = wb.create_sheet("SR Optimizacion")
wo.sheet_view.showGridLines = False
sec = Font(bold=True, size=11, color="9A3D0C")
wo["B2"] = "Optimización bajo incertidumbre"; wo["B2"].font = Font(bold=True, size=15, color="9A3D0C")
wo["B3"] = "Escriba las celdas como Hoja!Celda. Las celdas blancas son editables. Pulse Optimizar en la cinta SimRiesgo."; wo["B3"].font = Font(color="7C7B77")
stats_list = ["Media", "Desviación estándar", "Percentil", "Mínimo", "Máximo", "Probabilidad <= x", "Probabilidad >= x", "Valor (sin simular)"]
for i, t in enumerate(stats_list, start=1): wo.cell(i, 26, t)
wo["AA1"] = "Maximizar"; wo["AA2"] = "Minimizar"; wo["AB1"] = "<="; wo["AB2"] = ">="
for col in ("Z", "AA", "AB"): wo.column_dimensions[col].hidden = True
wo.column_dimensions["A"].width = 2; wo.column_dimensions["B"].width = 34
for col in "CDEF": wo.column_dimensions[col].width = 13
wo.column_dimensions["G"].width = 3; wo.column_dimensions["H"].width = 24; wo.column_dimensions["I"].width = 20
for col in "JKL": wo.column_dimensions[col].width = 11
def ed(c): c.fill = white; c.border = box
wo["B4"] = "Objetivo"; wo["B4"].font = sec
wo["B5"] = "Celda de salida"; wo["C5"] = "Modelo!" + VAN
wo["B6"] = "Estadístico"; wo["C6"] = "Media"
wo["B7"] = "Parámetro (p del percentil o x)"; wo["C7"] = 0.05
wo["B8"] = "Sentido"; wo["C8"] = "Maximizar"
for a in ("C5", "C6", "C7", "C8"): ed(wo[a])
dv1 = DataValidation(type="list", formula1="=$Z$1:$Z$7"); wo.add_data_validation(dv1); dv1.add("C6")
dv2 = DataValidation(type="list", formula1="=$AA$1:$AA$2"); wo.add_data_validation(dv2); dv2.add("C8")
wo["B10"] = "Variables de decisión"; wo["B10"].font = sec
for j, t in enumerate(["Celda", "Mínimo", "Máximo", "Paso (0 = continuo)"]): wo.cell(11, 2 + j, t).font = Font(bold=True)
wo["B12"] = "Modelo!" + CAP; wo["C12"] = 24000; wo["D12"] = 46000; wo["E12"] = 500
for rr in range(12, 32):
    for cc in range(2, 6): ed(wo.cell(rr, cc))
wo["H10"] = "Restricciones (opcional)"; wo["H10"].font = sec
for j, t in enumerate(["Celda", "Estadístico", "Parámetro", "Operador", "Límite"]): wo.cell(11, 8 + j, t).font = Font(bold=True)
wo["H12"] = "Modelo!" + COST; wo["I12"] = "Percentil"; wo["J12"] = 0.8; wo["K12"] = "<="; wo["L12"] = 320000
for rr in range(12, 22):
    for cc in range(8, 13): ed(wo.cell(rr, cc))
dv3 = DataValidation(type="list", formula1="=$Z$1:$Z$8"); wo.add_data_validation(dv3); dv3.add("I12:I21")
dv4 = DataValidation(type="list", formula1="=$AB$1:$AB$2"); wo.add_data_validation(dv4); dv4.add("K12:K21")
wo["H23"] = "Restricción incluida: el percentil 80 % del costo total no debe superar 320.000 USD."; wo["H23"].font = Font(italic=True, color="7C7B77")
wo["B34"] = "Configuración"; wo["B34"].font = sec
for i, (lab, v) in enumerate([("Iteraciones por prueba", 300), ("Pruebas máximas", 150), ("Tamaño de población", 12), ("Detener si no mejora en (pruebas)", 50), ("Semilla (números comunes)", 12345)]):
    wo.cell(35 + i, 2, lab); c = wo.cell(35 + i, 3, v); ed(c)

# ------------------------- Datos historicos -------------------------
wd = wb.create_sheet("Datos históricos")
wd.sheet_view.showGridLines = False
wd["A1"] = "Demanda mensual histórica (unidades)"; wd["A1"].font = Font(bold=True, size=13, color=RED)
wd["A2"] = "Seleccione B4:B63 y pulse 'Ajustar a datos' en la cinta."; wd["A2"].font = note
wd["A3"] = "Mes"; wd["B3"] = "Demanda"; wd["A3"].font = wd["B3"].font = Font(bold=True)
rnd = random.Random(42)
for i in range(60):
    wd.cell(4 + i, 1, i + 1)
    wd.cell(4 + i, 2, round(rnd.lognormvariate(math.log(2500), 0.18)))
wd.column_dimensions["A"].width = 10; wd.column_dimensions["B"].width = 14
wb.active = 0
wb.save(OUT)
print(OUT)
