"""Compresion MS-OVBA (seccion 2.4.1 de la especificacion [MS-OVBA])."""
import struct


def _bitcount(diff):
    b = 0
    while (1 << b) < diff:
        b += 1
    return max(b, 4)


def _compress_chunk(data):
    out = bytearray()
    n = len(data)
    pos = 0
    index = {}  # prefijo de 3 bytes -> lista de posiciones
    while pos < n:
        flag_pos = len(out)
        out.append(0)
        flags = 0
        for bit in range(8):
            if pos >= n:
                break
            bc = _bitcount(pos)
            max_len = (0xFFFF >> bc) + 3
            best_len, best_off = 0, 0
            if pos >= 1 and pos + 3 <= n:
                key = bytes(data[pos:pos + 3])
                for cand in reversed(index.get(key, ())[-512:]):
                    off = pos - cand
                    if off > (1 << bc):
                        break
                    l = 0
                    lim = min(max_len, n - pos)
                    while l < lim and data[cand + l] == data[pos + l]:
                        l += 1
                    if l > best_len:
                        best_len, best_off = l, off
                        if l == lim:
                            break
            if best_len >= 3:
                token = ((best_off - 1) << (16 - bc)) | (best_len - 3)
                out += struct.pack("<H", token)
                flags |= 1 << bit
                step = best_len
            else:
                out.append(data[pos])
                step = 1
            for p in range(pos, pos + step):
                if p + 3 <= n:
                    index.setdefault(bytes(data[p:p + 3]), []).append(p)
            pos += step
        out[flag_pos] = flags
    return bytes(out)


def compress(data: bytes) -> bytes:
    out = bytearray(b"\x01")
    for start in range(0, len(data), 4096):
        chunk = data[start:start + 4096]
        comp = _compress_chunk(chunk)
        if len(comp) > 4096 and len(chunk) == 4096:
            header = 0x3000 | (4096 + 2 - 3)
            out += struct.pack("<H", header) + chunk
        else:
            header = 0x8000 | 0x3000 | (len(comp) + 2 - 3)
            out += struct.pack("<H", header) + comp
    return bytes(out)
